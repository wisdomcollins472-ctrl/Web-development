-- ============================================================================
-- BENSON IDAHOSA UNIVERSITY — DATABASE SCHEMA (PostgreSQL / Supabase)
-- ----------------------------------------------------------------------------
-- Row-Level Security is the primary authorisation boundary: the client only
-- ever receives the anon key, so every policy below must hold on its own.
-- Frontend permission checks (src/lib/auth.tsx) are a UX convenience only.
-- ============================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------- enums ----
do $$ begin
  create type user_role as enum ('SUPER_ADMIN','ADMIN','ADMISSIONS','EDITOR','FACULTY_ADMIN','STAFF','STUDENT','APPLICANT');
exception when duplicate_object then null; end $$;

do $$ begin
  create type content_status as enum ('draft','published');
exception when duplicate_object then null; end $$;

do $$ begin
  create type programme_level as enum ('undergraduate','postgraduate','professional');
exception when duplicate_object then null; end $$;

do $$ begin
  create type application_status as enum ('draft','submitted','under_review','additional_information_required','accepted','rejected','withdrawn');
exception when duplicate_object then null; end $$;

do $$ begin
  create type enquiry_status as enum ('new','in_progress','responded','resolved');
exception when duplicate_object then null; end $$;

-- --------------------------------------------------------------- profiles --
create table if not exists profiles (
  id          uuid primary key references auth.users on delete cascade,
  email       text not null,
  full_name   text not null default '',
  role        user_role not null default 'APPLICANT',
  phone       text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ------------------------------------------------------------------ roles --
create table if not exists roles (
  role        user_role primary key,
  label       text not null,
  permissions text[] not null default '{}'
);

insert into roles (role, label, permissions) values
  ('SUPER_ADMIN','Super administrator', array['*']),
  ('ADMIN','Administrator', array['content.read','content.write','content.delete','content.publish','applications.read','applications.update','enquiries.read','enquiries.update','users.read','audit.read','analytics.read','documents.write']),
  ('ADMISSIONS','Admissions officer', array['content.read','applications.read','applications.update','enquiries.read','enquiries.update','documents.write']),
  ('EDITOR','Content editor', array['content.read','content.write','content.publish','documents.write']),
  ('FACULTY_ADMIN','Faculty administrator', array['content.read','programmes.read','programmes.write']),
  ('STAFF','Staff', array['content.read']),
  ('STUDENT','Student', array[]::text[]),
  ('APPLICANT','Applicant', array[]::text[])
on conflict (role) do nothing;

-- --------------------------------------------------- academic structure ----
create table if not exists faculties (
  id           uuid primary key default gen_random_uuid(),
  slug         text unique not null,
  name         text not null,
  short_name   text not null default '',
  ordinal      text not null default '',
  summary      text not null default '',
  intro        text not null default '',
  dean         text not null default '',
  departments  text[] not null default '{}',
  research_areas text[] not null default '{}',
  contact_email text not null default '',
  contact_phone text not null default '',
  image_path   text not null default '',
  status       content_status not null default 'published',
  sources      jsonb not null default '[]'::jsonb,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists faculties_status_idx on faculties (status);

create table if not exists departments (
  id          uuid primary key default gen_random_uuid(),
  slug        text unique not null,
  name        text not null,
  faculty_id  uuid not null references faculties on delete cascade,
  created_at  timestamptz not null default now()
);
create index if not exists departments_faculty_idx on departments (faculty_id);

create table if not exists programmes (
  id           uuid primary key default gen_random_uuid(),
  slug         text unique not null,
  title        text not null,
  faculty_id   uuid not null references faculties on delete cascade,
  department   text not null default '',
  level        programme_level not null,
  award        text not null default '',
  duration     text not null default '',
  overview     text not null default '',
  objectives   text[] not null default '{}',
  requirements text[] not null default '{}',
  careers      text[] not null default '{}',
  status       content_status not null default 'published',
  sources      jsonb not null default '[]'::jsonb,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists programmes_faculty_idx on programmes (faculty_id);
create index if not exists programmes_level_idx on programmes (level);
create index if not exists programmes_status_idx on programmes (status);

-- ------------------------------------------------------------- admissions --
create table if not exists applicants (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users on delete cascade,
  first_name   text not null default '',
  last_name    text not null default '',
  phone        text not null default '',
  date_of_birth date,
  gender       text not null default '',
  nationality  text not null default '',
  state        text not null default '',
  address      text not null default '',
  created_at   timestamptz not null default now(),
  unique (user_id)
);

create table if not exists applications (
  id             uuid primary key default gen_random_uuid(),
  reference      text unique not null,
  applicant_id   uuid not null references applicants on delete cascade,
  programme_id   uuid not null references programmes on delete restrict,
  level          programme_level not null,
  status         application_status not null default 'draft',
  data           jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists applications_applicant_idx on applications (applicant_id);
create index if not exists applications_status_idx on applications (status);

create table if not exists application_documents (
  id             uuid primary key default gen_random_uuid(),
  application_id uuid not null references applications on delete cascade,
  storage_path   text not null,
  file_name      text not null,
  mime_type      text not null default '',
  size_bytes     bigint not null default 0,
  uploaded_at    timestamptz not null default now()
);
create index if not exists application_documents_app_idx on application_documents (application_id);

create table if not exists payments (
  id             uuid primary key default gen_random_uuid(),
  application_id uuid not null references applications on delete cascade,
  provider       text not null,
  provider_ref   text not null,
  amount_kobo    bigint not null,
  currency       text not null default 'NGN',
  verified       boolean not null default false,
  verified_at    timestamptz,
  created_at     timestamptz not null default now()
);

-- ------------------------------------------------------------- newsroom ----
create table if not exists news (
  id             uuid primary key default gen_random_uuid(),
  slug           text unique not null,
  title          text not null,
  excerpt        text not null default '',
  content        text not null default '',
  category       text not null default 'Announcements',
  author         text not null default '',
  cover_image    text not null default '',
  published_at   date not null default current_date,
  status         content_status not null default 'draft',
  seo_title      text not null default '',
  seo_description text not null default '',
  og_image       text not null default '',
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists news_status_idx on news (status, published_at desc);

create table if not exists events (
  id              uuid primary key default gen_random_uuid(),
  slug            text unique not null,
  title           text not null,
  description     text not null default '',
  image           text not null default '',
  start_date      timestamptz not null,
  end_date        timestamptz not null,
  location        text not null default '',
  category        text not null default 'Campus',
  registration_url text not null default '',
  status          content_status not null default 'draft',
  created_at      timestamptz not null default now()
);
create index if not exists events_start_idx on events (start_date);

create table if not exists announcements (
  id         uuid primary key default gen_random_uuid(),
  title      text not null,
  body       text not null default '',
  href       text not null default '/',
  cta        text not null default 'Read more',
  starts_at  timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '30 days',
  status     content_status not null default 'draft',
  created_at timestamptz not null default now()
);

create table if not exists documents (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  description text not null default '',
  category    text not null default 'Other',
  version     text not null default '1.0',
  storage_path text not null default '',
  date        date not null default current_date,
  status      content_status not null default 'draft',
  created_at  timestamptz not null default now()
);

create table if not exists faqs (
  id         uuid primary key default gen_random_uuid(),
  question   text not null,
  answer     text not null,
  category   text not null default 'General',
  status     content_status not null default 'draft',
  sort_order int not null default 0
);

create table if not exists scholarships (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  summary     text not null default '',
  eligibility text not null default '',
  deadline    date,
  status      content_status not null default 'draft'
);

create table if not exists gallery (
  id         uuid primary key default gen_random_uuid(),
  title      text not null default '',
  image_path text not null,
  category   text not null default 'Campus',
  status     content_status not null default 'draft',
  sort_order int not null default 0
);

create table if not exists staff (
  id         uuid primary key default gen_random_uuid(),
  full_name  text not null,
  position   text not null default '',
  office     text not null default '',
  biography  text not null default '',
  email      text not null default '',
  image_path text not null default '',
  sort_order int not null default 0,
  status     content_status not null default 'draft'
);

-- ------------------------------------------------------ contact & system ---
create table if not exists enquiries (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  email      text not null,
  phone      text not null default '',
  subject    text not null default '',
  message    text not null,
  status     enquiry_status not null default 'new',
  created_at timestamptz not null default now()
);

create table if not exists notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users on delete cascade,
  category   text not null default 'system',
  title      text not null,
  body       text not null default '',
  href       text not null default '/',
  read       boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on notifications (user_id, read);

create table if not exists audit_logs (
  id         uuid primary key default gen_random_uuid(),
  actor_id   uuid references auth.users on delete set null,
  actor_email text not null default '',
  action     text not null,
  resource   text not null default '',
  meta       jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_logs_created_idx on audit_logs (created_at desc);

create table if not exists site_settings (
  key        text primary key,
  value      jsonb not null,
  updated_at timestamptz not null default now()
);

insert into site_settings (key, value) values
  ('institution', '{"name":"Benson Idahosa University","short":"BIU","city":"Benin City","state":"Edo","country":"Nigeria"}'::jsonb),
  ('contact', '{"phones":["+2348111117310","+2348149906200"],"campus":"15 Agboma St, Ogogugbo, Benin City 300102, Edo","mailing":"Private Mail Bag 1100, University Way, Off Upper Adesuwa Road, GRA, Benin City"}'::jsonb)
on conflict (key) do nothing;

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================
alter table profiles             enable row level security;
alter table applicants           enable row level security;
alter table applications         enable row level security;
alter table application_documents enable row level security;
alter table payments             enable row level security;
alter table notifications        enable row level security;
alter table enquiries            enable row level security;
alter table news                 enable row level security;
alter table events               enable row level security;
alter table announcements        enable row level security;
alter table documents            enable row level security;
alter table faculties            enable row level security;
alter table departments          enable row level security;
alter table programmes           enable row level security;
alter table audit_logs           enable row level security;
alter table staff                enable row level security;
alter table scholarships         enable row level security;
alter table faqs                 enable row level security;
alter table gallery              enable row level security;
alter table site_settings        enable row level security;

-- Helper: current user's role without recursing through RLS.
create or replace function current_role_name() returns user_role
language sql stable security definer set search_path = public as $$
  select role from profiles where id = auth.uid();
$$;

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(current_role_name() in ('SUPER_ADMIN','ADMIN','ADMISSIONS','EDITOR','FACULTY_ADMIN'), false);
$$;

-- Public read of published content only -------------------------------------
drop policy if exists public_read_published on news;
create policy public_read_published on news for select using (status = 'published');
drop policy if exists public_read_published on events;
create policy public_read_published on events for select using (status = 'published');
drop policy if exists public_read_published on announcements;
create policy public_read_published on announcements for select using (status = 'published' and starts_at <= now() and expires_at > now());
drop policy if exists public_read_published on documents;
create policy public_read_published on documents for select using (status = 'published');
drop policy if exists public_read_published on faculties;
create policy public_read_published on faculties for select using (status = 'published');
drop policy if exists public_read_published on departments;
create policy public_read_published on departments for select using (true);
drop policy if exists public_read_published on programmes;
create policy public_read_published on programmes for select using (status = 'published');
drop policy if exists public_read on faqs;
create policy public_read on faqs for select using (status = 'published');
drop policy if exists public_read on scholarships;
create policy public_read on scholarships for select using (status = 'published');
drop policy if exists public_read on gallery;
create policy public_read on gallery for select using (status = 'published');
drop policy if exists public_read on staff;
create policy public_read on staff for select using (status = 'published');
drop policy if exists public_read on site_settings;
create policy public_read on site_settings for select using (true);

-- Profiles ------------------------------------------------------------------
drop policy if exists own_profile on profiles;
create policy own_profile on profiles for select using (id = auth.uid());
drop policy if exists own_profile_update on profiles;
create policy own_profile_update on profiles for update using (id = auth.uid());
drop policy if exists admin_profiles on profiles;
create policy admin_profiles on profiles for all using (is_admin());

-- Applicants: a user only ever sees their own applicant record ---------------
drop policy if exists own_applicant on applicants;
create policy own_applicant on applicants for all using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists admin_applicants on applicants;
create policy admin_applicants on applicants for all using (is_admin());

-- Applications: strictly scoped to the authenticated applicant --------------
drop policy if exists own_applications on applications;
create policy own_applications on applications for all
  using (applicant_id in (select id from applicants where user_id = auth.uid()))
  with check (applicant_id in (select id from applicants where user_id = auth.uid()));
drop policy if exists admin_applications on applications;
create policy admin_applications on applications for all using (is_admin());

drop policy if exists own_documents on application_documents;
create policy own_documents on application_documents for all
  using (application_id in (
    select a.id from applications a join applicants ap on ap.id = a.applicant_id where ap.user_id = auth.uid()))
  with check (application_id in (
    select a.id from applications a join applicants ap on ap.id = a.applicant_id where ap.user_id = auth.uid()));
drop policy if exists admin_documents on application_documents;
create policy admin_documents on application_documents for all using (is_admin());

drop policy if exists own_payments on payments;
create policy own_payments on payments for select
  using (application_id in (
    select a.id from applications a join applicants ap on ap.id = a.applicant_id where ap.user_id = auth.uid()));
drop policy if exists admin_payments on payments;
create policy admin_payments on payments for all using (is_admin());

-- Notifications: own only ----------------------------------------------------
drop policy if exists own_notifications on notifications;
create policy own_notifications on notifications for all using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists admin_notifications on notifications;
create policy admin_notifications on notifications for all using (is_admin());

-- Enquiries: anyone may create; only staff may read or update --------------
drop policy if exists insert_enquiry on enquiries;
create policy insert_enquiry on enquiries for insert with check (true);
drop policy if exists read_enquiries on enquiries;
create policy read_enquiries on enquiries for select using (is_admin());
drop policy if exists update_enquiries on enquiries;
create policy update_enquiries on enquiries for update using (is_admin());

-- Editorial write access ----------------------------------------------------
drop policy if exists write_news on news;
create policy write_news on news for all using (is_admin()) with check (is_admin());
drop policy if exists write_events on events;
create policy write_events on events for all using (is_admin()) with check (is_admin());
drop policy if exists write_announcements on announcements;
create policy write_announcements on announcements for all using (is_admin()) with check (is_admin());
drop policy if exists write_documents on documents;
create policy write_documents on documents for all using (is_admin()) with check (is_admin());
drop policy if exists write_faculties on faculties;
create policy write_faculties on faculties for all using (is_admin()) with check (is_admin());
drop policy if exists write_departments on departments;
create policy write_departments on departments for all using (is_admin()) with check (is_admin());
drop policy if exists write_programmes on programmes;
create policy write_programmes on programmes for all using (is_admin()) with check (is_admin());
drop policy if exists write_staff on staff;
create policy write_staff on staff for all using (is_admin()) with check (is_admin());
drop policy if exists write_scholarships on scholarships;
create policy write_scholarships on scholarships for all using (is_admin()) with check (is_admin());
drop policy if exists write_faqs on faqs;
create policy write_faqs on faqs for all using (is_admin()) with check (is_admin());
drop policy if exists write_gallery on gallery;
create policy write_gallery on gallery for all using (is_admin()) with check (is_admin());
drop policy if exists write_settings on site_settings;
create policy write_settings on site_settings for all using (is_admin()) with check (is_admin());

-- Audit logs: read-only for admins, written by the server ------------------
drop policy if exists read_audit on audit_logs;
create policy read_audit on audit_logs for select using (is_admin());

-- ============================================================================
-- STORAGE BUCKETS
-- ============================================================================
insert into storage.buckets (id, name, public) values
  ('site-assets','site-assets', true),
  ('programme-images','programme-images', true),
  ('faculty-images','faculty-images', true),
  ('news-images','news-images', true),
  ('event-images','event-images', true),
  ('gallery','gallery', true),
  ('documents','documents', true),
  ('application-documents','application-documents', false),
  ('avatars','avatars', true)
on conflict (id) do nothing;

-- Private bucket: applicants may only reach files inside their own folder.
drop policy if exists own_application_files on storage.objects;
create policy own_application_files on storage.objects for all
  using (
    bucket_id = 'application-documents'
    and (storage.foldername(name))[1] in (
      select a.id::text from applications a join applicants ap on ap.id = a.applicant_id where ap.user_id = auth.uid()
    )
  )
  with check (
    bucket_id = 'application-documents'
    and (storage.foldername(name))[1] in (
      select a.id::text from applications a join applicants ap on ap.id = a.applicant_id where ap.user_id = auth.uid()
    )
  );

drop policy if exists admin_application_files on storage.objects;
create policy admin_application_files on storage.objects for all
  using (bucket_id = 'application-documents' and is_admin());

-- Public read on public buckets
drop policy if exists public_assets_read on storage.objects;
create policy public_assets_read on storage.objects for select
  using (bucket_id in ('site-assets','programme-images','faculty-images','news-images','event-images','gallery','avatars','documents'));

-- ============================================================================
-- UPDATED_AT TRIGGER
-- ============================================================================
create or replace function touch_updated_at() returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists programmes_touch on programmes;
create trigger programmes_touch before update on programmes for each row execute function touch_updated_at();
drop trigger if exists faculties_touch on faculties;
create trigger faculties_touch before update on faculties for each row execute function touch_updated_at();
drop trigger if exists news_touch on news;
create trigger news_touch before update on news for each row execute function touch_updated_at();
drop trigger if exists profiles_touch on profiles;
create trigger profiles_touch before update on profiles for each row execute function touch_updated_at();
drop trigger if exists applications_touch on applications;
create trigger applications_touch before update on applications for each row execute function touch_updated_at();
