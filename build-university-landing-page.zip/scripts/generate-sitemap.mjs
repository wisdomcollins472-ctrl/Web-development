/**
 * SITEMAP GENERATOR
 * ---------------------------------------------------------------------------
 * Run after `npm run build` to emit dist/sitemap.xml from the route table:
 *   node scripts/generate-sitemap.mjs
 * Content routes (news, events, programmes, faculties) are appended by the
 * deploy pipeline from the database.
 */
import { writeFileSync, readFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const siteUrl = (process.env.VITE_SITE_URL ?? "https://biu.example.com").replace(/\/$/, "");

const STATIC = [
  { loc: "/", priority: "1.0", changefreq: "weekly" },
  { loc: "/about", priority: "0.8", changefreq: "monthly" },
  { loc: "/about/leadership", priority: "0.6", changefreq: "monthly" },
  { loc: "/academics", priority: "0.9", changefreq: "weekly" },
  { loc: "/academics/faculties", priority: "0.9", changefreq: "monthly" },
  { loc: "/academics/programmes", priority: "0.9", changefreq: "weekly" },
  { loc: "/admissions", priority: "0.9", changefreq: "weekly" },
  { loc: "/campus-life", priority: "0.8", changefreq: "monthly" },
  { loc: "/research", priority: "0.7", changefreq: "monthly" },
  { loc: "/news", priority: "0.8", changefreq: "daily" },
  { loc: "/events", priority: "0.7", changefreq: "weekly" },
  { loc: "/documents", priority: "0.6", changefreq: "monthly" },
  { loc: "/student-hub", priority: "0.7", changefreq: "monthly" },
  { loc: "/staff-hub", priority: "0.6", changefreq: "monthly" },
  { loc: "/contact", priority: "0.7", changefreq: "monthly" },
];

// Content routes exported at build time, if the pipeline provides them.
let dynamic = [];
const contentFile = path.join(root, "dist", "content-routes.json");
if (existsSync(contentFile)) {
  try {
    dynamic = JSON.parse(readFileSync(contentFile, "utf8"));
  } catch {
    dynamic = [];
  }
}

const urls = [...STATIC, ...dynamic];
const today = new Date().toISOString().slice(0, 10);

const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls
  .map(
    (u) => `  <url>
    <loc>${siteUrl}/#${u.loc}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`
  )
  .join("\n")}
</urlset>
`;

writeFileSync(path.join(root, "dist", "sitemap.xml"), xml);
console.log(`sitemap.xml written with ${urls.length} URLs`);
