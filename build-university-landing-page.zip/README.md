# Benson Idahosa University — Digital Platform

A production-shaped, content-managed website for Benson Idahosa University (BIU), Benin City,
Edo State. Built with React, TypeScript, Vite and Tailwind CSS v4.

## Quick start

```bash
npm install
npm run dev
npm run build          # → dist/
node scripts/generate-sitemap.mjs   # → dist/sitemap.xml (run after build)
```

## What this build is

| Area | Implementation |
| --- | --- |
| Design system | `src/index.css` — colour, type, spacing, button, form and motion tokens |
| Routing | `src/lib/router.tsx` — hash router with query params, scroll restoration, per-route SEO |
| Content layer | `src/lib/cms.ts` — typed records, verified sources, loading/error/empty states |
| Auth & roles | `src/lib/auth.tsx` — 8 roles, permission map, session handling |
| Public site | `src/pages/` — home, about, academics, admissions, campus life, research, news, events, documents, hubs, contact |
| Application flow | `src/pages/Apply.tsx` + `src/pages/Portal.tsx` — drafts, documents, statuses, notifications |
| CMS | `src/pages/Admin.tsx` — dashboard, applications, enquiries, content CRUD, users, audit log |
| Assistant | `src/components/AskBIU.tsx` — retrieval over verified knowledge base only |
| Search | `src/components/SearchOverlay.tsx` — categorised results (⌘K) |
| Database | `supabase/schema.sql` — tables, indexes, constraints, RLS policies, storage buckets |
| Secrets | `.env.example` — server-only keys never enter client code |

## Content integrity

Every record in `src/lib/cms.ts` carries a `sources` array. Facts that could not be verified
are left **empty** and the UI shows an editable CMS placeholder instead of inventing content.
There are no fabricated statistics, rankings, awards, fees, staff or programme requirements.

## Backend contract

`src/lib/cms.ts` is the seam. Replace its functions with Supabase queries — the interfaces
(`db.*`, `admin.*`, `subscribe`) are designed to map 1:1 onto the tables in
`supabase/schema.sql`. Row-level security in that file is the real authorisation boundary;
`src/lib/auth.tsx` mirrors it for UX only.

## Deployment

The build is a single self-contained `dist/index.html`, so it can be dropped onto any static
host. Suggested memorable URLs:

- `https://benson-idahosa-university.vercel.app`
- `https://biu-benin-city.netlify.app`

After deploying, set `VITE_SITE_URL` and regenerate the sitemap so canonical URLs and the
Open Graph image resolve to absolute addresses.

## Accessibility & motion

- `prefers-reduced-motion` disables parallax, autoplay and all transitions.
- Semantic landmarks, skip link, visible focus rings, labelled controls, status is never
  communicated by colour alone.
- Tap-to-call telephone links and Google Maps direction links throughout.
