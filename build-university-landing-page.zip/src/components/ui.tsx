import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Link } from "../lib/router";

/* ------------------------------------------------------------------ Reveal */
export function Reveal({
  children,
  delay = 0,
  as: Tag = "div",
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  as?: "div" | "section" | "li" | "article" | "header" | "figure";
  className?: string;
}) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setInView(true);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <Tag
      // @ts-expect-error polymorphic ref
      ref={ref}
      className={`reveal ${inView ? "in" : ""} ${className}`}
      style={{ ["--d" as string]: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

/* ------------------------------------------------------------------ Button */
type BtnVariant = "primary" | "gold" | "outline" | "ghost-light" | "quiet";
export function Button({
  children,
  variant = "primary",
  className = "",
  ...rest
}: { variant?: BtnVariant } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const map: Record<BtnVariant, string> = {
    primary: "btn-primary",
    gold: "btn-gold",
    outline: "btn-outline",
    "ghost-light": "btn-ghost-light",
    quiet: "btn !normal-case !tracking-normal !text-[0.95rem] !font-medium !px-0 !py-1 text-royal-700 hover:text-royal-900",
  };
  return (
    <button className={`btn ${map[variant]} ${className}`} {...rest}>
      {children}
    </button>
  );
}

export function ButtonLink({
  children,
  to,
  variant = "primary",
  className = "",
  ...rest
}: { to: string; variant?: BtnVariant } & Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, "href">) {
  const map: Record<BtnVariant, string> = {
    primary: "btn-primary",
    gold: "btn-gold",
    outline: "btn-outline",
    "ghost-light": "btn-ghost-light",
    quiet: "btn !normal-case !tracking-normal !text-[0.95rem] !font-medium !px-0 !py-1 text-royal-700 hover:text-royal-900",
  };
  return (
    <Link to={to} className={`btn ${map[variant]} ${className}`} {...rest}>
      {children}
    </Link>
  );
}

/* --------------------------------------------------------- SectionHeading */
export function SectionHeading({
  label,
  title,
  intro,
  tone = "light",
  align = "left",
  action,
}: {
  label?: string;
  title: ReactNode;
  intro?: ReactNode;
  tone?: "light" | "dark";
  align?: "left" | "center";
  action?: ReactNode;
}) {
  const dark = tone === "dark";
  return (
    <div
      className={`flex flex-col gap-6 ${
        align === "center" ? "items-center text-center" : "md:flex-row md:items-end md:justify-between"
      }`}
    >
      <div className={align === "center" ? "max-w-2xl" : "max-w-3xl"}>
        {label && (
          <Reveal>
            <span className={`label ${dark ? "text-gold-400" : "text-royal-600"}`}>{label}</span>
          </Reveal>
        )}
        <Reveal delay={80}>
          <h2 className={`display-2 mt-4 ${dark ? "text-white" : "text-royal-900"}`}>{title}</h2>
        </Reveal>
        {intro && (
          <Reveal delay={160}>
            <p className={`lede mt-5 ${dark ? "text-white/70" : "text-ink/70"}`}>{intro}</p>
          </Reveal>
        )}
      </div>
      {action && <Reveal delay={220}>{action}</Reveal>}
    </div>
  );
}

/* ---------------------------------------------------------------- Statuses */
const APP_STATUS: Record<string, { label: string; cls: string }> = {
  draft: { label: "Draft", cls: "bg-royal-50 text-royal-700 border-royal-200" },
  submitted: { label: "Submitted", cls: "bg-royal-800 text-white border-royal-800" },
  under_review: { label: "Under review", cls: "bg-gold-500/15 text-gold-600 border-gold-500/40" },
  additional_information_required: { label: "Info required", cls: "bg-gold-500/15 text-gold-600 border-gold-500/40" },
  accepted: { label: "Accepted", cls: "bg-emerald-50 text-emerald-800 border-emerald-300" },
  rejected: { label: "Rejected", cls: "bg-red-50 text-red-800 border-red-300" },
  withdrawn: { label: "Withdrawn", cls: "bg-royal-50 text-royal-500 border-royal-200" },
};
export function StatusBadge({ status }: { status: string }) {
  const s = APP_STATUS[status] ?? { label: status, cls: "bg-royal-50 text-royal-700 border-royal-200" };
  return (
    <span className={`badge border ${s.cls}`}>
      <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-current" />
      {s.label}
    </span>
  );
}

export function Badge({ children, tone = "light" }: { children: ReactNode; tone?: "light" | "dark" | "gold" }) {
  const cls =
    tone === "dark"
      ? "border-white/25 text-white/80"
      : tone === "gold"
        ? "border-gold-500/40 text-gold-600"
        : "border-ink/15 text-ink/60";
  return <span className={`badge border ${cls}`}>{children}</span>;
}

/* ------------------------------------------------------- Loading skeletons */
export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`skeleton ${className}`} aria-hidden="true" />;
}
export function SkeletonText({ lines = 3, className = "" }: { lines?: number; className?: string }) {
  return (
    <div className={`space-y-2.5 ${className}`} role="status" aria-label="Loading">
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton key={i} className={`h-3.5 ${i === lines - 1 ? "w-2/3" : "w-full"}`} />
      ))}
    </div>
  );
}
export function SkeletonCard() {
  return (
    <div className="panel p-5">
      <Skeleton className="aspect-[16/10] w-full" />
      <Skeleton className="mt-5 h-3 w-24" />
      <Skeleton className="mt-3 h-5 w-3/4" />
      <Skeleton className="mt-3 h-3.5 w-full" />
    </div>
  );
}
export function SkeletonRows({ rows = 6 }: { rows?: number }) {
  return (
    <div className="divide-y divide-ink/10" role="status" aria-label="Loading">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 py-4">
          <Skeleton className="h-4 w-1/4" />
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="ml-auto h-6 w-20" />
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------ Empty / Error */
export function EmptyState({
  title,
  body,
  action,
  icon = "◇",
}: {
  title: string;
  body?: string;
  action?: ReactNode;
  icon?: string;
}) {
  return (
    <div className="panel flex flex-col items-center px-6 py-16 text-center">
      <span aria-hidden="true" className="font-display text-3xl text-royal-300">
        {icon}
      </span>
      <h3 className="display-3 mt-4 text-royal-900">{title}</h3>
      {body && <p className="mt-3 max-w-md text-ink/60">{body}</p>}
      {action && <div className="mt-7">{action}</div>}
    </div>
  );
}

export function ErrorState({ onRetry, message }: { onRetry?: () => void; message?: string }) {
  return (
    <div className="panel border-red-200 bg-red-50/60 px-6 py-12 text-center" role="alert">
      <h3 className="display-3 text-red-900">Something went wrong while loading this information.</h3>
      <p className="mx-auto mt-3 max-w-md text-red-900/70">
        {message ?? "Please try again. If the problem continues, contact the BIU ICT office."}
      </p>
      {onRetry && (
        <div className="mt-6">
          <Button variant="outline" onClick={onRetry}>
            Try again
          </Button>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------- Modal */
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    ref.current?.querySelector<HTMLElement>("button, input, a")?.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center p-0 sm:items-center sm:p-6">
      <div className="absolute inset-0 bg-royal-950/60 backdrop-blur-[2px]" onClick={onClose} aria-hidden="true" />
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="panel relative z-10 max-h-[92vh] w-full max-w-lg overflow-auto rounded-b-none sm:rounded-[4px]"
      >
        <div className="flex items-start justify-between gap-4 border-b border-ink/10 px-6 py-5">
          <h2 className="display-3 text-royal-900">{title}</h2>
          <button onClick={onClose} aria-label="Close dialog" className="text-ink/50 hover:text-royal-800">
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>
        <div className="px-6 py-6">{children}</div>
        {footer && <div className="border-t border-ink/10 px-6 py-4">{footer}</div>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------- Toast */
interface Toast {
  id: string;
  title: string;
  body?: string;
  tone: "success" | "error" | "info";
}
const ToastCtx = createContext<(t: Omit<Toast, "id">) => void>(() => {});
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((t: Omit<Toast, "id">) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 5200);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-[90] flex flex-col items-center gap-2 p-4 sm:items-end sm:p-6">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            className={`pointer-events-auto w-full max-w-sm border-l-2 bg-white px-5 py-4 shadow-[0_8px_30px_rgba(10,26,51,0.12)] ${
              t.tone === "success" ? "border-emerald-600" : t.tone === "error" ? "border-red-600" : "border-royal-600"
            }`}
          >
            <p className="text-sm font-semibold text-royal-900">{t.title}</p>
            {t.body && <p className="mt-1 text-sm text-ink/65">{t.body}</p>}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

/* ------------------------------------------------------------------- Forms */
export function Field({
  label,
  error,
  hint,
  required,
  children,
}: {
  label: string;
  error?: string;
  hint?: string;
  required?: boolean;
  children: (id: string) => ReactNode;
}) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="label text-ink/70">
        {label}
        {required && <span className="text-gold-600"> *</span>}
      </label>
      <div className="mt-2">{children(id)}</div>
      {hint && !error && <p className="mt-1.5 text-xs text-ink/50">{hint}</p>}
      {error && (
        <p className="mt-1.5 text-xs font-medium text-red-700" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export function Spinner({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={`spin h-4 w-4 ${className}`} aria-hidden="true">
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2.5" opacity="0.2" />
      <path d="M21 12a9 9 0 0 0-9-9" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

/* -------------------------------------------------------------- Pagination */
export function Pagination({
  page,
  pages,
  onChange,
}: {
  page: number;
  pages: number;
  onChange: (p: number) => void;
}) {
  if (pages <= 1) return null;
  return (
    <nav className="flex items-center justify-center gap-1.5" aria-label="Pagination">
      <Button variant="outline" onClick={() => onChange(page - 1)} disabled={page === 1} className="!px-3 !py-2">
        Prev
      </Button>
      <span className="px-3 text-sm text-ink/60">
        Page {page} of {pages}
      </span>
      <Button variant="outline" onClick={() => onChange(page + 1)} disabled={page === pages} className="!px-3 !py-2">
        Next
      </Button>
    </nav>
  );
}

/* --------------------------------------------------------------- DataTable */
export function DataTable<T>({
  columns,
  rows,
  keyOf,
  empty,
  actions,
}: {
  columns: { key: string; label: string; render: (row: T) => ReactNode; className?: string }[];
  rows: T[];
  keyOf: (row: T) => string;
  empty?: ReactNode;
  actions?: (row: T) => ReactNode;
}) {
  if (rows.length === 0 && empty) return <>{empty}</>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] text-left text-sm">
        <thead>
          <tr className="border-b border-ink/15">
            {columns.map((c) => (
              <th key={c.key} className={`label py-3 pr-4 text-ink/50 ${c.className ?? ""}`}>
                {c.label}
              </th>
            ))}
            {actions && <th className="label py-3 text-right text-ink/50">Actions</th>}
          </tr>
        </thead>
        <tbody className="divide-y divide-ink/10">
          {rows.map((r) => (
            <tr key={keyOf(r)} className="align-top transition-colors hover:bg-royal-50/60">
              {columns.map((c) => (
                <td key={c.key} className={`py-4 pr-4 ${c.className ?? ""}`}>
                  {c.render(r)}
                </td>
              ))}
              {actions && <td className="py-4 text-right whitespace-nowrap">{actions(r)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------------------------------------- Breadcrumbs */
export function Breadcrumbs({ items }: { items: { name: string; path?: string }[] }) {
  const list = useMemo(
    () => (
      <nav aria-label="Breadcrumb">
        <ol className="flex flex-wrap items-center gap-2 text-xs text-ink/50">
          {items.map((i, idx) => (
            <li key={i.name} className="flex items-center gap-2">
              {idx > 0 && <span aria-hidden="true">/</span>}
              {i.path ? (
                <Link to={i.path} className="hover:text-royal-700">
                  {i.name}
                </Link>
              ) : (
                <span aria-current="page" className="text-ink/70">
                  {i.name}
                </span>
              )}
            </li>
          ))}
        </ol>
      </nav>
    ),
    [items]
  );
  return list;
}

/* ------------------------------------------------------------ Page header */
export function PageHero({
  label,
  title,
  intro,
  crumb,
  aside,
}: {
  label: string;
  title: string;
  intro?: string;
  crumb?: { name: string; path?: string }[];
  aside?: ReactNode;
}) {
  return (
    <header className="relative overflow-hidden border-b border-ink/10 bg-royal-900 text-white">
      <div
        aria-hidden="true"
        className="absolute inset-0 opacity-[0.18]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgb(255 255 255 / 0.12) 1px, transparent 1px), linear-gradient(to bottom, rgb(255 255 255 / 0.12) 1px, transparent 1px)",
          backgroundSize: "72px 72px",
        }}
      />
      <div className="shell relative py-14 md:py-20">
        {crumb && (
          <div className="mb-8 text-white/50 [&_a]:text-white/70">
            <Breadcrumbs items={crumb} />
          </div>
        )}
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div className="max-w-3xl">
            <span className="label text-gold-400">{label}</span>
            <h1 className="display-1 mt-5 text-white">{title}</h1>
            {intro && <p className="lede mt-6 max-w-2xl text-white/70">{intro}</p>}
          </div>
          {aside && <div className="shrink-0">{aside}</div>}
        </div>
      </div>
    </header>
  );
}
