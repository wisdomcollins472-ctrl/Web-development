import { useEffect, useRef, useState } from "react";
import { Link, useRoute } from "../lib/router";
import { useAuth } from "../lib/auth";
import { CONTACT } from "../lib/cms";
import { LogoMark } from "./Brand";
import { Button } from "./ui";

interface MenuLink {
  label: string;
  to?: string;
  href?: string;
  note?: string;
}
interface MenuGroup {
  title: string;
  links: MenuLink[];
}
interface NavItem {
  label: string;
  to?: string;
  groups?: MenuGroup[];
  feature?: { title: string; body: string; to: string; cta: string };
}

const NAV: NavItem[] = [
  {
    label: "ABOUT",
    to: "/about",
    groups: [
      {
        title: "The University",
        links: [
          { label: "Our Story", to: "/about" },
          { label: "Vision & Mission", to: "/about?section=vision" },
          { label: "Leadership", to: "/about/leadership" },
          { label: "Governance", to: "/about?section=governance" },
          { label: "Accreditation", to: "/about?section=accreditation" },
          { label: "Strategic Plan", to: "/about?section=strategic-plan" },
        ],
      },
    ],
    feature: {
      title: "Named for Archbishop Benson Idahosa",
      body: "A Benin City minister whose name the university carries.",
      to: "/about",
      cta: "Our story",
    },
  },
  {
    label: "ACADEMICS",
    to: "/academics",
    groups: [
      {
        title: "Study",
        links: [
          { label: "Faculties", to: "/academics/faculties" },
          { label: "Departments", to: "/academics?section=departments" },
          { label: "Undergraduate", to: "/academics/programmes?level=undergraduate" },
          { label: "Postgraduate", to: "/academics/programmes?level=postgraduate" },
          { label: "Professional Programmes", to: "/academics/programmes?level=professional" },
        ],
      },
      {
        title: "Resources",
        links: [
          { label: "Programme Finder", to: "/academics/programmes" },
          { label: "Research", to: "/research" },
          { label: "Academic Calendar", to: "/documents?category=Calendars" },
          { label: "Document Centre", to: "/documents" },
        ],
      },
    ],
    feature: {
      title: "Find your programme",
      body: "Search by level, faculty and department.",
      to: "/academics/programmes",
      cta: "Open programme finder",
    },
  },
  {
    label: "ADMISSIONS",
    to: "/admissions",
    groups: [
      {
        title: "Apply",
        links: [
          { label: "Undergraduate", to: "/admissions?section=undergraduate" },
          { label: "Postgraduate", to: "/admissions?section=postgraduate" },
          { label: "Professional", to: "/admissions?section=professional" },
          { label: "How to Apply", to: "/admissions?section=how-to-apply" },
          { label: "Application Portal", to: "/apply" },
        ],
      },
      {
        title: "Information",
        links: [
          { label: "Requirements", to: "/admissions?section=requirements" },
          { label: "Fees", to: "/admissions?section=fees" },
          { label: "Scholarships", to: "/admissions?section=scholarships" },
          { label: "FAQs", to: "/admissions?section=faqs" },
        ],
      },
    ],
    feature: {
      title: "Your next chapter starts here",
      body: "Create an application, save your progress and track your status.",
      to: "/apply",
      cta: "Start your application",
    },
  },
  {
    label: "CAMPUS LIFE",
    to: "/campus-life",
    groups: [
      {
        title: "Student experience",
        links: [
          { label: "Accommodation", to: "/campus-life?category=Accommodation" },
          { label: "Student Affairs", to: "/campus-life?category=Student%20Affairs" },
          { label: "Sports", to: "/campus-life?category=Sports" },
          { label: "Clubs", to: "/campus-life?category=Clubs%20%26%20Societies" },
        ],
      },
      {
        title: "Wellbeing & community",
        links: [
          { label: "Chapel", to: "/campus-life?category=Chapel" },
          { label: "Health", to: "/campus-life?category=Health" },
          { label: "Dining", to: "/campus-life?category=Dining" },
          { label: "Events", to: "/events" },
        ],
      },
    ],
  },
  {
    label: "RESEARCH",
    to: "/research",
    groups: [
      {
        title: "Research",
        links: [
          { label: "Research Areas", to: "/research?section=areas" },
          { label: "Centres", to: "/research?section=centres" },
          { label: "Publications", to: "/research?section=publications" },
          { label: "Partnerships", to: "/research?section=partnerships" },
        ],
      },
      {
        title: "Newsroom",
        links: [
          { label: "News", to: "/news" },
          { label: "Events", to: "/events" },
          { label: "Announcements", to: "/news?section=announcements" },
        ],
      },
    ],
  },
  {
    label: "RESOURCES",
    groups: [
      {
        title: "Portals",
        links: [
          { label: "Student Portal", href: CONTACT.portal },
          { label: "Staff Portal", href: CONTACT.portal },
          { label: "CBT", href: CONTACT.portal },
          { label: "E-learning", href: CONTACT.portal },
          { label: "Library", href: CONTACT.website },
          { label: "Downloads", to: "/documents" },
        ],
      },
      {
        title: "Support",
        links: [
          { label: "Student Hub", to: "/student-hub" },
          { label: "Staff Hub", to: "/staff-hub" },
          { label: "Contact BIU", to: "/contact" },
        ],
      },
    ],
  },
];

function MenuLinkItem({ link, onNavigate }: { link: MenuLink; onNavigate: () => void }) {
  if (link.href) {
    return (
      <a
        href={link.href}
        target="_blank"
        rel="noopener noreferrer"
        onClick={onNavigate}
        className="group flex items-baseline justify-between gap-3 py-2 text-[0.95rem] text-ink/80 transition-colors hover:text-royal-800"
      >
        {link.label}
        <span aria-hidden="true" className="text-[0.7rem] text-ink/30 transition-transform group-hover:translate-x-0.5 group-hover:text-royal-600">
          ↗
        </span>
      </a>
    );
  }
  return (
    <Link
      to={link.to!}
      onClick={onNavigate}
      className="block py-2 text-[0.95rem] text-ink/80 transition-colors hover:text-royal-800"
    >
      {link.label}
    </Link>
  );
}

export default function Navbar({ onOpenSearch }: { onOpenSearch: () => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navRef = useRef<HTMLDivElement>(null);
  const { session } = useAuth();
  const { path } = useRoute();

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 24);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    setOpen(null);
    setMobileOpen(false);
  }, [path]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(null);
        setMobileOpen(false);
      }
    };
    const onClick = (e: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(e.target as Node)) setOpen(null);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onClick);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  const solid = scrolled || open !== null || mobileOpen;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-[70] transition-[background-color,box-shadow,border-color] duration-500 ${
        solid
          ? "border-b border-ink/10 bg-parchment/95 backdrop-blur-md supports-[backdrop-filter]:bg-parchment/85"
          : "border-b border-white/10 bg-transparent"
      }`}
    >
      {/* Utility strip */}
      <div
        className={`hidden overflow-hidden border-b border-white/10 text-[0.7rem] tracking-wide transition-all duration-500 lg:block ${
          solid ? "max-h-0 opacity-0" : "max-h-10 opacity-100"
        }`}
      >
        <div className="shell flex h-9 items-center justify-between text-white/70">
          <span>{CONTACT.hours.summary} · Benin City, Edo State</span>
          <div className="flex items-center gap-6">
            <a href={`tel:${CONTACT.phones[0].tel}`} className="hover:text-gold-400">
              {CONTACT.phones[0].display}
            </a>
            <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="hover:text-gold-400">
              biu.edu.ng ↗
            </a>
          </div>
        </div>
      </div>

      <div ref={navRef} className="shell flex items-center justify-between gap-4 py-3.5">
        <Link to="/" className="flex items-center gap-3" aria-label="Benson Idahosa University — home">
          <LogoMark className="h-9 w-9" />
          <span className={`leading-none ${solid ? "text-royal-900" : "text-white"}`}>
            <span className="block font-display text-[1.02rem] font-semibold tracking-tight">Benson Idahosa</span>
            <span className="mt-1 block text-[0.58rem] font-semibold tracking-[0.26em] opacity-70">UNIVERSITY</span>
          </span>
        </Link>

        {/* Desktop */}
        <nav aria-label="Primary" className="hidden items-center gap-1 xl:flex">
          {NAV.map((item) => {
            const isOpen = open === item.label;
            return (
              <div key={item.label} className="relative" onMouseEnter={() => setOpen(item.label)} onMouseLeave={() => setOpen(null)}>
                <button
                  className={`flex items-center gap-1.5 px-3.5 py-2 text-[0.78rem] font-semibold tracking-[0.12em] transition-colors ${
                    solid ? "text-royal-900 hover:text-royal-600" : "text-white hover:text-gold-300"
                  }`}
                  aria-expanded={isOpen}
                  onClick={() => setOpen(isOpen ? null : item.label)}
                  onFocus={() => setOpen(item.label)}
                >
                  {item.label}
                  {item.groups && (
                    <svg viewBox="0 0 24 24" className={`h-3 w-3 transition-transform ${isOpen ? "rotate-180" : ""}`} fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M6 9l6 6 6-6" />
                    </svg>
                  )}
                </button>

                {item.groups && isOpen && (
                  <div className="absolute left-0 top-full pt-3">
                    <div className="flex w-max max-w-[min(90vw,60rem)] gap-10 border border-ink/10 bg-white p-8 shadow-[0_24px_60px_rgba(10,26,51,0.14)]">
                      {item.groups.map((g) => (
                        <div key={g.title} className="min-w-[13rem]">
                          <p className="label text-ink/40">{g.title}</p>
                          <div className="mt-4 space-y-0.5">
                            {g.links.map((l) => (
                              <MenuLinkItem key={l.label} link={l} onNavigate={() => setOpen(null)} />
                            ))}
                          </div>
                        </div>
                      ))}
                      {item.feature && (
                        <div className="w-72 border-l border-ink/10 pl-8">
                          <p className="label text-gold-600">Highlight</p>
                          <p className="mt-4 font-display text-xl leading-snug text-royal-900">{item.feature.title}</p>
                          <p className="mt-2 text-sm text-ink/60">{item.feature.body}</p>
                          <Link
                            to={item.feature.to}
                            onClick={() => setOpen(null)}
                            className="link-editorial mt-5 inline-flex text-sm font-semibold text-royal-800"
                          >
                            {item.feature.cta} <span aria-hidden="true">→</span>
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSearch}
            className={`hidden items-center gap-2 border px-3.5 py-2 text-[0.72rem] font-semibold tracking-[0.14em] transition-colors md:inline-flex ${
              solid ? "border-ink/15 text-ink/60 hover:border-royal-700 hover:text-royal-800" : "border-white/25 text-white/80 hover:border-white"
            }`}
            aria-label="Search BIU"
          >
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="7" />
              <path d="M20 20l-3.5-3.5" />
            </svg>
            SEARCH BIU
          </button>
          <Link
            to="/student-hub"
            className={`hidden text-[0.78rem] font-semibold tracking-[0.1em] transition-colors lg:inline-flex ${
              solid ? "text-royal-900 hover:text-royal-600" : "text-white hover:text-gold-300"
            }`}
          >
            {session ? "MY PORTAL" : "STUDENT PORTAL"}
          </Link>
          <Link to="/apply" className="btn btn-gold !px-5 !py-2.5 hidden sm:inline-flex">
            Apply now
          </Link>
          <button
            className={`flex h-10 w-10 items-center justify-center border xl:hidden ${
              solid ? "border-ink/15 text-royal-900" : "border-white/25 text-white"
            }`}
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((o) => !o)}
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
              {mobileOpen ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 8h16M4 16h16" />}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-x-0 top-0 z-[69] h-[100svh] overflow-y-auto bg-parchment pt-24 xl:hidden">
          <nav aria-label="Mobile" className="shell pb-16">
            <button
              onClick={() => {
                setMobileOpen(false);
                onOpenSearch();
              }}
              className="mb-8 flex w-full items-center gap-3 border border-ink/15 px-4 py-3.5 text-left text-sm text-ink/50"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="7" />
                <path d="M20 20l-3.5-3.5" />
              </svg>
              Search BIU
            </button>
            <ul className="divide-y divide-ink/10">
              {NAV.map((item) => (
                <li key={item.label} className="py-1">
                  <Link
                    to={item.to ?? item.groups?.flatMap((g) => g.links).find((l) => l.to)?.to ?? "/"}
                    className="block py-3.5 font-display text-2xl text-royal-900"
                    onClick={() => setMobileOpen(false)}
                  >
                    {item.label}
                  </Link>
                  {item.groups && (
                    <ul className="mb-4 grid grid-cols-2 gap-x-4 gap-y-1 pb-2">
                      {item.groups.flatMap((g) => g.links).map((l) => (
                        <li key={l.label}>
                          {l.href ? (
                            <a href={l.href} target="_blank" rel="noopener noreferrer" className="block py-1.5 text-sm text-ink/65">
                              {l.label} ↗
                            </a>
                          ) : (
                            <Link to={l.to!} className="block py-1.5 text-sm text-ink/65" onClick={() => setMobileOpen(false)}>
                              {l.label}
                            </Link>
                          )}
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              ))}
            </ul>
            <div className="mt-10 grid gap-3">
              <Link to="/apply" className="btn btn-gold w-full" onClick={() => setMobileOpen(false)}>
                Apply now
              </Link>
              <Link to="/student-hub" className="btn btn-outline w-full" onClick={() => setMobileOpen(false)}>
                Student portal
              </Link>
            </div>
            <a href={`tel:${CONTACT.phones[0].tel}`} className="mt-8 block text-sm text-ink/60">
              Call {CONTACT.phones[0].display}
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

export { Button };
