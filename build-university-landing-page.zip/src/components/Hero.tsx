import { useEffect, useRef, useState } from "react";
import { Link } from "../lib/router";
import { usePrefersReducedMotion } from "../lib/hooks";

const HD = "https://videos.pexels.com/video-files/6145693/6145693-hd_1920_1080_24fps.mp4";
const UHD = "https://videos.pexels.com/video-files/6145693/6145693-uhd_3840_2160_24fps.mp4";
const POSTER = "https://images.pexels.com/videos/6145693/pexels-photo-6145693.jpeg?auto=compress&cs=tinysrgb&w=1920";
const FADE = 1.4;

/** Two stacked videos crossfade at the loop point → seamless loop, no hard cut. */
function CinematicVideo({ reduced, mobile }: { reduced: boolean; mobile: boolean }) {
  const refs = [useRef<HTMLVideoElement>(null), useRef<HTMLVideoElement>(null)];
  const cur = useRef(0);
  const [active, setActive] = useState(0);
  const [playing, setPlaying] = useState(!reduced && !mobile);
  // 1080p primary; transparently upgrade to the 4K rendition if it ever fails.
  const [src, setSrc] = useState(HD);

  useEffect(() => setPlaying(!reduced && !mobile), [reduced, mobile]);

  useEffect(() => {
    refs.forEach((r) => {
      if (r.current) r.current.load();
    });
  }, [src]);

  useEffect(() => {
    const vids = refs.map((r) => r.current!);
    const onTime = () => {
      const v = vids[cur.current];
      if (!v.duration || v.currentTime < v.duration - FADE) return;
      const next = 1 - cur.current;
      vids[next].currentTime = 0;
      vids[next].play().catch(() => {});
      cur.current = next;
      setActive(next);
    };
    vids.forEach((v) => v.addEventListener("timeupdate", onTime));
    return () => vids.forEach((v) => v.removeEventListener("timeupdate", onTime));
  }, []);

  useEffect(() => {
    let visible = true;
    const apply = () => {
      const v = refs[cur.current].current;
      if (!v) return;
      if (playing && visible) v.play().catch(() => {});
      else refs.forEach((r) => r.current?.pause());
    };
    const io = new IntersectionObserver(([e]) => {
      visible = e.isIntersecting;
      apply();
    });
    io.observe(refs[0].current!.parentElement!);
    apply();
    return () => io.disconnect();
  }, [playing]);

  return (
    <div className="absolute inset-0 overflow-hidden bg-royal-950">
      <img src={POSTER} alt="" className="absolute inset-0 h-full w-full scale-105 object-cover" fetchPriority="high" />
      {refs.map((ref, i) => (
        <video
          key={i}
          ref={ref}
          src={src}
          muted
          playsInline
          preload="auto"
          poster={POSTER}
          aria-hidden="true"
          autoPlay={i === 0 && !reduced && !mobile}
          onError={() => setSrc((s) => (s === HD ? UHD : s))}
          className="absolute inset-0 h-full w-full scale-105 object-cover transition-opacity ease-linear"
          style={{ opacity: active === i ? 1 : 0, transitionDuration: `${FADE}s` }}
        />
      ))}
      <button
        type="button"
        onClick={() => setPlaying((p) => !p)}
        className="absolute bottom-6 right-5 z-30 flex h-11 w-11 items-center justify-center rounded-full border border-white/30 bg-royal-950/40 text-white backdrop-blur transition hover:bg-royal-950/70 md:bottom-8 md:right-8"
        aria-label={playing ? "Pause background video" : "Play background video"}
      >
        {playing ? (
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
            <rect x="6" y="5" width="4" height="14" rx="1" />
            <rect x="14" y="5" width="4" height="14" rx="1" />
          </svg>
        ) : (
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        )}
      </button>
    </div>
  );
}

export default function Hero() {
  const reduced = usePrefersReducedMotion();
  const [mobile, setMobile] = useState(false);
  const heroRef = useRef<HTMLElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px)");
    const on = () => setMobile(mq.matches);
    on();
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);

  // Subtle transform-based parallax: backdrop drifts slower than the copy.
  useEffect(() => {
    if (reduced) return;
    let raf = 0;
    const update = () => {
      raf = 0;
      const y = window.scrollY;
      if (y > window.innerHeight * 1.2) return;
      setProgress(Math.min(1, y / (window.innerHeight * 0.9)));
      const media = heroRef.current?.querySelector<HTMLElement>("[data-hero-media]");
      const copy = heroRef.current?.querySelector<HTMLElement>("[data-hero-copy]");
      const front = heroRef.current?.querySelector<HTMLElement>("[data-hero-front]");
      if (media) media.style.transform = `translate3d(0, ${y * 0.28}px, 0) scale(1.06)`;
      if (copy) copy.style.transform = `translate3d(0, ${y * 0.1}px, 0)`;
      if (front) front.style.transform = `translate3d(0, ${y * -0.12}px, 0)`;
      if (heroRef.current) heroRef.current.style.setProperty("--p", String(Math.min(1, y / window.innerHeight)));
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
    };
  }, [reduced]);

  return (
    <section
      ref={heroRef}
      className="grain relative isolate flex min-h-[78svh] flex-col justify-end overflow-hidden bg-royal-950 text-white md:min-h-[88svh]"
      aria-label="Introduction"
    >
      <div data-hero-media className="parallax absolute inset-0 -z-10 will-change-transform">
        <CinematicVideo reduced={reduced} mobile={mobile} />
      </div>

      {/* Controlled contrast overlay */}
      <div
        aria-hidden="true"
        className="absolute inset-0 -z-10"
        style={{
          background:
            "linear-gradient(180deg, rgba(6,15,31,0.72) 0%, rgba(6,15,31,0.35) 32%, rgba(6,15,31,0.55) 68%, rgba(6,15,31,0.92) 100%)",
        }}
      />
      <div
        aria-hidden="true"
        className="absolute inset-0 -z-10 opacity-70"
        style={{ background: "radial-gradient(120% 80% at 15% 85%, rgba(10,26,51,0.9), transparent 60%)" }}
      />

      <div data-hero-copy className="shell relative pb-16 pt-40 md:pb-24 md:pt-48">
        <p className="rise label flex items-center gap-3 text-gold-400" style={{ ["--d" as string]: "120ms" }}>
          <span className="h-px w-10 bg-gold-400" />
          Benin City · Edo State · Nigeria
        </p>
        <h1
          className="rise display-1 mt-7 max-w-[15ch] text-white"
          style={{ ["--d" as string]: "240ms", opacity: 1 - progress * 0.55 }}
        >
          Where purpose becomes possibility.
        </h1>
        <p
          className="rise lede mt-8 max-w-xl text-white/75"
          style={{ ["--d" as string]: "400ms", opacity: 1 - progress * 0.75 }}
        >
          A university experience designed to develop academically excellent, professionally capable and purpose-driven
          leaders.
        </p>
        <div className="rise mt-11 flex flex-wrap items-center gap-3" style={{ ["--d" as string]: "540ms" }}>
          <Link to="/academics/programmes" className="btn btn-gold">
            Explore programmes
          </Link>
          <Link to="/apply" className="btn btn-ghost-light">
            Start your application
          </Link>
        </div>

        <dl className="rise mt-16 grid max-w-2xl grid-cols-3 gap-6 border-t border-white/15 pt-8" style={{ ["--d" as string]: "680ms" }}>
          {[
            ["Faculties", "Eight across arts, sciences, engineering, law, medicine and management"],
            ["Campus", "Ogogugbo, Benin City — Edo State"],
            ["Google rating", "4.2 from 180 reviews"],
          ].map(([k, v]) => (
            <div key={k}>
              <dt className="label text-white/45">{k}</dt>
              <dd className="mt-2 text-sm leading-snug text-white/75">{v}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="pointer-events-none absolute bottom-7 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-3 md:flex">
        <span className="label text-white/45">Scroll</span>
        <span className="relative block h-10 w-px overflow-hidden bg-white/20">
          <span className="scrollcue absolute left-0 top-0 h-4 w-px bg-gold-400" />
        </span>
      </div>

      {/* Depth 3 — nearest layer: a fine editorial rule that leads the scroll */}
      <div
        data-hero-front
        aria-hidden="true"
        className="pointer-events-none absolute right-6 top-1/2 z-10 hidden -translate-y-1/2 items-center gap-4 lg:flex"
      >
        <span className="h-24 w-px bg-gold-500/70" />
        <span className="label vertical-text text-white/45 [writing-mode:vertical-rl]">Benin City · Edo State</span>
      </div>
    </section>
  );
}
