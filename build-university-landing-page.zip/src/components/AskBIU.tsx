import { useEffect, useRef, useState } from "react";
import { Link } from "../lib/router";
import { CONTACT } from "../lib/cms";

/**
 * ASK BIU — institutional assistant.
 * Answers are retrieved ONLY from the verified knowledge base below. If a
 * question cannot be verified, the assistant says so and routes the visitor to
 * the appropriate BIU office. It never invents fees, requirements, deadlines,
 * rankings, policies or staff details.
 */

interface KbEntry {
  id: string;
  keywords: string[];
  answer: string;
  links?: { label: string; to: string }[];
}

const KB: KbEntry[] = [
  {
    id: "location",
    keywords: ["where", "location", "address", "find", "campus", "located", "directions", "map"],
    answer: `The campus is at ${CONTACT.addresses[0].lines.join(", ")}. The mailing address is ${CONTACT.addresses[1].lines.join(", ")}. Plus code: ${CONTACT.plusCode.code}.`,
    links: [{ label: "Open directions", to: "/contact" }],
  },
  {
    id: "contact",
    keywords: ["contact", "phone", "call", "email", "reach", "number"],
    answer: `Published telephone lines are ${CONTACT.phones.map((p) => `${p.label}: ${p.display}`).join(" and ")}. The official website is biu.edu.ng.`,
    links: [{ label: "Contact page", to: "/contact" }],
  },
  {
    id: "hours",
    keywords: ["hours", "open", "close", "closes", "when"],
    answer: `The public listing shows BIU as open, closing at ${CONTACT.hours.closes}. ${CONTACT.hours.note} For office hours, please call the main line.`,
    links: [{ label: "Visit information", to: "/contact" }],
  },
  {
    id: "admissions",
    keywords: ["admission", "apply", "application", "how to apply", "requirements", "entry"],
    answer:
      "Applications are made through the admissions process: choose a programme, create an application, complete your information, upload required documents and submit. Specific entry requirements are published per programme — open a programme page to see what is currently published, or contact the admissions office.",
    links: [
      { label: "How to apply", to: "/admissions" },
      { label: "Start application", to: "/apply" },
    ],
  },
  {
    id: "programmes",
    keywords: ["programme", "course", "study", "degree", "what can i study", "faculty", "department"],
    answer:
      "BIU's published faculties are Agriculture; Arts and Education; Basic and Applied Sciences; Basic Medical and Health Sciences; Engineering; Law; Social and Management Sciences; and the School of Postgraduate Studies. You can search every published programme in the programme finder.",
    links: [{ label: "Programme finder", to: "/academics/programmes" }],
  },
  {
    id: "portal",
    keywords: ["portal", "login", "student portal", "result", "cbt", "e-learning", "elearning", "library"],
    answer: "Student services such as the student portal, CBT and e-learning are accessed through BIU's existing systems. The published portal address is listed on the Student Hub.",
    links: [{ label: "Student Hub", to: "/student-hub" }],
  },
  {
    id: "fees",
    keywords: ["fee", "fees", "tuition", "cost", "payment", "how much", "scholarship"],
    answer:
      "Fee schedules and scholarship information change by session and programme, and are published by the university. I can't verify current figures here — please contact the admissions office or the official BIU website.",
    links: [{ label: "Admissions", to: "/admissions" }],
  },
  {
    id: "accreditation",
    keywords: ["accredit", "nuc", "recognised", "recognized", "approved", "licence", "license"],
    answer:
      "Accreditation and licensing status is published by the university and the National Universities Commission. I can't verify the current status from this assistant — please check biu.edu.ng or contact the university directly.",
    links: [{ label: "About BIU", to: "/about" }],
  },
  {
    id: "leadership",
    keywords: ["vice chancellor", "president", "chancellor", "leadership", "management", "who runs"],
    answer: "BIU's leadership directory lists the President, the Chancellor and the Vice Chancellor. Biographies and contact details are published where available.",
    links: [{ label: "Leadership", to: "/about/leadership" }],
  },
  {
    id: "reviews",
    keywords: ["review", "rating", "reviews", "reputation"],
    answer: `BIU holds a ${CONTACT.rating.value} rating from ${CONTACT.rating.count} reviews on its public listing. Selected visitor comments are quoted on the homepage and campus pages.`,
    links: [{ label: "Campus life", to: "/campus-life" }],
  },
  {
    id: "chapel",
    keywords: ["church", "chapel", "worship", "mountain of life", "faith"],
    answer:
      "Mountain of Life is listed as a church at this location. BIU is named in honour of Archbishop Benson Idahosa, a Charismatic Pentecostal minister from Benin City.",
    links: [{ label: "Campus life", to: "/campus-life" }],
  },
];

const REFUSAL =
  "I couldn't verify that information from the university's current published information. Please contact the appropriate BIU office.";

const QUICK = [
  { label: "Admissions", q: "How do I apply for admission?" },
  { label: "Programmes", q: "What programmes can I study?" },
  { label: "Fees", q: "What are the fees?" },
  { label: "Campus life", q: "What is campus life like?" },
  { label: "Application status", q: "How do I check my application status?" },
  { label: "Contact BIU", q: "How do I contact BIU?" },
];

interface Msg {
  id: string;
  role: "user" | "assistant";
  text: string;
  links?: { label: string; to: string }[];
  refused?: boolean;
}

function retrieve(question: string): KbEntry | null {
  const q = question.toLowerCase();
  let best: { entry: KbEntry; score: number } | null = null;
  for (const entry of KB) {
    let score = 0;
    for (const k of entry.keywords) if (q.includes(k)) score += k.length;
    if (score > 0 && (!best || score > best.score)) best = { entry, score };
  }
  return best?.entry ?? null;
}

export default function AskBIU() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [thinking, setThinking] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [messages, thinking]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    if (open) document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  const ask = (question: string) => {
    if (!question.trim()) return;
    setMessages((m) => [...m, { id: Math.random().toString(36), role: "user", text: question }]);
    setInput("");
    setThinking(true);
    const entry = retrieve(question);
    setTimeout(() => {
      setThinking(false);
      setMessages((m) => [
        ...m,
        entry
          ? { id: Math.random().toString(36), role: "assistant", text: entry.answer, links: entry.links }
          : { id: Math.random().toString(36), role: "assistant", text: REFUSAL, refused: true },
      ]);
    }, 520);
  };

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        className={`fixed bottom-5 right-5 z-[75] flex items-center gap-2.5 border px-4 py-3 text-[0.72rem] font-semibold tracking-[0.16em] shadow-[0_10px_30px_rgba(10,26,51,0.22)] transition-colors md:bottom-7 md:right-7 ${
          open ? "border-royal-800 bg-royal-800 text-white" : "border-royal-800/20 bg-white text-royal-900 hover:bg-royal-50"
        }`}
        aria-expanded={open}
        aria-controls="ask-biu-panel"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M21 12a8 8 0 0 1-8 8H7l-4 3v-5.5A8 8 0 0 1 12 4h1a8 8 0 0 1 8 8z" />
        </svg>
        ASK BIU
      </button>

      {open && (
        <div
          id="ask-biu-panel"
          role="dialog"
          aria-modal="false"
          aria-label="Ask BIU assistant"
          className="fixed inset-x-3 bottom-20 z-[76] flex max-h-[72svh] flex-col overflow-hidden border border-ink/10 bg-white shadow-[0_30px_80px_rgba(10,26,51,0.25)] sm:inset-x-auto sm:right-7 sm:bottom-24 sm:w-[26rem]"
        >
          <div className="flex items-start justify-between gap-4 border-b border-ink/10 bg-royal-900 px-5 py-4 text-white">
            <div>
              <p className="label text-gold-400">Ask BIU</p>
              <p className="mt-1.5 text-sm text-white/70">Answers drawn from verified university information only.</p>
            </div>
            <button onClick={() => setOpen(false)} aria-label="Close assistant" className="text-white/60 hover:text-white">
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>

          <div className="flex-1 space-y-4 overflow-y-auto px-5 py-5">
            {messages.length === 0 && (
              <>
                <p className="text-sm text-ink/65">
                  Ask about admissions, programmes, campus life or how to reach the university. If information can't be
                  verified, I'll say so.
                </p>
                <div className="flex flex-wrap gap-2">
                  {QUICK.map((q) => (
                    <button
                      key={q.label}
                      onClick={() => ask(q.q)}
                      className="border border-ink/15 px-3 py-1.5 text-xs font-semibold tracking-wide text-royal-800 transition-colors hover:border-royal-700 hover:bg-royal-50"
                    >
                      {q.label}
                    </button>
                  ))}
                </div>
              </>
            )}

            {messages.map((m) => (
              <div key={m.id} className={m.role === "user" ? "flex justify-end" : ""}>
                <div
                  className={
                    m.role === "user"
                      ? "max-w-[85%] bg-royal-900 px-4 py-2.5 text-sm text-white"
                      : `max-w-full border-l-2 px-4 py-3 text-sm leading-relaxed ${
                          m.refused ? "border-gold-500 bg-gold-500/8 text-ink/80" : "border-royal-700 bg-royal-50 text-ink/85"
                        }`
                  }
                >
                  {m.text}
                  {m.links && (
                    <div className="mt-3 flex flex-wrap gap-3">
                      {m.links.map((l) => (
                        <Link
                          key={l.label}
                          to={l.to}
                          onClick={() => setOpen(false)}
                          className="link-editorial text-xs font-semibold tracking-wide text-royal-800"
                        >
                          {l.label} →
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {thinking && (
              <div className="flex items-center gap-2 text-xs text-ink/45">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-royal-500" />
                Checking published information…
              </div>
            )}
            <div ref={endRef} />
          </div>

          <form
            className="flex items-center gap-2 border-t border-ink/10 px-4 py-3"
            onSubmit={(e) => {
              e.preventDefault();
              ask(input);
            }}
          >
            <label htmlFor="ask-biu-input" className="sr-only">
              Ask a question
            </label>
            <input
              id="ask-biu-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about BIU…"
              className="input !py-2.5"
            />
            <button type="submit" className="btn btn-primary !px-4 !py-2.5" aria-label="Send question">
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </button>
          </form>
        </div>
      )}
    </>
  );
}
