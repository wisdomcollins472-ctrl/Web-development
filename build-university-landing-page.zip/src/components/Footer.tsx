import { Link } from "../lib/router";
import { CONTACT } from "../lib/cms";
import { LogoMark } from "./Brand";

const COLUMNS: { title: string; links: { label: string; to?: string; href?: string }[] }[] = [
  {
    title: "Explore",
    links: [
      { label: "Academics", to: "/academics" },
      { label: "Faculties", to: "/academics/faculties" },
      { label: "Admissions", to: "/admissions" },
      { label: "Campus Life", to: "/campus-life" },
      { label: "Research", to: "/research" },
      { label: "News", to: "/news" },
    ],
  },
  {
    title: "Students",
    links: [
      { label: "Student Portal", href: CONTACT.portal },
      { label: "Student Hub", to: "/student-hub" },
      { label: "Documents", to: "/documents" },
      { label: "Support", to: "/contact" },
    ],
  },
  {
    title: "University",
    links: [
      { label: "About", to: "/about" },
      { label: "Leadership", to: "/about/leadership" },
      { label: "Staff Hub", to: "/staff-hub" },
      { label: "Contact", to: "/contact" },
    ],
  },
];

const SOCIAL = [
  { label: "Facebook", href: "https://www.facebook.com/BensonIdahosaUniversity" },
  { label: "Instagram", href: "https://www.instagram.com/bensonidahosauniversity" },
  { label: "X", href: "https://x.com" },
  { label: "LinkedIn", href: "https://www.linkedin.com" },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-royal-950 text-white">
      <div aria-hidden="true" className="absolute inset-0 opacity-[0.07]">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(to right, rgb(255 255 255 / 0.5) 1px, transparent 1px), linear-gradient(to bottom, rgb(255 255 255 / 0.5) 1px, transparent 1px)",
            backgroundSize: "96px 96px",
          }}
        />
      </div>

      <div className="shell relative">
        {/* Final CTA */}
        <div className="border-b border-white/10 py-20 md:py-28">
          <div className="flex flex-col gap-10 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="label text-gold-400">Admissions</p>
              <h2 className="display-2 mt-5 max-w-2xl text-white">Start your BIU journey.</h2>
              <p className="lede mt-6 max-w-lg text-white/65">
                Create an application, save your progress and submit when you are ready.
              </p>
            </div>
            <Link to="/apply" className="btn btn-gold shrink-0">
              Apply now
            </Link>
          </div>
        </div>

        {/* Links */}
        <div className="grid gap-12 py-16 md:grid-cols-12">
          <div className="md:col-span-4">
            <div className="flex items-center gap-3">
              <LogoMark className="h-10 w-10" />
              <span className="leading-none">
                <span className="block font-display text-lg">Benson Idahosa</span>
                <span className="mt-1 block text-[0.6rem] font-semibold tracking-[0.26em] text-white/60">UNIVERSITY</span>
              </span>
            </div>
            <address className="mt-7 space-y-4 text-sm not-italic text-white/65">
              {CONTACT.addresses.map((a) => (
                <div key={a.label}>
                  <span className="label block text-white/40">{a.label}</span>
                  <a href={a.href} target="_blank" rel="noopener noreferrer" className="link-editorial mt-1.5 inline-block text-white/80">
                    {a.lines.map((l) => (
                      <span key={l} className="block">
                        {l}
                      </span>
                    ))}
                  </a>
                </div>
              ))}
              <div>
                <span className="label block text-white/40">Telephone</span>
                {CONTACT.phones.map((p) => (
                  <a key={p.tel} href={`tel:${p.tel}`} className="link-editorial mt-1.5 block text-white/80">
                    {p.display}
                  </a>
                ))}
              </div>
            </address>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title} className="md:col-span-2">
              <h3 className="label text-white/40">{col.title}</h3>
              <ul className="mt-5 space-y-2.5 text-sm">
                {col.links.map((l) => (
                  <li key={l.label}>
                    {l.href ? (
                      <a href={l.href} target="_blank" rel="noopener noreferrer" className="link-editorial text-white/75 hover:text-white">
                        {l.label} ↗
                      </a>
                    ) : (
                      <Link to={l.to!} className="link-editorial text-white/75 hover:text-white">
                        {l.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div className="md:col-span-2">
            <h3 className="label text-white/40">Connect</h3>
            <ul className="mt-5 space-y-2.5 text-sm">
              {SOCIAL.map((s) => (
                <li key={s.label}>
                  <a href={s.href} target="_blank" rel="noopener noreferrer" className="link-editorial text-white/75 hover:text-white">
                    {s.label} ↗
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="flex flex-col gap-4 border-t border-white/10 py-8 text-xs text-white/45 md:flex-row md:items-center md:justify-between">
          <p>
            © {new Date().getFullYear()} Benson Idahosa University, Benin City, Edo State, Nigeria. Institutional
            information sourced from biu.edu.ng and the university's public listings.
          </p>
          <p className="flex flex-wrap items-center gap-x-4 gap-y-2">
            <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="hover:text-gold-400">
              biu.edu.ng ↗
            </a>
            <Link to="/contact" className="hover:text-gold-400">
              Contact
            </Link>
            <Link to="/admin" className="hover:text-gold-400">
              CMS
            </Link>
          </p>
        </div>
      </div>
    </footer>
  );
}
