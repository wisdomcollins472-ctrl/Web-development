import { Link } from "../lib/router";
import type { Faculty } from "../lib/cms";

/**
 * Editorial numbered faculty directory — not a card grid.
 * Hover reveals an image, shifts the title and animates the arrow.
 */
export default function FacultyList({ faculties }: { faculties: Faculty[] }) {
  if (faculties.length === 0) {
    return (
      <p className="rule py-10 text-ink/60">No faculties are published yet.</p>
    );
  }
  return (
    <ul className="relative">
      {faculties.map((f) => (
        <li key={f.id} className="rule group relative">
          <Link
            to={`/academics/faculties/${f.slug}`}
            className="faculty-row"
            aria-label={`${f.name} — view faculty`}
          >
            <span className="font-display text-lg text-ink/35 transition-colors group-hover:text-gold-600">{f.ordinal}</span>
            <span className="min-w-0">
              <span className="block font-display text-[clamp(1.5rem,3.4vw,2.75rem)] leading-tight text-royal-900 transition-colors group-hover:text-royal-700">
                {f.name}
              </span>
              <span className="mt-1.5 block text-sm text-ink/55">{f.summary}</span>
              {f.departments.length > 0 && (
                <span className="mt-3 hidden flex-wrap gap-x-3 gap-y-1 text-xs text-ink/45 md:flex">
                  {f.departments.slice(0, 4).map((d) => (
                    <span key={d}>{d}</span>
                  ))}
                  {f.departments.length > 4 && <span>+{f.departments.length - 4} more</span>}
                </span>
              )}
            </span>
            <span className="flex items-center gap-4">
              <span className="hidden text-xs text-ink/40 sm:block">{f.departments.length} departments</span>
              <span
                aria-hidden="true"
                className="flex h-11 w-11 items-center justify-center border border-ink/15 text-royal-900 transition-all duration-500 group-hover:border-royal-800 group-hover:bg-royal-800 group-hover:text-white"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M5 12h14M13 6l6 6-6 6" />
                </svg>
              </span>
            </span>
            <img
              src={f.image}
              alt=""
              loading="lazy"
              decoding="async"
              className="faculty-img hidden lg:block"
              aria-hidden="true"
            />
          </Link>
        </li>
      ))}
    </ul>
  );
}
