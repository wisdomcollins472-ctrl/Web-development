import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "../lib/router";
import { db, LEVEL_LABEL, type Programme } from "../lib/cms";
import { SkeletonRows } from "./ui";

interface Hit {
  group: string;
  label: string;
  sub?: string;
  to: string;
}

export default function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState("");
  const [programmes, setProgrammes] = useState<Programme[] | null>(null);
  const [faculties, setFaculties] = useState<{ slug: string; name: string }[] | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQ("");
      const t = setTimeout(() => inputRef.current?.focus(), 40);
      return () => clearTimeout(t);
    }
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    if (open) document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) return;
    let alive = true;
    Promise.all([db.programmes(), db.faculties()]).then(([p, f]) => {
      if (!alive) return;
      setProgrammes(p);
      setFaculties(f.map((x) => ({ slug: x.slug, name: x.name })));
    });
    return () => {
      alive = false;
    };
  }, [open]);

  const hits = useMemo<Hit[]>(() => {
    const term = q.trim().toLowerCase();
    const staticHits: Hit[] = [
      { group: "Pages", label: "Faculties", to: "/academics/faculties" },
      { group: "Pages", label: "Programme Finder", to: "/academics/programmes" },
      { group: "Pages", label: "Admissions & How to Apply", to: "/admissions" },
      { group: "Pages", label: "Campus Life", to: "/campus-life" },
      { group: "Pages", label: "Research", to: "/research" },
      { group: "Pages", label: "News", to: "/news" },
      { group: "Pages", label: "Events", to: "/events" },
      { group: "Pages", label: "Documents", to: "/documents" },
      { group: "Pages", label: "Contact BIU", to: "/contact" },
      { group: "Pages", label: "Leadership", to: "/about/leadership" },
    ];
    const out: Hit[] = [];
    if (faculties) {
      out.push(
        ...faculties
          .filter((f) => !term || f.name.toLowerCase().includes(term))
          .map((f) => ({ group: "Faculties", label: f.name, to: `/academics/faculties/${f.slug}` }))
      );
    }
    if (programmes) {
      out.push(
        ...programmes
          .filter((p) => !term || `${p.title} ${p.department} ${p.award}`.toLowerCase().includes(term))
          .slice(0, 12)
          .map((p) => ({
            group: "Programmes",
            label: p.title,
            sub: `${p.award} · ${LEVEL_LABEL[p.level]} · ${p.department}`,
            to: `/academics/programmes/${p.slug}`,
          }))
      );
    }
    const pages = staticHits.filter((h) => !term || h.label.toLowerCase().includes(term));
    return [...out, ...pages];
  }, [q, programmes, faculties]);

  const grouped = useMemo(() => {
    const map = new Map<string, Hit[]>();
    hits.forEach((h) => map.set(h.group, [...(map.get(h.group) ?? []), h]));
    return [...map.entries()];
  }, [hits]);

  if (!open) return null;
  const loading = !programmes || !faculties;

  return (
    <div className="fixed inset-0 z-[85] flex items-start justify-center px-4 pt-24 pb-8 sm:pt-32">
      <div className="absolute inset-0 bg-royal-950/70 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Search BIU"
        className="relative z-10 flex max-h-[80svh] w-full max-w-2xl flex-col overflow-hidden border border-ink/10 bg-white"
      >
        <div className="flex items-center gap-3 border-b border-ink/10 px-5 py-4">
          <svg viewBox="0 0 24 24" className="h-5 w-5 text-ink/40" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="11" cy="11" r="7" />
            <path d="M20 20l-3.5-3.5" />
          </svg>
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search programmes, faculties, pages…"
            aria-label="Search query"
            className="w-full bg-transparent text-lg outline-none placeholder:text-ink/35"
          />
          <button onClick={onClose} className="label border border-ink/15 px-2.5 py-1.5 text-ink/50 hover:text-royal-800">
            ESC
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {loading ? (
            <SkeletonRows rows={5} />
          ) : grouped.length === 0 ? (
            <div className="py-14 text-center">
              <p className="display-3 text-royal-900">No results for “{q}”.</p>
              <p className="mt-3 text-sm text-ink/60">Try a faculty, programme or page name.</p>
            </div>
          ) : (
            <div className="space-y-7">
              {grouped.map(([group, items]) => (
                <div key={group}>
                  <p className="label text-ink/40">{group}</p>
                  <ul className="mt-2 divide-y divide-ink/8">
                    {items.map((h) => (
                      <li key={`${group}-${h.label}-${h.to}`}>
                        <Link
                          to={h.to}
                          onClick={onClose}
                          className="flex items-center justify-between gap-4 py-3 transition-colors hover:text-royal-700"
                        >
                          <span>
                            <span className="block text-[0.98rem]">{h.label}</span>
                            {h.sub && <span className="mt-0.5 block text-xs text-ink/50">{h.sub}</span>}
                          </span>
                          <span aria-hidden="true" className="text-ink/30">
                            →
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
