export function LogoMark({ className = "h-10 w-10" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <rect width="64" height="64" rx="14" fill="#0e2a20" />
      <g fill="none" stroke="#e0a847" strokeWidth="2.6" strokeLinecap="round">
        <path d="M32 14v6M20.5 18.5l3.6 4.6M43.5 18.5l-3.6 4.6M14 28.5l5.5 2M50 28.5l-5.5 2" />
      </g>
      <path
        d="M32 30c-5.8-3.6-11.6-4.4-17-3.4v19.2c5.4-1 11.2-.2 17 3.4 5.8-3.6 11.6-4.4 17-3.4V26.6c-5.4-1-11.2-.2-17 3.4z"
        fill="#f5eedf"
      />
      <path d="M32 30v19.2" stroke="#b5532b" strokeWidth="2.4" />
    </svg>
  );
}

export function Wordmark({ light = false }: { light?: boolean }) {
  return (
    <span className="flex items-center gap-3">
      <LogoMark className="h-10 w-10 shrink-0 ring-1 ring-gold/40 rounded-[14px]" />
      <span className={`leading-none ${light ? "text-parchment" : "text-forest"}`}>
        <span className="block font-display text-[1.05rem] font-semibold tracking-tight">
          Benson Idahosa
        </span>
        <span className="block text-[0.62rem] font-semibold uppercase tracking-[0.28em] opacity-70 mt-1">
          University · Benin City
        </span>
      </span>
    </span>
  );
}

const LEAF =
  "M0 0C18 -6 44 -4 62 12C80 28 86 52 80 78C62 74 38 66 22 50C6 34 -2 16 0 0Z";

/** Canopy silhouette used as the near-foreground parallax layer. */
export function Canopy({ className = "", color = "#0e2a20" }: { className?: string; color?: string }) {
  const leaves = [
    { x: 10, y: 0, r: 20, s: 1.6 },
    { x: 80, y: -10, r: 60, s: 1.9 },
    { x: 150, y: 10, r: 100, s: 1.4 },
    { x: 40, y: 60, r: 150, s: 1.2 },
    { x: 210, y: -20, r: 40, s: 1.3 },
    { x: 0, y: 120, r: 190, s: 1.5 },
    { x: 120, y: 90, r: 80, s: 1 },
  ];
  return (
    <svg viewBox="0 0 320 300" className={className} aria-hidden="true" preserveAspectRatio="xMinYMin meet">
      <path d="M-10 -10 Q120 40 300 -10" stroke={color} strokeWidth="6" fill="none" />
      <path d="M-10 60 Q60 60 150 20" stroke={color} strokeWidth="4" fill="none" />
      {leaves.map((l, i) => (
        <path
          key={i}
          d={LEAF}
          fill={color}
          transform={`translate(${l.x} ${l.y}) rotate(${l.r}) scale(${l.s})`}
          opacity={0.92}
        />
      ))}
    </svg>
  );
}
