import { useEffect, useMemo, useState } from "react";
import { Link } from "../lib/router";
import { db, LEVEL_LABEL, LEVELS, type Level, type Programme } from "../lib/cms";
import { Button, EmptyState, ErrorState, SkeletonCard } from "./ui";

const LEVEL_TABS: { value: Level | "all"; label: string }[] = [
  { value: "all", label: "All levels" },
  ...LEVELS,
];

export default function ProgrammeFinder({
  initialLevel = "all",
  headingLevel = "h2",
}: {
  initialLevel?: Level | "all";
  headingLevel?: "h2" | "h3";
}) {
  const [q, setQ] = useState("");
  const [level, setLevel] = useState<Level | "all">(initialLevel);
  const [faculty, setFaculty] = useState("all");
  const [department, setDepartment] = useState("all");
  const [programmes, setProgrammes] = useState<Programme[] | null>(null);
  const [faculties, setFaculties] = useState<{ slug: string; name: string }[]>([]);
  const [departments, setDepartments] = useState<string[]>([]);
  const [error, setError] = useState(false);
  const [nonce, setNonce] = useState(0);

  // Catalogue metadata (faculties + departments) — loaded once.
  useEffect(() => {
    let alive = true;
    Promise.all([db.allFaculties(), db.programmes()])
      .then(([f, p]) => {
        if (!alive) return;
        setFaculties(f.map((x) => ({ slug: x.slug, name: x.name })));
        setDepartments([...new Set(p.map((x) => x.department))].sort());
      })
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [nonce]);

  // Results — debounced search against the database layer.
  useEffect(() => {
    let alive = true;
    setProgrammes(null);
    const t = setTimeout(() => {
      db
        .programmes({ q, level, faculty, department })
        .then((p) => alive && setProgrammes(p))
        .catch(() => alive && setError(true));
    }, 220);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [q, level, faculty, department, nonce]);

  const count = useMemo(() => programmes?.length ?? 0, [programmes]);
  const H = headingLevel;

  return (
    <div>
      {/* Controls */}
      <div className="panel p-5 md:p-7">
        <div className="grid gap-5 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <label htmlFor="pf-q" className="label text-ink/60">
              What do you want to study?
            </label>
            <div className="relative mt-2">
              <svg viewBox="0 0 24 24" className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/35" fill="none" stroke="currentColor" strokeWidth="1.8">
                <circle cx="11" cy="11" r="7" />
                <path d="M20 20l-3.5-3.5" />
              </svg>
              <input
                id="pf-q"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="e.g. engineering, law, nursing"
                className="input !pl-10"
                type="search"
              />
            </div>
          </div>

          <div className="lg:col-span-3">
            <label htmlFor="pf-faculty" className="label text-ink/60">
              Faculty
            </label>
            <select id="pf-faculty" className="input mt-2" value={faculty} onChange={(e) => setFaculty(e.target.value)}>
              <option value="all">All faculties</option>
              {faculties.map((f) => (
                <option key={f.slug} value={f.slug}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>

          <div className="lg:col-span-2">
            <label htmlFor="pf-dept" className="label text-ink/60">
              Department
            </label>
            <select id="pf-dept" className="input mt-2" value={department} onChange={(e) => setDepartment(e.target.value)}>
              <option value="all">All</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-end lg:col-span-2">
            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                setQ("");
                setLevel("all");
                setFaculty("all");
                setDepartment("all");
                setNonce((n) => n + 1);
              }}
            >
              Reset
            </Button>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-ink/10 pt-5" role="group" aria-label="Filter by level">
          {LEVEL_TABS.map((t) => (
            <button
              key={t.value}
              onClick={() => setLevel(t.value)}
              aria-pressed={level === t.value}
              className={`border px-3.5 py-2 text-xs font-semibold tracking-[0.1em] transition-colors ${
                level === t.value
                  ? "border-royal-800 bg-royal-800 text-white"
                  : "border-ink/15 text-ink/60 hover:border-royal-700 hover:text-royal-800"
              }`}
            >
              {t.label.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="mt-8">
        <div className="flex items-baseline justify-between">
          <p className="label text-ink/45" aria-live="polite">
            {programmes ? `${count} programme${count === 1 ? "" : "s"}` : "Loading…"}
          </p>
          <Link to="/academics/faculties" className="link-editorial text-sm text-royal-800">
            Browse by faculty →
          </Link>
        </div>

        {error ? (
          <div className="mt-5">
            <ErrorState onRetry={() => setNonce((n) => n + 1)} />
          </div>
        ) : !programmes ? (
          <div className="mt-5 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        ) : count === 0 ? (
          <div className="mt-5">
            <EmptyState
              title="No programmes match your search."
              body="Try a broader search term, or reset the filters to see every published programme."
              action={
                <Button
                  variant="outline"
                  onClick={() => {
                    setQ("");
                    setLevel("all");
                    setFaculty("all");
                    setDepartment("all");
                  }}
                >
                  Reset filters
                </Button>
              }
            />
          </div>
        ) : (
          <ul className="mt-5 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {programmes.map((p) => (
              <li key={p.id}>
                <Link
                  to={`/academics/programmes/${p.slug}`}
                  className="panel group flex h-full flex-col p-6 transition-[border-color,transform] duration-500 hover:-translate-y-0.5 hover:border-royal-300"
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="label text-royal-600">{LEVEL_LABEL[p.level]}</span>
                    {p.award && <span className="label text-ink/40">{p.award}</span>}
                  </div>
                  <H className="mt-4 font-display text-2xl leading-snug text-royal-900 group-hover:text-royal-700">{p.title}</H>
                  <p className="mt-2 text-sm text-ink/55">{p.department}</p>
                  <p className="mt-auto pt-6 text-sm font-semibold text-royal-800">
                    View programme <span aria-hidden="true" className="inline-block transition-transform group-hover:translate-x-1">→</span>
                  </p>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
