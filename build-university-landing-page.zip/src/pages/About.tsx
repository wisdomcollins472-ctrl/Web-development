import { Link } from "../lib/router";
import { useSeo, breadcrumbLd } from "../lib/seo";
import { CONTACT, LEADERS, REVIEWS } from "../lib/cms";
import { PageHero, Reveal, SectionHeading } from "../components/ui";
import { useSectionScroll } from "../lib/router";

function initials(name: string) {
  return name
    .replace(/(Prof\.|Archbishop|Bishop|Dr\.|Mr\.|Mrs\.)\s*/gi, "")
    .split(" ")
    .slice(0, 2)
    .map((p) => p[0])
    .join("");
}

const VISION = [
  ["Vision", "The university's vision and mission statements are published by the institution. They appear here once confirmed by the university."],
  ["Mission", "Mission wording is an editable CMS field — it is not inferred or paraphrased from other sources."],
];

export default function About() {
  useSectionScroll();
  useSeo({
    title: "About BIU — Our Story, Vision & Leadership | Benson Idahosa University",
    description:
      "Benson Idahosa University: institutional overview, vision and mission, governance and the leadership directory.",
    path: "/about",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "About", path: "/about" },
    ]),
  });

  return (
    <>
      <PageHero
        label="About"
        title="A university named for a purpose."
        intro="Benson Idahosa University is located in Ogogugbo, Benin City, Edo State. This page sets out only what the university publishes about itself."
        crumb={[{ name: "Home", path: "/" }, { name: "About" }]}
      />

      {/* Our story */}
      <section className="border-b border-ink/10 bg-white py-20 md:py-24">
        <div className="shell grid gap-14 md:grid-cols-12 md:gap-20">
          <div className="md:col-span-7">
            <Reveal>
              <span className="label text-royal-600">Our story</span>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="display-2 mt-4 text-royal-900">From Christian Faith University to BIU.</h2>
            </Reveal>
            <Reveal delay={140}>
              <div className="mt-7 space-y-5 leading-relaxed text-ink/70">
                <p className="lede">
                  The institution was previously named Christian Faith University. It was renamed in honour of Archbishop
                  Benson Idahosa, a Charismatic Pentecostal minister from Benin City, Nigeria.
                </p>
                <p>
                  Today the university teaches across eight faculties at its Benin City campuses, with a campus on Agboma
                  Street in Ogogugbo and a further Legacy Campus in the city.
                </p>
                <p>
                  Dates of foundation, enrolment figures, convocation history and accreditation milestones are published
                  by the university. They are not reproduced here unless they can be verified from the university's own
                  published information.
                </p>
              </div>
            </Reveal>
            <Reveal delay={200}>
              <figure className="mt-10 border-l-2 border-gold-500 bg-gold-500/8 px-6 py-5">
                <blockquote className="font-display text-xl leading-snug text-royal-900">“{REVIEWS[2].quote}”</blockquote>
                <figcaption className="mt-4 text-xs text-ink/50">{REVIEWS[2].name} · Google review</figcaption>
              </figure>
            </Reveal>
          </div>
          <div className="md:col-span-5">
            <Reveal delay={120}>
              <div className="aspect-[4/5] overflow-hidden bg-royal-900">
                <img
                  src="/images/campus.jpg"
                  alt="BIU campus buildings at dusk (illustrative)"
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
            </Reveal>
            <Reveal delay={200}>
              <dl className="mt-8 space-y-6">
                <div>
                  <dt className="label text-ink/45">Location</dt>
                  <dd className="mt-1.5 text-royal-900">Ogogugbo, Benin City, Edo State, Nigeria</dd>
                </div>
                <div>
                  <dt className="label text-ink/45">Mailing address</dt>
                  <dd className="mt-1.5 text-royal-900">{CONTACT.addresses[1].lines.join(", ")}</dd>
                </div>
                <div>
                  <dt className="label text-ink/45">Official website</dt>
                  <dd className="mt-1.5">
                    <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="link-editorial text-royal-800">
                      biu.edu.ng ↗
                    </a>
                  </dd>
                </div>
              </dl>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Vision & mission / governance / accreditation / strategic plan */}
      <section className="py-20 md:py-24">
        <div className="shell">
          <SectionHeading
            label="Vision & mission"
            title="What guides the university."
            intro="Institutional statements are published by the university and are reproduced verbatim here — never paraphrased or inferred."
          />
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {VISION.map(([title, body], i) => (
              <Reveal key={title} delay={i * 100}>
                <div id={i === 0 ? "vision" : "mission"} className="panel h-full scroll-mt-28 p-7">
                  <h3 className="font-display text-2xl text-royal-900">{title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-ink/65">{body}</p>
                  <span className="badge mt-5 border-ink/15 text-ink/50">CMS field</span>
                </div>
              </Reveal>
            ))}
            <Reveal delay={200}>
              <div id="governance" className="panel h-full scroll-mt-28 p-7">
                <h3 className="font-display text-2xl text-royal-900">Governance</h3>
                <p className="mt-3 text-sm leading-relaxed text-ink/65">
                  Governing council, senate and committee structures are published by the university. This section is an
                  editable CMS structure until that information is confirmed.
                </p>
                <span className="badge mt-5 border-ink/15 text-ink/50">CMS structure</span>
              </div>
            </Reveal>
            <Reveal delay={260}>
              <div id="accreditation" className="panel h-full scroll-mt-28 p-7">
                <h3 className="font-display text-2xl text-royal-900">Accreditation</h3>
                <p className="mt-3 text-sm leading-relaxed text-ink/65">
                  Programme and institutional accreditation status is published by the university and the National
                  Universities Commission. Ask BIU does not assert accreditation status.
                </p>
                <span className="badge mt-5 border-ink/15 text-ink/50">CMS structure</span>
              </div>
            </Reveal>
            <Reveal delay={320}>
              <div id="strategic-plan" className="panel h-full scroll-mt-28 p-7">
                <h3 className="font-display text-2xl text-royal-900">Strategic plan</h3>
                <p className="mt-3 text-sm leading-relaxed text-ink/65">
                  Strategic plan documents are published in the document centre when the university releases them.
                </p>
                <span className="badge mt-5 border-ink/15 text-ink/50">CMS structure</span>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="border-t border-ink/10 bg-white py-20 md:py-24">
        <div className="shell">
          <SectionHeading
            label="Leadership"
            title="University leadership."
            intro="Office holders as published by the university. Biographies and contact details appear where the university publishes them."
            action={
              <Link to="/about/leadership" className="btn btn-outline">
                Full directory
              </Link>
            }
          />
          <ul className="mt-12 grid gap-px bg-ink/10 sm:grid-cols-3">
            {LEADERS.map((l, i) => (
              <li key={l.id} className="bg-parchment">
                <Reveal delay={i * 100}>
                  <div className="h-full p-7">
                    <span
                      aria-hidden="true"
                      className="flex h-16 w-16 items-center justify-center rounded-full border border-royal-200 bg-white font-display text-xl text-royal-800"
                    >
                      {initials(l.name)}
                    </span>
                    <h3 className="mt-5 font-display text-2xl leading-snug text-royal-900">{l.name}</h3>
                    <p className="mt-1.5 text-sm font-medium text-gold-600">{l.role}</p>
                    <p className="mt-4 text-sm text-ink/55">{l.office}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  );
}

/* ------------------------------------------------------- leadership page */
export function Leadership() {
  useSeo({
    title: "Leadership Directory | Benson Idahosa University",
    description: "Office holders at Benson Idahosa University: President, Chancellor and Vice Chancellor.",
    path: "/about/leadership",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "About", path: "/about" },
      { name: "Leadership", path: "/about/leadership" },
    ]),
  });

  return (
    <>
      <PageHero
        label="Leadership"
        title="Leadership directory."
        intro="Office holders published by the university. Individual biographies, offices and contact details are added as the university publishes them."
        crumb={[{ name: "Home", path: "/" }, { name: "About", path: "/about" }, { name: "Leadership" }]}
      />
      <section className="shell py-20">
        <ul className="grid gap-px bg-ink/10 sm:grid-cols-2 lg:grid-cols-3">
          {LEADERS.map((l, i) => (
            <li key={l.id} className="bg-parchment">
              <Reveal delay={i * 90}>
                <article className="h-full p-8">
                  <span
                    aria-hidden="true"
                    className="flex h-20 w-20 items-center justify-center rounded-full border border-royal-200 bg-white font-display text-2xl text-royal-800"
                  >
                    {initials(l.name)}
                  </span>
                  <h2 className="mt-6 font-display text-3xl leading-snug text-royal-900">{l.name}</h2>
                  <p className="mt-2 text-sm font-semibold text-gold-600">{l.role}</p>
                  <p className="mt-4 text-sm text-ink/60">{l.office}</p>
                  {l.bio ? (
                    <p className="mt-5 leading-relaxed text-ink/70">{l.bio}</p>
                  ) : (
                    <p className="mt-5 border-l-2 border-gold-500 bg-gold-500/8 px-4 py-3 text-sm text-ink/70">
                      Biography not yet published — editable CMS field.
                    </p>
                  )}
                  {l.email && (
                    <a href={`mailto:${l.email}`} className="link-editorial mt-5 inline-flex text-sm font-semibold text-royal-800">
                      {l.email}
                    </a>
                  )}
                </article>
              </Reveal>
            </li>
          ))}
        </ul>
        <p className="mt-10 text-sm text-ink/50">
          Office holders are listed from published university sources. If a detail is not shown here, it has not been
          published rather than omitted.
        </p>
      </section>
    </>
  );
}
