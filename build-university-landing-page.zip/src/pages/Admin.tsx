import { useEffect, useMemo, useState } from "react";
import { Link } from "../lib/router";
import { useSeo } from "../lib/seo";
import {
  admin,
  db,
  getStore,
  subscribe,
  slugify,
  uid,
  NEWS_CATEGORIES,
  DOC_CATEGORIES,
  type Announcement,
  type Application,
  type DocItem,
  type Enquiry,
  type EventItem,
  type Faculty,
  type NewsItem,
  type Programme,
  type AuditEntry,
} from "../lib/cms";
import { PERMISSIONS, ROLES, useAuth } from "../lib/auth";
import {
  Button,
  DataTable,
  EmptyState,
  Field,
  Modal,
  Pagination,
  Reveal,
  Spinner,
  StatusBadge,
  useToast,
} from "../components/ui";

const SECTIONS = [
  { id: "dashboard", label: "Dashboard", perm: "content.read" },
  { id: "applications", label: "Applications", perm: "applications.read" },
  { id: "enquiries", label: "Enquiries", perm: "enquiries.read" },
  { id: "programmes", label: "Programmes", perm: "content.read" },
  { id: "faculties", label: "Faculties", perm: "content.read" },
  { id: "news", label: "News", perm: "content.read" },
  { id: "events", label: "Events", perm: "content.read" },
  { id: "announcements", label: "Announcements", perm: "content.read" },
  { id: "documents", label: "Documents", perm: "content.read" },
  { id: "users", label: "Users & Roles", perm: "users.read" },
  { id: "audit", label: "Audit Log", perm: "audit.read" },
  { id: "settings", label: "Site Settings", perm: "content.read" },
] as const;

type SectionId = (typeof SECTIONS)[number]["id"];

/* ------------------------------------------------------------------ shells */
function StatCard({ label, value, note }: { label: string; value: string | number; note?: string }) {
  return (
    <div className="panel p-6">
      <p className="label text-ink/45">{label}</p>
      <p className="mt-3 font-display text-4xl text-royal-900">{value}</p>
      {note && <p className="mt-2 text-xs text-ink/50">{note}</p>}
    </div>
  );
}

function EditorShell({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h2 className="display-3 text-royal-900">{title}</h2>
      <p className="mt-2 max-w-2xl text-sm text-ink/60">{description}</p>
      <div className="mt-8">{children}</div>
    </div>
  );
}

/* --------------------------------------------------------------- dashboard */
function Dashboard() {
  const [store, setStore] = useState(getStore());
  useEffect(() => subscribe(() => setStore(getStore())), []);
  const apps = store.applications;
  const submitted = apps.filter((a) => a.status !== "draft").length;
  const pending = apps.filter((a) => a.status === "submitted" || a.status === "under_review").length;

  return (
    <EditorShell title="Dashboard" description="An overview of admissions activity and published content.">
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Applications" value={apps.length} note={`${submitted} submitted`} />
        <StatCard label="Awaiting review" value={pending} note="Submitted or under review" />
        <StatCard label="New enquiries" value={store.enquiries.filter((e) => e.status === "new").length} note="Contact form submissions" />
        <StatCard label="Published news" value={store.news.filter((n) => n.status === "published").length} note={`${store.events.length} events`} />
      </div>

      <div className="mt-10 grid gap-5 lg:grid-cols-2">
        <div className="panel p-6">
          <h3 className="label text-ink/45">Recent activity</h3>
          {store.audit.length === 0 ? (
            <p className="mt-4 text-sm text-ink/55">No administrative activity recorded yet.</p>
          ) : (
            <ul className="mt-4 divide-y divide-ink/10">
              {store.audit.slice(0, 6).map((a) => (
                <li key={a.id} className="flex items-start justify-between gap-4 py-3 text-sm">
                  <span>
                    <span className="font-medium text-royal-900">{a.action.replace(/_/g, " ")}</span>
                    <span className="block text-xs text-ink/50">{a.resource}</span>
                  </span>
                  <span className="shrink-0 text-xs text-ink/45">{new Date(a.at).toLocaleString("en-GB")}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="panel p-6">
          <h3 className="label text-ink/45">Top programmes by application</h3>
          {apps.length === 0 ? (
            <p className="mt-4 text-sm text-ink/55">No applications yet.</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {Object.entries(
                apps.reduce<Record<string, number>>((acc, a) => {
                  acc[a.programmeSlug] = (acc[a.programmeSlug] ?? 0) + 1;
                  return acc;
                }, {})
              )
                .sort((a, b) => b[1] - a[1])
                .slice(0, 6)
                .map(([slug, count]) => (
                  <li key={slug} className="flex items-center justify-between gap-4 text-sm">
                    <span className="text-royal-900">{slug.replace(/-/g, " ")}</span>
                    <span className="text-ink/50">{count}</span>
                  </li>
                ))}
            </ul>
          )}
        </div>
      </div>
    </EditorShell>
  );
}

/* ------------------------------------------------------------ applications */
function ApplicationsAdmin() {
  const { can } = useAuth();
  const toast = useToast();
  const [apps, setApps] = useState<Application[] | null>(null);
  useEffect(() => {
    let alive = true;
    const load = () => {
      db.allApplications().then((a) => {
        if (alive) setApps(a);
      });
    };
    load();
    const unsub = subscribe(load);
    return () => {
      alive = false;
      unsub();
    };
  }, []);
  const [page, setPage] = useState(1);
  const per = 8;
  const pages = Math.max(1, Math.ceil((apps?.length ?? 0) / per));
  const rows = useMemo(() => (apps ?? []).slice((page - 1) * per, page * per), [apps, page]);

  if (!can("applications.read")) return <EditorShell title="Applications" description="You do not have permission to view applications."><EmptyState title="Access restricted" body="Ask an administrator for the ADMISSIONS or ADMIN role." /></EditorShell>;

  return (
    <EditorShell title="Applications" description="Review, update and track every application. Status changes notify the applicant.">
      {!apps ? (
        <p className="flex items-center gap-2 text-sm text-ink/55"><Spinner /> Loading applications…</p>
      ) : apps.length === 0 ? (
        <EmptyState title="No applications yet." body="Applications created through the portal appear here." />
      ) : (
        <>
          <DataTable<Application>
            rows={rows}
            keyOf={(a) => a.id}
            columns={[
              { key: "ref", label: "Reference", render: (a) => <span className="font-medium text-royal-900">{a.ref}</span> },
              { key: "programme", label: "Programme", render: (a) => a.programmeSlug.replace(/-/g, " ") },
              { key: "level", label: "Level", render: (a) => a.level },
              { key: "docs", label: "Docs", render: (a) => a.documents.length },
              { key: "status", label: "Status", render: (a) => <StatusBadge status={a.status} /> },
              {
                key: "updated",
                label: "Updated",
                render: (a) => new Date(a.updatedAt).toLocaleDateString("en-GB"),
              },
            ]}
            actions={(a) =>
              can("applications.update") ? (
                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    className="!px-3 !py-1.5 !text-[0.7rem]"
                    onClick={() => {
                      admin.setApplicationStatus(a.id, "under_review", "Review started by admissions.");
                      toast({ tone: "info", title: "Marked under review", body: a.ref });
                    }}
                  >
                    Review
                  </Button>
                  <Button
                    variant="outline"
                    className="!px-3 !py-1.5 !text-[0.7rem]"
                    onClick={() => {
                      admin.setApplicationStatus(a.id, "accepted", "Congratulations — an offer has been made.");
                      toast({ tone: "success", title: "Application accepted", body: a.ref });
                    }}
                  >
                    Accept
                  </Button>
                  <Button
                    variant="outline"
                    className="!px-3 !py-1.5 !text-[0.7rem]"
                    onClick={() => {
                      admin.setApplicationStatus(a.id, "additional_information_required", "Please provide further documents.");
                      toast({ tone: "info", title: "Information requested", body: a.ref });
                    }}
                  >
                    Info
                  </Button>
                </div>
              ) : (
                <span className="text-xs text-ink/40">Read only</span>
              )
            }
          />
          <div className="mt-6">
            <Pagination page={page} pages={pages} onChange={setPage} />
          </div>
        </>
      )}
    </EditorShell>
  );
}

/* --------------------------------------------------------------- enquiries */
function EnquiriesAdmin() {
  const { can } = useAuth();
  const toast = useToast();
  const [rows, setRows] = useState<Enquiry[] | null>(null);
  useEffect(() => {
    const load = () => db.enquiries().then(setRows);
    load();
    const unsub = subscribe(load);
    return () => {
      unsub();
    };
  }, []);
  if (!can("enquiries.read")) return <EditorShell title="Enquiries" description="You do not have permission to view enquiries."><EmptyState title="Access restricted" body="Ask an administrator for the ADMISSIONS or ADMIN role." /></EditorShell>;

  return (
    <EditorShell title="Enquiries" description="Contact form submissions and their response status.">
      {!rows ? (
        <p className="text-sm text-ink/55">Loading enquiries…</p>
      ) : rows.length === 0 ? (
        <EmptyState title="No enquiries yet." body="Submissions from the contact form appear here." />
      ) : (
        <DataTable<Enquiry>
          rows={rows}
          keyOf={(e) => e.id}
          columns={[
            { key: "name", label: "Name", render: (e) => <span className="font-medium text-royal-900">{e.name}</span> },
            { key: "subject", label: "Subject", render: (e) => e.subject },
            { key: "email", label: "Email", render: (e) => <a href={`mailto:${e.email}`} className="link-editorial">{e.email}</a> },
            { key: "status", label: "Status", render: (e) => <span className="label text-royal-700">{e.status.replace(/_/g, " ")}</span> },
          ]}
          actions={(e) =>
            can("enquiries.update") ? (
              <select
                className="input !w-auto !py-1.5 !text-xs"
                value={e.status}
                aria-label={`Status for enquiry from ${e.name}`}
                onChange={(ev) => {
                  admin.setEnquiryStatus(e.id, ev.target.value as Enquiry["status"]);
                  toast({ tone: "success", title: "Status updated" });
                }}
              >
                <option value="new">New</option>
                <option value="in_progress">In progress</option>
                <option value="responded">Responded</option>
                <option value="resolved">Resolved</option>
              </select>
            ) : (
              <span className="text-xs text-ink/40">Read only</span>
            )
          }
        />
      )}
    </EditorShell>
  );
}

/* ------------------------------------------------------- generic CMS table */
function useStoreList<T>(key: "programmes" | "faculties" | "news" | "events" | "announcements" | "documents") {
  const [rows, setRows] = useState<T[] | null>(null);
  useEffect(() => {
    const load = () => setRows((getStore()[key] as unknown as T[]) ?? []);
    load();
    const unsub = subscribe(load);
    return () => {
      unsub();
    };
  }, [key]);
  return [rows, setRows] as const;
}

function ConfirmButton({ label, onConfirm }: { label: string; onConfirm: () => void }) {
  const [armed, setArmed] = useState(false);
  return (
    <Button
      variant="outline"
      className="!px-3 !py-1.5 !text-[0.7rem]"
      onClick={() => {
        if (armed) {
          onConfirm();
          setArmed(false);
        } else setArmed(true);
      }}
      onBlur={() => setArmed(false)}
    >
      {armed ? "Confirm delete" : label}
    </Button>
  );
}

/* ---------------------------------------------------------------- programmes */
function ProgrammesAdmin() {
  const { can } = useAuth();
  const toast = useToast();
  const [rows] = useStoreList<Programme>("programmes");
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [editing, setEditing] = useState<Programme | null>(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    db.allFaculties().then(setFaculties);
  }, []);

  const blank = (): Programme => ({
    id: uid(),
    slug: "",
    title: "",
    facultySlug: faculties[0]?.slug ?? "",
    department: "",
    level: "undergraduate",
    award: "",
    duration: "",
    overview: "",
    objectives: [],
    requirements: [],
    careers: [],
    status: "published",
    sources: [],
  });

  const save = (p: Programme) => {
    const slug = p.slug || slugify(p.title);
    admin.upsertProgramme({ ...p, slug });
    setOpen(false);
    toast({ tone: "success", title: "Programme saved", body: p.title });
  };

  if (!can("content.write") && !can("programmes.write"))
    return <EditorShell title="Programmes" description="You do not have permission to edit programmes."><EmptyState title="Access restricted" body="Ask an administrator for the EDITOR, ADMIN or FACULTY_ADMIN role." /></EditorShell>;

  return (
    <EditorShell title="Programmes" description="Create, edit, publish and unpublish programmes. Unpublished fields are hidden on the public site rather than filled in.">
      <div className="mb-6">
        <Button
          variant="primary"
          onClick={() => {
            setEditing(blank());
            setOpen(true);
          }}
        >
          New programme
        </Button>
      </div>
      {!rows ? (
        <p className="text-sm text-ink/55">Loading programmes…</p>
      ) : (
        <DataTable<Programme>
          rows={rows}
          keyOf={(p) => p.id}
          columns={[
            { key: "title", label: "Programme", render: (p) => <span className="font-medium text-royal-900">{p.title}</span> },
            { key: "faculty", label: "Faculty", render: (p) => p.facultySlug.replace(/-/g, " ") },
            { key: "dept", label: "Department", render: (p) => p.department },
            { key: "level", label: "Level", render: (p) => p.level },
            { key: "status", label: "Status", render: (p) => <span className="label text-royal-700">{p.status}</span> },
          ]}
          actions={(p) => (
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                className="!px-3 !py-1.5 !text-[0.7rem]"
                onClick={() => {
                  setEditing(p);
                  setOpen(true);
                }}
              >
                Edit
              </Button>
              <Button
                variant="outline"
                className="!px-3 !py-1.5 !text-[0.7rem]"
                onClick={() => admin.upsertProgramme({ ...p, status: p.status === "published" ? "draft" : "published" })}
              >
                {p.status === "published" ? "Unpublish" : "Publish"}
              </Button>
              <ConfirmButton label="Delete" onConfirm={() => admin.deleteProgramme(p.id)} />
            </div>
          )}
        />
      )}

      <Modal
        open={open && !!editing}
        onClose={() => setOpen(false)}
        title={editing?.title ? `Edit ${editing.title}` : "New programme"}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={() => editing && save(editing)}>
              Save programme
            </Button>
          </div>
        }
      >
        {editing && (
          <div className="space-y-5">
            <Field label="Programme title" required>
              {(id) => (
                <input
                  id={id}
                  className="input"
                  value={editing.title}
                  onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                />
              )}
            </Field>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Slug">
                {(id) => (
                  <input
                    id={id}
                    className="input"
                    value={editing.slug}
                    onChange={(e) => setEditing({ ...editing, slug: e.target.value })}
                    placeholder="auto from title"
                  />
                )}
              </Field>
              <Field label="Faculty">
                {(id) => (
                  <select
                    id={id}
                    className="input"
                    value={editing.facultySlug}
                    onChange={(e) => setEditing({ ...editing, facultySlug: e.target.value })}
                  >
                    {faculties.map((f) => (
                      <option key={f.slug} value={f.slug}>
                        {f.name}
                      </option>
                    ))}
                  </select>
                )}
              </Field>
              <Field label="Department">
                {(id) => (
                  <input
                    id={id}
                    className="input"
                    value={editing.department}
                    onChange={(e) => setEditing({ ...editing, department: e.target.value })}
                  />
                )}
              </Field>
              <Field label="Level">
                {(id) => (
                  <select
                    id={id}
                    className="input"
                    value={editing.level}
                    onChange={(e) => setEditing({ ...editing, level: e.target.value as Programme["level"] })}
                  >
                    <option value="undergraduate">Undergraduate</option>
                    <option value="postgraduate">Postgraduate</option>
                    <option value="professional">Professional</option>
                  </select>
                )}
              </Field>
              <Field label="Award">
                {(id) => (
                  <input
                    id={id}
                    className="input"
                    value={editing.award}
                    onChange={(e) => setEditing({ ...editing, award: e.target.value })}
                    placeholder="e.g. B.Sc."
                  />
                )}
              </Field>
              <Field label="Duration">
                {(id) => (
                  <input
                    id={id}
                    className="input"
                    value={editing.duration}
                    onChange={(e) => setEditing({ ...editing, duration: e.target.value })}
                    placeholder="Leave blank if not published"
                  />
                )}
              </Field>
            </div>
            <Field label="Overview" hint="Leave blank to show the CMS placeholder on the public page.">
              {(id) => (
                <textarea
                  id={id}
                  className="input"
                  rows={4}
                  value={editing.overview}
                  onChange={(e) => setEditing({ ...editing, overview: e.target.value })}
                />
              )}
            </Field>
            <Field label="Status">
              {(id) => (
                <select
                  id={id}
                  className="input"
                  value={editing.status}
                  onChange={(e) => setEditing({ ...editing, status: e.target.value as Programme["status"] })}
                >
                  <option value="published">Published</option>
                  <option value="draft">Draft</option>
                </select>
              )}
            </Field>
          </div>
        )}
      </Modal>
    </EditorShell>
  );
}

/* ------------------------------------------------------------------ faculties */
function FacultiesAdmin() {
  const { can } = useAuth();
  const [rows] = useStoreList<Faculty>("faculties");
  const [editing, setEditing] = useState<Faculty | null>(null);
  const [open, setOpen] = useState(false);
  if (!can("content.write"))
    return <EditorShell title="Faculties" description="You do not have permission to edit faculties."><EmptyState title="Access restricted" /></EditorShell>;

  return (
    <EditorShell title="Faculties" description="Manage the faculty directory, departments and contact details.">
      <div className="mb-6">
        <Button
          variant="primary"
          onClick={() => {
            setEditing({
              id: uid(),
              slug: "",
              name: "",
              short: "",
              ordinal: String((rows?.length ?? 0) + 1).padStart(2, "0"),
              summary: "",
              intro: "",
              dean: "",
              departments: [],
              researchAreas: [],
              contact: { email: "", phone: "" },
              image: "/images/campus.jpg",
              status: "published",
              sources: [],
            });
            setOpen(true);
          }}
        >
          New faculty
        </Button>
      </div>
      {!rows ? (
        <p className="text-sm text-ink/55">Loading faculties…</p>
      ) : (
        <DataTable<Faculty>
          rows={rows}
          keyOf={(f) => f.id}
          columns={[
            { key: "name", label: "Faculty", render: (f) => <span className="font-medium text-royal-900">{f.name}</span> },
            { key: "depts", label: "Departments", render: (f) => f.departments.length },
            { key: "dean", label: "Dean", render: (f) => f.dean || <span className="text-ink/40">not published</span> },
            { key: "status", label: "Status", render: (f) => <span className="label text-royal-700">{f.status}</span> },
          ]}
          actions={(f) => (
            <div className="flex justify-end gap-2">
              <Button variant="outline" className="!px-3 !py-1.5 !text-[0.7rem]" onClick={() => { setEditing(f); setOpen(true); }}>
                Edit
              </Button>
              <ConfirmButton label="Delete" onConfirm={() => admin.deleteFaculty(f.id)} />
            </div>
          )}
        />
      )}
      <Modal
        open={open && !!editing}
        onClose={() => setOpen(false)}
        title={editing?.name || "New faculty"}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={() => { if (editing) admin.upsertFaculty({ ...editing, slug: editing.slug || slugify(editing.name) }); setOpen(false); }}>
              Save faculty
            </Button>
          </div>
        }
      >
        {editing && (
          <div className="space-y-5">
            <Field label="Faculty name" required>
              {(id) => <input id={id} className="input" value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} />}
            </Field>
            <Field label="Summary">
              {(id) => <input id={id} className="input" value={editing.summary} onChange={(e) => setEditing({ ...editing, summary: e.target.value })} />}
            </Field>
            <Field label="Introduction" hint="Leave blank to show the CMS placeholder publicly.">
              {(id) => <textarea id={id} className="input" rows={4} value={editing.intro} onChange={(e) => setEditing({ ...editing, intro: e.target.value })} />}
            </Field>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Dean">
                {(id) => <input id={id} className="input" value={editing.dean} onChange={(e) => setEditing({ ...editing, dean: e.target.value })} />}
              </Field>
              <Field label="Contact email">
                {(id) => <input id={id} className="input" value={editing.contact.email} onChange={(e) => setEditing({ ...editing, contact: { ...editing.contact, email: e.target.value } })} />}
              </Field>
            </div>
            <Field label="Departments" hint="Comma separated.">
              {(id) => (
                <input
                  id={id}
                  className="input"
                  value={editing.departments.join(", ")}
                  onChange={(e) => setEditing({ ...editing, departments: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
                />
              )}
            </Field>
          </div>
        )}
      </Modal>
    </EditorShell>
  );
}

/* --------------------------------------------------------------- news/events */
function NewsAdmin() {
  const { can } = useAuth();
  const toast = useToast();
  const [rows] = useStoreList<NewsItem>("news");
  const [editing, setEditing] = useState<NewsItem | null>(null);
  const [open, setOpen] = useState(false);
  if (!can("content.write"))
    return <EditorShell title="News" description="You do not have permission to publish news."><EmptyState title="Access restricted" /></EditorShell>;

  const blank = (): NewsItem => ({
    id: uid(),
    title: "",
    slug: "",
    excerpt: "",
    content: "",
    category: NEWS_CATEGORIES[0],
    author: "BIU Newsroom",
    coverImage: "/images/campus.jpg",
    publishedAt: new Date().toISOString().slice(0, 10),
    status: "published",
    seoTitle: "",
    seoDescription: "",
    ogImage: "/og-image.jpg",
  });

  return (
    <EditorShell title="News" description="Publish, schedule and archive news articles with SEO fields.">
      <div className="mb-6">
        <Button variant="primary" onClick={() => { setEditing(blank()); setOpen(true); }}>New article</Button>
      </div>
      {!rows ? (
        <p className="text-sm text-ink/55">Loading articles…</p>
      ) : rows.length === 0 ? (
        <EmptyState title="No articles yet." body="Published articles appear on the public news page automatically." />
      ) : (
        <DataTable<NewsItem>
          rows={rows}
          keyOf={(n) => n.id}
          columns={[
            { key: "title", label: "Title", render: (n) => <span className="font-medium text-royal-900">{n.title}</span> },
            { key: "cat", label: "Category", render: (n) => n.category },
            { key: "date", label: "Published", render: (n) => new Date(n.publishedAt).toLocaleDateString("en-GB") },
            { key: "status", label: "Status", render: (n) => <span className="label text-royal-700">{n.status}</span> },
          ]}
          actions={(n) => (
            <div className="flex justify-end gap-2">
              <Button variant="outline" className="!px-3 !py-1.5 !text-[0.7rem]" onClick={() => { setEditing(n); setOpen(true); }}>Edit</Button>
              <ConfirmButton label="Delete" onConfirm={() => admin.deleteNews(n.id)} />
            </div>
          )}
        />
      )}
      <Modal
        open={open && !!editing}
        onClose={() => setOpen(false)}
        title={editing?.title || "New article"}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={() => { if (editing) { admin.upsertNews({ ...editing, slug: editing.slug || slugify(editing.title) }); toast({ tone: "success", title: "Article saved" }); } setOpen(false); }}>
              Save article
            </Button>
          </div>
        }
      >
        {editing && (
          <div className="space-y-5">
            <Field label="Title" required>
              {(id) => <input id={id} className="input" value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />}
            </Field>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Category">
                {(id) => (
                  <select id={id} className="input" value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })}>
                    {NEWS_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                  </select>
                )}
              </Field>
              <Field label="Published date">
                {(id) => <input id={id} type="date" className="input" value={editing.publishedAt} onChange={(e) => setEditing({ ...editing, publishedAt: e.target.value })} />}
              </Field>
            </div>
            <Field label="Excerpt">
              {(id) => <textarea id={id} className="input" rows={2} value={editing.excerpt} onChange={(e) => setEditing({ ...editing, excerpt: e.target.value })} />}
            </Field>
            <Field label="Content">
              {(id) => <textarea id={id} className="input" rows={6} value={editing.content} onChange={(e) => setEditing({ ...editing, content: e.target.value })} />}
            </Field>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="SEO title">
                {(id) => <input id={id} className="input" value={editing.seoTitle} onChange={(e) => setEditing({ ...editing, seoTitle: e.target.value })} />}
              </Field>
              <Field label="Status">
                {(id) => (
                  <select id={id} className="input" value={editing.status} onChange={(e) => setEditing({ ...editing, status: e.target.value as NewsItem["status"] })}>
                    <option value="published">Published</option>
                    <option value="draft">Draft</option>
                  </select>
                )}
              </Field>
            </div>
            <Field label="SEO description">
              {(id) => <textarea id={id} className="input" rows={2} value={editing.seoDescription} onChange={(e) => setEditing({ ...editing, seoDescription: e.target.value })} />}
            </Field>
          </div>
        )}
      </Modal>
    </EditorShell>
  );
}

function EventsAdmin() {
  const { can } = useAuth();
  const toast = useToast();
  const [rows] = useStoreList<EventItem>("events");
  const [editing, setEditing] = useState<EventItem | null>(null);
  const [open, setOpen] = useState(false);
  if (!can("content.write"))
    return <EditorShell title="Events" description="You do not have permission to manage events."><EmptyState title="Access restricted" /></EditorShell>;

  const blank = (): EventItem => ({
    id: uid(),
    title: "",
    slug: "",
    description: "",
    image: "/images/campus.jpg",
    startDate: new Date().toISOString().slice(0, 10),
    endDate: new Date().toISOString().slice(0, 10),
    location: "Benson Idahosa University, Benin City",
    category: "Campus",
    registrationUrl: "",
    status: "published",
  });

  return (
    <EditorShell title="Events" description="Publish upcoming events. They appear on the homepage and events page automatically.">
      <div className="mb-6">
        <Button variant="primary" onClick={() => { setEditing(blank()); setOpen(true); }}>New event</Button>
      </div>
      {!rows ? (
        <p className="text-sm text-ink/55">Loading events…</p>
      ) : rows.length === 0 ? (
        <EmptyState title="No events yet." body="Scheduled events appear here and on the public site." />
      ) : (
        <DataTable<EventItem>
          rows={rows}
          keyOf={(e) => e.id}
          columns={[
            { key: "title", label: "Event", render: (e) => <span className="font-medium text-royal-900">{e.title}</span> },
            { key: "date", label: "Starts", render: (e) => new Date(e.startDate).toLocaleDateString("en-GB") },
            { key: "loc", label: "Location", render: (e) => e.location },
            { key: "cat", label: "Category", render: (e) => e.category },
          ]}
          actions={(e) => (
            <div className="flex justify-end gap-2">
              <Button variant="outline" className="!px-3 !py-1.5 !text-[0.7rem]" onClick={() => { setEditing(e); setOpen(true); }}>Edit</Button>
              <ConfirmButton label="Delete" onConfirm={() => admin.deleteEvent(e.id)} />
            </div>
          )}
        />
      )}
      <Modal
        open={open && !!editing}
        onClose={() => setOpen(false)}
        title={editing?.title || "New event"}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={() => { if (editing) { admin.upsertEvent({ ...editing, slug: editing.slug || slugify(editing.title) }); toast({ tone: "success", title: "Event saved" }); } setOpen(false); }}>
              Save event
            </Button>
          </div>
        }
      >
        {editing && (
          <div className="space-y-5">
            <Field label="Title" required>
              {(id) => <input id={id} className="input" value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />}
            </Field>
            <Field label="Description">
              {(id) => <textarea id={id} className="input" rows={4} value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} />}
            </Field>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Starts">
                {(id) => <input id={id} type="date" className="input" value={editing.startDate} onChange={(e) => setEditing({ ...editing, startDate: e.target.value })} />}
              </Field>
              <Field label="Ends">
                {(id) => <input id={id} type="date" className="input" value={editing.endDate} onChange={(e) => setEditing({ ...editing, endDate: e.target.value })} />}
              </Field>
              <Field label="Location">
                {(id) => <input id={id} className="input" value={editing.location} onChange={(e) => setEditing({ ...editing, location: e.target.value })} />}
              </Field>
              <Field label="Category">
                {(id) => <input id={id} className="input" value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })} />}
              </Field>
            </div>
          </div>
        )}
      </Modal>
    </EditorShell>
  );
}

/* --------------------------------------------------- announcements/documents */
function AnnouncementsAdmin() {
  const { can } = useAuth();
  const toast = useToast();
  const [rows] = useStoreList<Announcement>("announcements");
  const [editing, setEditing] = useState<Announcement | null>(null);
  const [open, setOpen] = useState(false);
  if (!can("content.write"))
    return <EditorShell title="Announcements" description="You do not have permission to manage announcements."><EmptyState title="Access restricted" /></EditorShell>;

  const blank = (): Announcement => ({
    id: uid(),
    title: "",
    body: "",
    href: "/admissions",
    cta: "Read more",
    startsAt: new Date().toISOString().slice(0, 10),
    expiresAt: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10),
    status: "published",
  });

  return (
    <EditorShell title="Announcements" description="Publish, schedule and expire announcements. Active ones appear as a banner on the homepage.">
      <div className="mb-6">
        <Button variant="primary" onClick={() => { setEditing(blank()); setOpen(true); }}>New announcement</Button>
      </div>
      {!rows ? (
        <p className="text-sm text-ink/55">Loading announcements…</p>
      ) : rows.length === 0 ? (
        <EmptyState title="No announcements." body="Scheduled announcements show as a homepage banner between their start and expiry dates." />
      ) : (
        <DataTable<Announcement>
          rows={rows}
          keyOf={(a) => a.id}
          columns={[
            { key: "title", label: "Announcement", render: (a) => <span className="font-medium text-royal-900">{a.title}</span> },
            { key: "start", label: "Starts", render: (a) => new Date(a.startsAt).toLocaleDateString("en-GB") },
            { key: "end", label: "Expires", render: (a) => new Date(a.expiresAt).toLocaleDateString("en-GB") },
            { key: "status", label: "Status", render: (a) => <span className="label text-royal-700">{a.status}</span> },
          ]}
          actions={(a) => (
            <div className="flex justify-end gap-2">
              <Button variant="outline" className="!px-3 !py-1.5 !text-[0.7rem]" onClick={() => { setEditing(a); setOpen(true); }}>Edit</Button>
              <ConfirmButton label="Delete" onConfirm={() => admin.deleteAnnouncement(a.id)} />
            </div>
          )}
        />
      )}
      <Modal
        open={open && !!editing}
        onClose={() => setOpen(false)}
        title={editing?.title || "New announcement"}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={() => { if (editing) { admin.upsertAnnouncement(editing); toast({ tone: "success", title: "Announcement saved" }); } setOpen(false); }}>
              Save announcement
            </Button>
          </div>
        }
      >
        {editing && (
          <div className="space-y-5">
            <Field label="Title" required>
              {(id) => <input id={id} className="input" value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />}
            </Field>
            <Field label="Body">
              {(id) => <textarea id={id} className="input" rows={3} value={editing.body} onChange={(e) => setEditing({ ...editing, body: e.target.value })} />}
            </Field>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Link">
                {(id) => <input id={id} className="input" value={editing.href} onChange={(e) => setEditing({ ...editing, href: e.target.value })} />}
              </Field>
              <Field label="Button label">
                {(id) => <input id={id} className="input" value={editing.cta} onChange={(e) => setEditing({ ...editing, cta: e.target.value })} />}
              </Field>
              <Field label="Starts">
                {(id) => <input id={id} type="date" className="input" value={editing.startsAt} onChange={(e) => setEditing({ ...editing, startsAt: e.target.value })} />}
              </Field>
              <Field label="Expires">
                {(id) => <input id={id} type="date" className="input" value={editing.expiresAt} onChange={(e) => setEditing({ ...editing, expiresAt: e.target.value })} />}
              </Field>
            </div>
          </div>
        )}
      </Modal>
    </EditorShell>
  );
}

function DocumentsAdmin() {
  const { can } = useAuth();
  const toast = useToast();
  const [rows] = useStoreList<DocItem>("documents");
  const [editing, setEditing] = useState<DocItem | null>(null);
  const [open, setOpen] = useState(false);
  if (!can("documents.write") && !can("content.write"))
    return <EditorShell title="Documents" description="You do not have permission to manage documents."><EmptyState title="Access restricted" /></EditorShell>;

  const blank = (): DocItem => ({
    id: uid(),
    title: "",
    description: "",
    category: DOC_CATEGORIES[0],
    version: "1.0",
    date: new Date().toISOString().slice(0, 10),
    status: "published",
  });

  return (
    <EditorShell title="Documents" description="Upload and version documents for the public document centre.">
      <div className="mb-6">
        <Button variant="primary" onClick={() => { setEditing(blank()); setOpen(true); }}>New document</Button>
      </div>
      {!rows ? (
        <p className="text-sm text-ink/55">Loading documents…</p>
      ) : rows.length === 0 ? (
        <EmptyState title="No documents yet." body="Published documents appear in the public document centre." />
      ) : (
        <DataTable<DocItem>
          rows={rows}
          keyOf={(d) => d.id}
          columns={[
            { key: "title", label: "Document", render: (d) => <span className="font-medium text-royal-900">{d.title}</span> },
            { key: "cat", label: "Category", render: (d) => d.category },
            { key: "ver", label: "Version", render: (d) => d.version },
            { key: "date", label: "Date", render: (d) => new Date(d.date).toLocaleDateString("en-GB") },
          ]}
          actions={(d) => (
            <div className="flex justify-end gap-2">
              <Button variant="outline" className="!px-3 !py-1.5 !text-[0.7rem]" onClick={() => { setEditing(d); setOpen(true); }}>Edit</Button>
              <ConfirmButton label="Delete" onConfirm={() => admin.deleteDocument(d.id)} />
            </div>
          )}
        />
      )}
      <Modal
        open={open && !!editing}
        onClose={() => setOpen(false)}
        title={editing?.title || "New document"}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={() => { if (editing) { admin.upsertDocument(editing); toast({ tone: "success", title: "Document saved" }); } setOpen(false); }}>
              Save document
            </Button>
          </div>
        }
      >
        {editing && (
          <div className="space-y-5">
            <Field label="Title" required>
              {(id) => <input id={id} className="input" value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />}
            </Field>
            <Field label="Description">
              {(id) => <textarea id={id} className="input" rows={3} value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} />}
            </Field>
            <div className="grid gap-5 sm:grid-cols-3">
              <Field label="Category">
                {(id) => (
                  <select id={id} className="input" value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })}>
                    {DOC_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                  </select>
                )}
              </Field>
              <Field label="Version">
                {(id) => <input id={id} className="input" value={editing.version} onChange={(e) => setEditing({ ...editing, version: e.target.value })} />}
              </Field>
              <Field label="Date">
                {(id) => <input id={id} type="date" className="input" value={editing.date} onChange={(e) => setEditing({ ...editing, date: e.target.value })} />}
              </Field>
            </div>
          </div>
        )}
      </Modal>
    </EditorShell>
  );
}

/* ------------------------------------------------------------ users/audit */
function UsersAdmin() {
  const { session } = useAuth();
  const users = [
    ...DEMO_USERS_LOCAL,
    ...(session ? [{ email: session.email, name: session.name, role: session.role }] : []),
  ];
  return (
    <EditorShell title="Users & roles" description="Roles are enforced server-side by row-level security; this view mirrors the policy set.">
      <div className="grid gap-5 lg:grid-cols-2">
        <div className="panel p-6">
          <h3 className="label text-ink/45">Accounts</h3>
          <ul className="mt-4 divide-y divide-ink/10">
            {users.map((u) => (
              <li key={u.email} className="flex items-center justify-between gap-4 py-3 text-sm">
                <span>
                  <span className="block font-medium text-royal-900">{u.name}</span>
                  <span className="text-xs text-ink/50">{u.email}</span>
                </span>
                <span className="label text-royal-700">{u.role.replace(/_/g, " ")}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="panel p-6">
          <h3 className="label text-ink/45">Role permissions</h3>
          <ul className="mt-4 space-y-3">
            {ROLES.map((r) => (
              <li key={r} className="text-sm">
                <span className="label text-royal-800">{r.replace(/_/g, " ")}</span>
                <p className="mt-1 text-xs leading-relaxed text-ink/55">
                  {PERMISSIONS[r].includes("*") ? "Full access to every resource." : PERMISSIONS[r].join(", ")}
                </p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </EditorShell>
  );
}

const DEMO_USERS_LOCAL = [
  { email: "admin@biu.edu.ng", name: "Site Administrator", role: "SUPER_ADMIN" as const },
  { email: "admissions@biu.edu.ng", name: "Admissions Officer", role: "ADMISSIONS" as const },
  { email: "applicant@biu.edu.ng", name: "Demo Applicant", role: "APPLICANT" as const },
];

function AuditAdmin() {
  const { can } = useAuth();
  const [rows, setRows] = useState<AuditEntry[] | null>(null);
  useEffect(() => {
    const load = () => db.audit().then(setRows);
    load();
    const unsub = subscribe(load);
    return () => {
      unsub();
    };
  }, []);
  if (!can("audit.read"))
    return <EditorShell title="Audit log" description="You do not have permission to view audit logs."><EmptyState title="Access restricted" /></EditorShell>;
  return (
    <EditorShell title="Audit log" description="Who changed what, when, and on which resource.">
      {!rows ? (
        <p className="text-sm text-ink/55">Loading audit log…</p>
      ) : rows.length === 0 ? (
        <EmptyState title="No audit entries yet." body="Administrative actions are recorded here automatically." />
      ) : (
        <DataTable<AuditEntry>
          rows={rows.slice(0, 60)}
          keyOf={(a) => a.id}
          columns={[
            { key: "action", label: "Action", render: (a) => <span className="label text-royal-700">{a.action.replace(/_/g, " ")}</span> },
            { key: "resource", label: "Resource", render: (a) => a.resource },
            { key: "actor", label: "Actor", render: (a) => a.actor },
            { key: "at", label: "When", render: (a) => new Date(a.at).toLocaleString("en-GB") },
          ]}
        />
      )}
    </EditorShell>
  );
}

function SettingsAdmin() {
  return (
    <EditorShell title="Site settings" description="Global configuration values. Secrets are read from environment variables server-side and are never stored in the client.">
      <div className="grid gap-5 lg:grid-cols-2">
        <div className="panel p-6">
          <h3 className="label text-ink/45">Integrations</h3>
          <ul className="mt-4 space-y-3 text-sm">
            {[
              ["Database (Supabase)", "Configured via environment variables"],
              ["Authentication", "Supabase Auth (server-side sessions)"],
              ["Storage buckets", "site-assets, documents, application-documents"],
              ["Transactional email", "Server-side provider, key held server-side"],
              ["Payments", "Server-side verification with the approved provider"],
              ["AI assistant", "Retrieval over CMS-approved content only"],
            ].map(([k, v]) => (
              <li key={k} className="flex items-start justify-between gap-4 border-b border-ink/10 pb-3 last:border-0">
                <span className="font-medium text-royal-900">{k}</span>
                <span className="max-w-[16rem] text-right text-xs text-ink/55">{v}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="panel p-6">
          <h3 className="label text-ink/45">Environment variables</h3>
          <p className="mt-4 text-sm text-ink/65">
            Required keys are documented in <code className="border border-ink/15 px-1.5 py-0.5 text-xs">.env.example</code>.
            No secret is ever shipped to the browser — the client only ever receives publishable keys.
          </p>
          <ul className="mt-4 space-y-2 text-xs text-ink/60">
            <li><code>VITE_SUPABASE_URL</code></li>
            <li><code>VITE_SUPABASE_ANON_KEY</code></li>
            <li><code>SUPABASE_SERVICE_ROLE_KEY</code> — server only</li>
            <li><code>PAYMENT_SECRET_KEY</code> — server only</li>
            <li><code>EMAIL_API_KEY</code> — server only</li>
            <li><code>AI_API_KEY</code> — server only</li>
          </ul>
        </div>
      </div>
    </EditorShell>
  );
}

/* --------------------------------------------------------------------- page */
export default function Admin() {
  const { session, can } = useAuth();
  const [section, setSection] = useState<SectionId>("dashboard");
  const [navOpen, setNavOpen] = useState(false);

  useSeo({
    title: "CMS Administration | Benson Idahosa University",
    description: "Content management for Benson Idahosa University.",
    path: "/admin",
  });

  const allowed = SECTIONS.filter((s) => can(s.perm) || s.id === "settings");

  if (!session) {
    return (
      <div className="shell py-24">
        <EmptyState
          title="Administrator sign-in required."
          body="This area is restricted to authorised BIU staff with the appropriate role."
          action={
            <Link to="/apply" className="btn btn-primary">
              Sign in
            </Link>
          }
        />
      </div>
    );
  }

  if (allowed.length === 0) {
    return (
      <div className="shell py-24">
        <EmptyState
          title="You do not have access to the CMS."
          body={`Your role (${session.role.replace(/_/g, " ")}) has no administrative permissions. Ask a SUPER_ADMIN to grant access.`}
          action={
            <Link to="/" className="btn btn-outline">
              Return to the site
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="shell py-10 md:py-14">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <span className="label text-gold-600">Content management</span>
          <h1 className="display-2 mt-3 text-royal-900">BIU CMS</h1>
        </div>
        <p className="text-sm text-ink/55">
          Signed in as <span className="font-medium text-royal-900">{session.email}</span> ·{" "}
          <span className="label text-royal-700">{session.role.replace(/_/g, " ")}</span>
        </p>
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-12">
        <button
          className="btn btn-outline lg:hidden"
          onClick={() => setNavOpen((o) => !o)}
          aria-expanded={navOpen}
        >
          {navOpen ? "Hide sections" : "Show sections"}
        </button>
        <aside className={`lg:col-span-3 ${navOpen ? "block" : "hidden lg:block"}`}>
          <nav aria-label="CMS sections" className="lg:sticky lg:top-28">
            <ul className="divide-y divide-ink/10 border-y border-ink/10">
              {allowed.map((s) => (
                <li key={s.id}>
                  <button
                    onClick={() => {
                      setSection(s.id);
                      setNavOpen(false);
                    }}
                    aria-current={section === s.id}
                    className={`flex w-full items-center justify-between px-1 py-3.5 text-left text-sm transition-colors ${
                      section === s.id ? "font-semibold text-royal-900" : "text-ink/60 hover:text-royal-700"
                    }`}
                  >
                    {s.label}
                    {section === s.id && <span aria-hidden="true" className="text-gold-600">●</span>}
                  </button>
                </li>
              ))}
            </ul>
            <div className="mt-6">
              <Link to="/" className="link-editorial text-sm text-royal-800">
                View public site →
              </Link>
            </div>
          </nav>
        </aside>

        <div className="lg:col-span-9">
          <Reveal>
            {section === "dashboard" && <Dashboard />}
            {section === "applications" && <ApplicationsAdmin />}
            {section === "enquiries" && <EnquiriesAdmin />}
            {section === "programmes" && <ProgrammesAdmin />}
            {section === "faculties" && <FacultiesAdmin />}
            {section === "news" && <NewsAdmin />}
            {section === "events" && <EventsAdmin />}
            {section === "announcements" && <AnnouncementsAdmin />}
            {section === "documents" && <DocumentsAdmin />}
            {section === "users" && <UsersAdmin />}
            {section === "audit" && <AuditAdmin />}
            {section === "settings" && <SettingsAdmin />}
          </Reveal>
        </div>
      </div>
    </div>
  );
}
