import { useEffect, useState } from "react";
import { Link, useRoute } from "../lib/router";
import { useSeo, breadcrumbLd } from "../lib/seo";
import { db, type Faculty, type Programme } from "../lib/cms";
import { ButtonLink, EmptyState, Reveal, SkeletonText } from "../components/ui";

export default function FacultyPage({ slug: slugProp }: { slug?: string }) {
  const { query } = useRoute();
  const slug = slugProp ?? query.get("slug") ?? "";
  const [faculty, setFaculty] = useState<Faculty | null | undefined>(undefined);
  const [programmes, setProgrammes] = useState<Programme[] | null>(null);

  useEffect(() => {
    let alive = true;
    setFaculty(undefined);
    Promise.all([db.faculty(slug), db.programmes()]).then(([f, p]) => {
      if (!alive) return;
      setFaculty(f);
      setProgrammes(p.filter((x) => x.facultySlug === slug));
    });
    return () => {
      alive = false;
    };
  }, [slug]);

  useSeo({
    title: faculty ? `${faculty.name} | Benson Idahosa University` : "Faculty | Benson Idahosa University",
    description: faculty?.summary ?? "Faculty information at Benson Idahosa University.",
    path: `/academics/faculties/${slug}`,
    jsonLd: faculty
      ? [
          breadcrumbLd([
            { name: "Home", path: "/" },
            { name: "Academics", path: "/academics" },
            { name: "Faculties", path: "/academics/faculties" },
            { name: faculty.name, path: `/academics/faculties/${faculty.slug}` },
          ]),
          { "@context": "https://schema.org", "@type": "EducationalOrganization", name: faculty.name },
        ]
      : undefined,
  });

  if (faculty === undefined) {
    return (
      <div className="shell py-24">
        <SkeletonText lines={6} />
      </div>
    );
  }

  // No slug in the URL → show the faculty directory.
  if (!slug) return <FacultiesIndex />;
  if (!faculty) {
    return (
      <div className="shell py-24">
        <EmptyState
          title="Faculty not found."
          body="This faculty may have been unpublished. Browse all faculties instead."
          action={
            <ButtonLink to="/academics/faculties" variant="primary">
              All faculties
            </ButtonLink>
          }
        />
      </div>
    );
  }

  return (
    <>
      <header className="relative overflow-hidden border-b border-ink/10 bg-royal-900 text-white">
        <div className="shell py-14 md:py-20">
          <nav aria-label="Breadcrumb" className="mb-8 text-xs text-white/50">
            <ol className="flex flex-wrap items-center gap-2">
              <li>
                <Link to="/" className="hover:text-gold-400">Home</Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link to="/academics" className="hover:text-gold-400">Academics</Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link to="/academics/faculties" className="hover:text-gold-400">Faculties</Link>
              </li>
              <li aria-hidden="true">/</li>
              <li aria-current="page" className="text-white/80">{faculty.name}</li>
            </ol>
          </nav>
          <div className="grid gap-10 md:grid-cols-12 md:items-end">
            <div className="md:col-span-7">
              <span className="label text-gold-400">Faculty {faculty.ordinal}</span>
              <h1 className="display-1 mt-5 text-white">{faculty.name}</h1>
              <p className="lede mt-6 max-w-2xl text-white/70">{faculty.summary}</p>
            </div>
            <div className="md:col-span-5">
              <div className="aspect-[16/10] overflow-hidden bg-royal-800">
                <img src={faculty.image} alt="" className="h-full w-full object-cover" loading="lazy" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="shell grid gap-16 py-20 md:grid-cols-12 md:py-24">
        <div className="md:col-span-7 lg:col-span-8">
          <Reveal>
            <h2 className="display-3 text-royal-900">Introduction</h2>
            {faculty.intro ? (
              <div className="mt-5 space-y-4 leading-relaxed text-ink/70">
                {faculty.intro.split("\n").map((para) => (
                  <p key={para.slice(0, 24)}>{para}</p>
                ))}
              </div>
            ) : (
              <div className="mt-5 border-l-2 border-gold-500 bg-gold-500/8 px-5 py-4">
                <p className="text-sm text-ink/70">
                  The faculty introduction has not been published yet. It is an editable CMS field and will appear here
                  once the university provides it.
                </p>
              </div>
            )}
          </Reveal>

          <Reveal delay={100}>
            <h2 className="display-3 mt-14 text-royal-900">Departments</h2>
            {faculty.departments.length === 0 ? (
              <p className="mt-4 text-ink/60">Departments for this faculty are published by the university.</p>
            ) : (
              <ul className="mt-5 grid gap-px bg-ink/10 sm:grid-cols-2">
                {faculty.departments.map((d) => (
                  <li key={d} className="bg-parchment px-5 py-4 text-royal-900">
                    {d}
                  </li>
                ))}
              </ul>
            )}
          </Reveal>

          <Reveal delay={160}>
            <h2 className="display-3 mt-14 text-royal-900">Programmes</h2>
            {!programmes ? (
              <SkeletonText lines={4} />
            ) : programmes.length === 0 ? (
              <p className="mt-4 text-ink/60">No published programmes for this faculty yet.</p>
            ) : (
              <ul className="mt-5 divide-y divide-ink/10">
                {programmes.map((p) => (
                  <li key={p.id}>
                    <Link
                      to={`/academics/programmes/${p.slug}`}
                      className="group flex flex-wrap items-center justify-between gap-3 py-4"
                    >
                      <span>
                        <span className="block font-display text-xl text-royal-900 group-hover:text-royal-700">{p.title}</span>
                        <span className="mt-1 block text-sm text-ink/50">
                          {p.award} · {p.department}
                        </span>
                      </span>
                      <span aria-hidden="true" className="text-ink/30 transition-transform group-hover:translate-x-1">→</span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Reveal>
        </div>

        <aside className="md:col-span-5 lg:col-span-4">
          <div className="panel sticky top-28 p-7">
            <h2 className="label text-ink/45">Faculty details</h2>
            <dl className="mt-5 space-y-5 text-sm">
              <div>
                <dt className="label text-ink/45">Dean</dt>
                <dd className="mt-1.5 text-royal-900">{faculty.dean || <span className="text-ink/45">Not published — CMS field</span>}</dd>
              </div>
              <div>
                <dt className="label text-ink/45">Contact</dt>
                <dd className="mt-1.5 text-royal-900">
                  {faculty.contact.email ? (
                    <a href={`mailto:${faculty.contact.email}`} className="link-editorial">{faculty.contact.email}</a>
                  ) : (
                    <span className="text-ink/45">Not published — CMS field</span>
                  )}
                  {faculty.contact.phone && (
                    <a href={`tel:${faculty.contact.phone}`} className="link-editorial mt-1 block">{faculty.contact.phone}</a>
                  )}
                </dd>
              </div>
              <div>
                <dt className="label text-ink/45">Research areas</dt>
                <dd className="mt-1.5 text-royal-900">
                  {faculty.researchAreas.length ? faculty.researchAreas.join(", ") : <span className="text-ink/45">Not published — CMS field</span>}
                </dd>
              </div>
            </dl>
            <div className="mt-7 border-t border-ink/10 pt-6">
              <ButtonLink to="/admissions" variant="primary" className="w-full">
                Apply to this faculty
              </ButtonLink>
              <ButtonLink to="/contact" variant="outline" className="mt-3 w-full">
                Ask a question
              </ButtonLink>
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}
