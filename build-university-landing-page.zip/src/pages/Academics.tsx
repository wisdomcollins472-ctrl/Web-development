import { useEffect, useState } from "react";
import { Link } from "../lib/router";
import { useSeo, breadcrumbLd } from "../lib/seo";
import { db, type Faculty } from "../lib/cms";
import FacultyList from "../components/FacultyList";
import ProgrammeFinder from "../components/ProgrammeFinder";
import { PageHero, Reveal, SkeletonRows } from "../components/ui";
import { useSectionScroll } from "../lib/router";

export default function Academics() {
  const [faculties, setFaculties] = useState<Faculty[] | null>(null);
  useSectionScroll([faculties?.length]);

  useEffect(() => {
    let alive = true;
    db.faculties().then((f) => alive && setFaculties(f));
    return () => {
      alive = false;
    };
  }, []);

  useSeo({
    title: "Academics — Faculties, Departments & Programmes | Benson Idahosa University",
    description: "Explore BIU faculties, departments and programmes across undergraduate, postgraduate and professional study.",
    path: "/academics",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "Academics", path: "/academics" },
    ]),
  });

  const departments = [...new Set(faculties?.flatMap((f) => f.departments) ?? [])].sort();

  return (
    <>
      <PageHero
        label="Academics"
        title="Academic life at BIU."
        intro="Eight faculties, their departments and every published programme. Where a detail has not been published by the university, it is left out rather than filled in."
        crumb={[{ name: "Home", path: "/" }, { name: "Academics" }]}
      />

      <section className="border-b border-ink/10 bg-white py-20 md:py-24">
        <div className="shell">
          <Reveal>
            <span className="label text-royal-600">Faculties</span>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="display-2 mt-4 text-royal-900">The faculties.</h2>
          </Reveal>
          <div className="mt-12">
            {faculties ? <FacultyList faculties={faculties} /> : <SkeletonRows rows={8} />}
          </div>
        </div>
      </section>

      <section id="departments" className="border-b border-ink/10 py-20 md:py-24">
        <div className="shell">
          <Reveal>
            <span className="label text-royal-600">Departments</span>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="display-2 mt-4 text-royal-900">Where teaching is organised.</h2>
          </Reveal>
          <div className="mt-12">
            {!faculties ? (
              <SkeletonRows rows={6} />
            ) : departments.length === 0 ? (
              <p className="rule py-8 text-ink/60">Departments are published by each faculty.</p>
            ) : (
              <ul className="grid gap-px bg-ink/10 sm:grid-cols-2 lg:grid-cols-3">
                {departments.map((d, i) => {
                  const owners = faculties.filter((f) => f.departments.includes(d));
                  return (
                    <li key={d} className="bg-parchment">
                      <Reveal delay={Math.min(i * 45, 320)}>
                        <div className="h-full p-6">
                          <h3 className="font-display text-xl text-royal-900">{d}</h3>
                          <p className="mt-2 text-sm text-ink/55">
                            {owners.map((o) => o.short).join(" · ")}
                          </p>
                          {owners[0] && (
                            <Link
                              to={`/academics/faculties/${owners[0].slug}`}
                              className="link-editorial mt-4 inline-flex text-sm font-semibold text-royal-800"
                            >
                              View faculty →
                            </Link>
                          )}
                        </div>
                      </Reveal>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      </section>

      <section className="py-20 md:py-28">
        <div className="shell">
          <Reveal>
            <span className="label text-royal-600">Programme finder</span>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="display-2 mt-4 text-royal-900">Explore your future.</h2>
          </Reveal>
          <div className="mt-12">
            <ProgrammeFinder />
          </div>
        </div>
      </section>
    </>
  );
}
