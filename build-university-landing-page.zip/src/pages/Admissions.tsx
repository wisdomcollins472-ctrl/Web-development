import { Link } from "../lib/router";
import { useSeo, breadcrumbLd } from "../lib/seo";
import { CONTACT } from "../lib/cms";
import { PageHero, Reveal, SectionHeading, ButtonLink, Badge } from "../components/ui";
import { useSectionScroll } from "../lib/router";

const PATHWAYS = [
  {
    id: "undergraduate",
    label: "Undergraduate",
    body: "Bachelor's degrees across agriculture, arts and education, sciences, medical and health sciences, engineering, law, management and the social sciences.",
    cta: "Find a programme",
    to: "/academics/programmes?level=undergraduate",
  },
  {
    id: "postgraduate",
    label: "Postgraduate",
    body: "Postgraduate study is coordinated through the School of Postgraduate Studies, including masters and doctoral awards.",
    cta: "Postgraduate programmes",
    to: "/academics/programmes?level=postgraduate",
  },
  {
    id: "professional",
    label: "Professional",
    body: "Professional programmes are listed in the programme finder where the university publishes them.",
    cta: "Professional programmes",
    to: "/academics/programmes?level=professional",
  },
];

const STEPS = [
  { n: "01", title: "Choose a programme", body: "Browse the programme finder and note the award, faculty and department." },
  { n: "02", title: "Create an application", body: "Register an applicant account, or sign in to continue an existing draft." },
  { n: "03", title: "Complete your information", body: "Enter your personal and academic details. Progress is saved as a draft automatically." },
  { n: "04", title: "Upload required documents", body: "Attach the documents listed for your programme. Files stay restricted to your application." },
  { n: "05", title: "Pay applicable fee", body: "Where a fee applies, payment is verified server-side before your status changes." },
  { n: "06", title: "Submit application", body: "Review your details and submit. You receive a reference number immediately." },
  { n: "07", title: "Track application status", body: "Follow your status in the applicant portal and receive notifications as it changes." },
];

const STATUSES = [
  ["DRAFT", "Started, not yet submitted."],
  ["SUBMITTED", "Received by admissions."],
  ["UNDER REVIEW", "Being assessed by the admissions office."],
  ["ADDITIONAL INFORMATION REQUIRED", "Admissions needs more from you."],
  ["ACCEPTED", "An offer has been made."],
  ["REJECTED", "Not successful on this occasion."],
  ["WITHDRAWN", "Withdrawn at your request."],
];

export default function Admissions() {
  useSectionScroll();

  useSeo({
    title: "Admissions — Your Next Chapter Starts Here | Benson Idahosa University",
    description: "Undergraduate, postgraduate and professional admissions at Benson Idahosa University: how to apply, requirements and application tracking.",
    path: "/admissions",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "Admissions", path: "/admissions" },
    ]),
  });

  return (
    <>
      <PageHero
        label="Admissions"
        title="Your next chapter starts here."
        intro="Undergraduate, postgraduate and professional study at Benson Idahosa University. Create an application, save your progress and track your status."
        crumb={[{ name: "Home", path: "/" }, { name: "Admissions" }]}
        aside={
          <div className="flex flex-col gap-3">
            <Link to="/apply" className="btn btn-gold w-full">Start your application</Link>
            <Link to="/portal" className="btn btn-ghost-light w-full">Track my application</Link>
          </div>
        }
      />

      {/* Pathways */}
      <section className="border-b border-ink/10 bg-white py-20 md:py-24">
        <div className="shell grid gap-10 md:grid-cols-3">
          {PATHWAYS.map((p, i) => (
            <Reveal key={p.id} delay={i * 100}>
              <div id={p.id} className="scroll-mt-28">
                <span className="label text-gold-600">{p.label}</span>
                <h2 className="display-3 mt-4 text-royal-900">{p.label} study</h2>
                <p className="mt-4 leading-relaxed text-ink/70">{p.body}</p>
                <Link to={p.to} className="link-editorial mt-6 inline-flex text-sm font-semibold text-royal-800">
                  {p.cta} →
                </Link>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* How to apply */}
      <section id="how-to-apply" className="scroll-mt-28 py-20 md:py-28">
        <div className="shell">
          <SectionHeading
            label="How to apply"
            title="Seven steps from enquiry to enrolment."
            intro="The application portal guides you through each stage and saves your progress as a draft."
          />
          <ol className="mt-14 grid gap-px bg-ink/10 md:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <li key={s.n} className="bg-parchment">
                <Reveal delay={Math.min(i * 70, 300)}>
                  <div className="h-full p-7">
                    <span className="font-display text-3xl text-gold-600">{s.n}</span>
                    <h3 className="mt-4 font-display text-xl text-royal-900">{s.title}</h3>
                    <p className="mt-2.5 text-sm leading-relaxed text-ink/65">{s.body}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ol>
          <Reveal delay={200}>
            <div className="mt-12 flex flex-wrap gap-3">
              <Link to="/apply" className="btn btn-primary">Start your application</Link>
              <Link to="/contact" className="btn btn-outline">Ask admissions a question</Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Requirements / fees / scholarships / FAQs */}
      <section className="border-y border-ink/10 bg-white py-20 md:py-24">
        <div className="shell grid gap-12 md:grid-cols-12">
          <div className="md:col-span-4">
            <Reveal>
              <span className="label text-royal-600">Requirements</span>
            </Reveal>
            <Reveal delay={70}>
              <h2 id="requirements" className="display-3 mt-4 scroll-mt-28 text-royal-900">What you need.</h2>
            </Reveal>
          </div>
          <div className="space-y-8 md:col-span-8">
            <Reveal>
              <div id="requirements-body" className="scroll-mt-28 border-l-2 border-gold-500 bg-gold-500/8 px-6 py-5">
                <p className="text-sm leading-relaxed text-ink/75">
                  Entry requirements are published per programme. Open a programme page to see the requirements the
                  university currently lists for that award, or contact the admissions office for confirmation.
                </p>
                <Link to="/academics/programmes" className="link-editorial mt-4 inline-flex text-sm font-semibold text-royal-800">
                  Browse programmes →
                </Link>
              </div>
            </Reveal>
            <Reveal delay={90}>
              <div id="fees" className="scroll-mt-28 border-t border-ink/10 pt-8">
                <h3 className="font-display text-2xl text-royal-900">Fees</h3>
                <p className="mt-3 leading-relaxed text-ink/70">
                  Fee schedules vary by programme and session and are published by the university. Current figures should
                  be confirmed with the admissions office rather than assumed.
                </p>
                <div className="mt-4 flex flex-wrap gap-4">
                  <a href={`tel:${CONTACT.phones[0].tel}`} className="link-editorial text-sm font-semibold text-royal-800">
                    Call admissions →
                  </a>
                  <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="link-editorial text-sm font-semibold text-royal-800">
                    biu.edu.ng ↗
                  </a>
                </div>
              </div>
            </Reveal>
            <Reveal delay={140}>
              <div id="scholarships" className="scroll-mt-28 border-t border-ink/10 pt-8">
                <h3 className="font-display text-2xl text-royal-900">Scholarships</h3>
                <p className="mt-3 leading-relaxed text-ink/70">
                  Scholarship schemes and eligibility are announced by the university. Ask the admissions office what is
                  currently open for your programme and session.
                </p>
              </div>
            </Reveal>
            <Reveal delay={190}>
              <div id="faqs" className="scroll-mt-28 border-t border-ink/10 pt-8">
                <h3 className="font-display text-2xl text-royal-900">Frequently asked questions</h3>
                <p className="mt-3 leading-relaxed text-ink/70">
                  FAQs are maintained in the CMS and published here. In the meantime, the Ask BIU assistant can answer
                  questions it can verify from published information.
                </p>
                <div className="mt-4 flex flex-wrap items-center gap-3">
                  <Badge>CMS</Badge>
                  <span className="text-sm text-ink/55">No published questions yet.</span>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Application statuses */}
      <section className="py-20 md:py-24">
        <div className="shell">
          <SectionHeading label="Application tracking" title="What each status means." />
          <ul className="mt-12 grid gap-px bg-ink/10 sm:grid-cols-2 lg:grid-cols-4">
            {STATUSES.map((s, i) => (
              <li key={s[0]} className="bg-parchment">
                <Reveal delay={Math.min(i * 60, 260)}>
                  <div className="h-full p-6">
                    <span className="label text-royal-700">{s[0]}</span>
                    <p className="mt-3 text-sm leading-relaxed text-ink/65">{s[1]}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ul>
          <Reveal delay={120}>
            <div className="mt-12">
              <ButtonLink to="/apply" variant="gold">Start your application</ButtonLink>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
