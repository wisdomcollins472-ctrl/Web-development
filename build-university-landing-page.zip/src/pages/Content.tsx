import { useEffect, useMemo, useState } from "react";
import { Link, useRoute } from "../lib/router";
import { useSeo, breadcrumbLd } from "../lib/seo";
import { CAMPUS_LIFE, CONTACT, DOC_CATEGORIES, db, type DocItem, type EventItem, type NewsItem } from "../lib/cms";
import {
  Badge,
  Button,
  ButtonLink,
  EmptyState,
  ErrorState,
  PageHero,
  Pagination,
  Reveal,
  SectionHeading,
  SkeletonCard,
  SkeletonRows,
  useToast,
} from "../components/ui";
import { useSectionScroll } from "../lib/router";

/* ============================================================== CAMPUS LIFE */
export function CampusLife() {
  const { query } = useRoute();
  const category = query.get("category") ?? "all";
  useSectionScroll();
  useSeo({
    title: "Campus Life | Benson Idahosa University",
    description: "Accommodation, student affairs, sports, clubs, chapel, health, dining and events at BIU.",
    path: "/campus-life",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "Campus Life", path: "/campus-life" },
    ]),
  });

  const categories = ["all", ...CAMPUS_LIFE.map((c) => c.name)];
  const shown = category === "all" ? CAMPUS_LIFE : CAMPUS_LIFE.filter((c) => c.name === category);

  return (
    <>
      <PageHero
        label="Campus life"
        title="Life beyond the lecture hall."
        intro="Accommodation, student affairs, sport, societies, chapel, health, dining and events — the parts of university life that happen outside the classroom."
        crumb={[{ name: "Home", path: "/" }, { name: "Campus Life" }]}
      />

      <section className="border-b border-ink/10 bg-white py-8">
        <div className="shell flex flex-wrap gap-2" role="group" aria-label="Filter campus life">
          {categories.map((c) => (
            <Link
              key={c}
              to={c === "all" ? "/campus-life" : `/campus-life?category=${encodeURIComponent(c)}`}
              aria-current={category === c ? "true" : undefined}
              className={`border px-3.5 py-2 text-xs font-semibold tracking-[0.1em] transition-colors ${
                category === c
                  ? "border-royal-800 bg-royal-800 text-white"
                  : "border-ink/15 text-ink/60 hover:border-royal-700 hover:text-royal-800"
              }`}
            >
              {c === "all" ? "ALL" : c.toUpperCase()}
            </Link>
          ))}
        </div>
      </section>

      <section className="py-20 md:py-24">
        <div className="shell">
          {shown.length === 0 ? (
            <EmptyState title="Nothing published in this category yet." />
          ) : (
            <div className="grid gap-5 md:grid-cols-2">
              {shown.map((c, i) => (
                <Reveal key={c.name} delay={i * 70}>
                  <article className="group relative overflow-hidden bg-royal-900">
                    <div className="aspect-[16/11] overflow-hidden">
                      <img
                        src={c.image}
                        alt={`${c.name} at Benson Idahosa University (illustrative)`}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-[1.4s] group-hover:scale-[1.04]"
                      />
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-royal-950/90 via-royal-950/20 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-7 text-white">
                      <Badge tone="dark">{c.tag}</Badge>
                      <h2 className="mt-3 font-display text-3xl">{c.name}</h2>
                      <p className="mt-2 max-w-md text-sm text-white/75">{c.note}</p>
                      <p className="mt-4 max-w-md text-xs leading-relaxed text-white/55">
                        Details for this area are managed in the CMS and published by the university.
                      </p>
                    </div>
                  </article>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="border-t border-ink/10 bg-white py-20">
        <div className="shell grid gap-10 md:grid-cols-12">
          <div className="md:col-span-5">
            <SectionHeading label="Voices from campus" title="What visitors say." />
          </div>
          <div className="md:col-span-7">
            <ul className="space-y-5">
              {[
                {
                  q: "The atmosphere is serene enough for learning, neat (with waste-bins in strategic locations) and shades (tress) that can protect you from the scorching sun.",
                  n: "Ejiroghene Onovughe",
                },
                {
                  q: "Biu is a great uni to attend.. It made me who I am today and the lecturers are simply awesome. They are always there to help you out in your time of need",
                  n: "Michael Egbagbe",
                },
              ].map((r, i) => (
                <Reveal key={r.n} delay={i * 110}>
                  <li>
                    <figure className="panel p-7">
                      <blockquote className="font-display text-xl leading-snug text-royal-900">“{r.q}”</blockquote>
                      <figcaption className="mt-4 text-xs text-ink/50">{r.n} · Google review</figcaption>
                    </figure>
                  </li>
                </Reveal>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </>
  );
}

/* ================================================================== RESEARCH */
export function Research() {
  useSectionScroll();
  useSeo({
    title: "Research & Innovation | Benson Idahosa University",
    description: "Research areas, centres, publications and partnerships at Benson Idahosa University.",
    path: "/research",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "Research", path: "/research" },
    ]),
  });

  const blocks = [
    { id: "areas", title: "Research areas", body: "Research themes and strengths are published by each faculty and appear here once confirmed." },
    { id: "centres", title: "Research centres", body: "Dedicated research centres and institutes are listed here as the university publishes them." },
    { id: "publications", title: "Publications", body: "Selected publications and outputs are added by the CMS. Nothing is listed until verified." },
    { id: "partnerships", title: "Partnerships", body: "Institutional and industry partnerships are published by the university." },
  ];

  return (
    <>
      <PageHero
        label="Research"
        title="Research that moves knowledge forward."
        intro="Research at BIU is organised by faculty and published by the university. This section is an editable structure — it does not assert research activity that has not been published."
        crumb={[{ name: "Home", path: "/" }, { name: "Research" }]}
        aside={
          <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="btn btn-ghost-light">
            Official site ↗
          </a>
        }
      />
      <section className="relative overflow-hidden border-b border-ink/10 bg-white py-20 md:py-24">
        <div className="shell grid gap-14 md:grid-cols-12 md:items-center">
          <div className="md:col-span-6">
            <Reveal>
              <span className="label text-royal-600">Approach</span>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="display-2 mt-4 text-royal-900">Structured for what comes next.</h2>
            </Reveal>
            <Reveal delay={140}>
              <p className="mt-6 leading-relaxed text-ink/70">
                Each research area, centre and publication is a record in the content system. Administrators publish them
                as the university confirms them, and they appear here, in the newsroom and in search immediately.
              </p>
            </Reveal>
          </div>
          <div className="md:col-span-6">
            <Reveal delay={160}>
              <div className="aspect-[4/3] overflow-hidden bg-royal-900">
                <img src="/images/lab.jpg" alt="Students working in a laboratory (illustrative)" loading="lazy" className="h-full w-full object-cover" />
              </div>
            </Reveal>
          </div>
        </div>
      </section>
      <section className="py-20 md:py-24">
        <div className="shell grid gap-px bg-ink/10 md:grid-cols-2">
          {blocks.map((b, i) => (
            <div key={b.id} id={b.id} className="scroll-mt-28 bg-parchment">
              <Reveal delay={i * 80}>
                <div className="h-full p-8">
                  <span className="font-display text-3xl text-gold-600">{String(i + 1).padStart(2, "0")}</span>
                  <h2 className="mt-4 font-display text-2xl text-royal-900">{b.title}</h2>
                  <p className="mt-3 max-w-md leading-relaxed text-ink/65">{b.body}</p>
                  <Badge>CMS</Badge>
                </div>
              </Reveal>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

/* ===================================================================== NEWS */
export function News() {
  const [items, setItems] = useState<NewsItem[] | null>(null);
  const [error, setError] = useState(false);
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("all");
  const [page, setPage] = useState(1);
  const per = 6;
  useSectionScroll();

  useEffect(() => {
    let alive = true;
    db.news()
      .then((n) => alive && setItems(n))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, []);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    return (items ?? []).filter(
      (n) =>
        (category === "all" || n.category === category) &&
        (!term || `${n.title} ${n.excerpt}`.toLowerCase().includes(term))
    );
  }, [items, q, category]);

  const pages = Math.max(1, Math.ceil(filtered.length / per));
  const rows = filtered.slice((page - 1) * per, page * per);

  useSeo({
    title: "News & Announcements | Benson Idahosa University",
    description: "The latest news and announcements from Benson Idahosa University.",
    path: "/news",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "News", path: "/news" },
    ]),
  });

  const cats = ["all", ...new Set((items ?? []).map((n) => n.category))];

  return (
    <>
      <PageHero
        label="Newsroom"
        title="News & announcements."
        intro="Articles published by the university through the newsroom CMS."
        crumb={[{ name: "Home", path: "/" }, { name: "News" }]}
      />

      <section className="border-b border-ink/10 bg-white py-8">
        <div className="shell flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
            {cats.map((c) => (
              <button
                key={c}
                onClick={() => {
                  setCategory(c);
                  setPage(1);
                }}
                aria-pressed={category === c}
                className={`border px-3.5 py-2 text-xs font-semibold tracking-[0.1em] transition-colors ${
                  category === c ? "border-royal-800 bg-royal-800 text-white" : "border-ink/15 text-ink/60 hover:border-royal-700"
                }`}
              >
                {(c === "all" ? "All" : c).toUpperCase()}
              </button>
            ))}
          </div>
          <div className="w-full md:w-72">
            <label htmlFor="news-search" className="label text-ink/50">
              Search news
            </label>
            <input
              id="news-search"
              type="search"
              className="input mt-2"
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setPage(1);
              }}
              placeholder="Search articles"
            />
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20">
        <div className="shell">
          {error ? (
            <ErrorState onRetry={() => window.location.reload()} />
          ) : !items ? (
            <div className="grid gap-5 md:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <SkeletonCard key={i} />
              ))}
            </div>
          ) : rows.length === 0 ? (
            <EmptyState
              title={q || category !== "all" ? "No news articles found." : "No published articles yet."}
              body={
                q || category !== "all"
                  ? "Try a different search term or category."
                  : "Articles published through the BIU newsroom CMS appear here automatically."
              }
              action={
                <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="btn btn-outline">
                  Read news on biu.edu.ng ↗
                </a>
              }
            />
          ) : (
            <>
              <ul className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                {rows.map((n, i) => (
                  <li key={n.id}>
                    <Reveal delay={i * 70}>
                      <Link to={`/news/${n.slug}`} className="panel group block h-full overflow-hidden">
                        {n.coverImage && (
                          <div className="aspect-[16/10] overflow-hidden bg-royal-100">
                            <img src={n.coverImage} alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-105" />
                          </div>
                        )}
                        <div className="p-6">
                          <div className="flex items-center gap-3">
                            <span className="label text-royal-600">{n.category}</span>
                            <span className="text-xs text-ink/40">
                              {new Date(n.publishedAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                            </span>
                          </div>
                          <h2 className="mt-3 font-display text-2xl leading-snug text-royal-900 group-hover:text-royal-700">{n.title}</h2>
                          <p className="mt-3 text-sm leading-relaxed text-ink/60">{n.excerpt}</p>
                        </div>
                      </Link>
                    </Reveal>
                  </li>
                ))}
              </ul>
              <div className="mt-12">
                <Pagination page={page} pages={pages} onChange={setPage} />
              </div>
            </>
          )}
        </div>
      </section>
    </>
  );
}

/* ------------------------------------------------------------ news article */
export function NewsArticle({ slug: slugProp }: { slug?: string }) {
  const { query } = useRoute();
  const slug = slugProp ?? query.get("slug") ?? "";
  const [item, setItem] = useState<NewsItem | null | undefined>(undefined);

  useEffect(() => {
    let alive = true;
    db.newsItem(slug).then((n) => alive && setItem(n));
    return () => {
      alive = false;
    };
  }, [slug]);

  useSeo({
    title: item ? `${item.title} | Benson Idahosa University` : "Article | Benson Idahosa University",
    description: item?.seoDescription || item?.excerpt || "News from Benson Idahosa University.",
    path: `/news/${slug}`,
    image: item?.ogImage,
    type: "article",
    jsonLd: item
      ? [
          breadcrumbLd([
            { name: "Home", path: "/" },
            { name: "News", path: "/news" },
            { name: item.title, path: `/news/${item.slug}` },
          ]),
          {
            "@context": "https://schema.org",
            "@type": "NewsArticle",
            headline: item.title,
            description: item.excerpt,
            datePublished: item.publishedAt,
            image: item.ogImage,
            publisher: { "@type": "CollegeOrUniversity", name: "Benson Idahosa University" },
          },
        ]
      : undefined,
  });

  if (item === undefined) return <div className="shell py-24"><SkeletonRows rows={4} /></div>;
  if (!item)
    return (
      <div className="shell py-24">
        <EmptyState title="Article not found." body="It may have been unpublished." action={<ButtonLink to="/news" variant="primary">All news</ButtonLink>} />
      </div>
    );

  return (
    <>
      <header className="border-b border-ink/10 bg-royal-900 text-white">
        <div className="shell py-14 md:py-20">
          <nav aria-label="Breadcrumb" className="mb-8 text-xs text-white/50">
            <ol className="flex flex-wrap items-center gap-2">
              <li><Link to="/" className="hover:text-gold-400">Home</Link></li>
              <li aria-hidden="true">/</li>
              <li><Link to="/news" className="hover:text-gold-400">News</Link></li>
              <li aria-hidden="true">/</li>
              <li aria-current="page" className="text-white/80">{item.category}</li>
            </ol>
          </nav>
          <span className="label text-gold-400">{item.category}</span>
          <h1 className="display-1 mt-5 max-w-4xl text-white">{item.title}</h1>
          <p className="mt-6 max-w-2xl text-lg text-white/70">{item.excerpt}</p>
          <p className="mt-8 text-xs text-white/50">
            {new Date(item.publishedAt).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })} · {item.author}
          </p>
        </div>
      </header>
      <article className="shell py-16 md:py-20">
        {item.coverImage && (
          <div className="aspect-[16/9] overflow-hidden bg-royal-100">
            <img src={item.coverImage} alt="" className="h-full w-full object-cover" />
          </div>
        )}
        <div className="mt-10 max-w-2xl">
          {item.content ? (
            item.content.split("\n").map((p) => (
              <p key={p.slice(0, 24)} className="mb-5 leading-relaxed text-ink/75">
                {p}
              </p>
            ))
          ) : (
            <p className="text-ink/60">Full article content has not been published yet.</p>
          )}
          <div className="mt-10 border-t border-ink/10 pt-6">
            <ButtonLink to="/news" variant="outline">
              Back to news
            </ButtonLink>
          </div>
        </div>
      </article>
    </>
  );
}

/* =================================================================== EVENTS */
export function Events() {
  const [items, setItems] = useState<EventItem[] | null>(null);
  const [error, setError] = useState(false);
  useEffect(() => {
    let alive = true;
    db.events()
      .then((e) => alive && setItems(e))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, []);

  useSeo({
    title: "Events | Benson Idahosa University",
    description: "Upcoming events at Benson Idahosa University, Benin City.",
    path: "/events",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "Events", path: "/events" },
    ]),
  });

  const upcoming = (items ?? []).filter((e) => e.startDate >= new Date().toISOString());

  return (
    <>
      <PageHero
        label="Events"
        title="What's happening at BIU."
        intro="Upcoming events published by the university. Events appear here automatically once scheduled."
        crumb={[{ name: "Home", path: "/" }, { name: "Events" }]}
      />
      <section className="shell py-16 md:py-20">
        {error ? (
          <ErrorState onRetry={() => window.location.reload()} />
        ) : !items ? (
          <SkeletonRows rows={4} />
        ) : upcoming.length === 0 ? (
          <EmptyState
            title="No upcoming events."
            body="Events are published through the CMS and listed here once scheduled."
            action={
              <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="btn btn-outline">
                Check biu.edu.ng ↗
              </a>
            }
          />
        ) : (
          <ul className="divide-y divide-ink/10 border-y border-ink/10">
            {upcoming.map((e, i) => (
              <li key={e.id}>
                <Reveal delay={i * 70}>
                  <Link to={`/events/${e.slug}`} className="group grid gap-5 py-7 md:grid-cols-12 md:items-center">
                    <div className="md:col-span-2">
                      <span className="font-display text-4xl text-royal-800">
                        {new Date(e.startDate).toLocaleDateString("en-GB", { day: "2-digit" })}
                      </span>
                      <span className="label mt-1 block text-ink/45">
                        {new Date(e.startDate).toLocaleDateString("en-GB", { month: "short", year: "numeric" })}
                      </span>
                    </div>
                    <div className="md:col-span-7">
                      <h2 className="font-display text-2xl text-royal-900 group-hover:text-royal-700">{e.title}</h2>
                      <p className="mt-1.5 text-sm text-ink/55">{e.location}</p>
                      <p className="mt-2 max-w-xl text-sm leading-relaxed text-ink/60">{e.description}</p>
                    </div>
                    <div className="md:col-span-3 md:text-right">
                      <span className="label text-royal-600">{e.category}</span>
                      <p className="mt-1 text-sm text-ink/50">View event →</p>
                    </div>
                  </Link>
                </Reveal>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}

/* ------------------------------------------------------------ event detail */
export function EventDetail({ slug: slugProp }: { slug?: string }) {
  const { query } = useRoute();
  const slug = slugProp ?? query.get("slug") ?? "";
  const [event, setEvent] = useState<EventItem | null | undefined>(undefined);

  useEffect(() => {
    let alive = true;
    db.event(slug).then((e) => alive && setEvent(e));
    return () => {
      alive = false;
    };
  }, [slug]);

  useSeo({
    title: event ? `${event.title} | Benson Idahosa University` : "Event | Benson Idahosa University",
    description: event?.description ?? "Event at Benson Idahosa University.",
    path: `/events/${slug}`,
    jsonLd: event
      ? [
          breadcrumbLd([
            { name: "Home", path: "/" },
            { name: "Events", path: "/events" },
            { name: event.title, path: `/events/${event.slug}` },
          ]),
          {
            "@context": "https://schema.org",
            "@type": "Event",
            name: event.title,
            description: event.description,
            startDate: event.startDate,
            endDate: event.endDate,
            location: { "@type": "Place", name: event.location },
            organizer: { "@type": "CollegeOrUniversity", name: "Benson Idahosa University" },
          },
        ]
      : undefined,
  });

  if (event === undefined) return <div className="shell py-24"><SkeletonRows rows={3} /></div>;
  if (!event)
    return (
      <div className="shell py-24">
        <EmptyState title="Event not found." action={<ButtonLink to="/events" variant="primary">All events</ButtonLink>} />
      </div>
    );

  return (
    <>
      <PageHero
        label={event.category}
        title={event.title}
        intro={event.description}
        crumb={[{ name: "Home", path: "/" }, { name: "Events", path: "/events" }, { name: event.title }]}
      />
      <section className="shell py-16">
        <div className="grid gap-10 md:grid-cols-12">
          <div className="md:col-span-7">
            {event.image && (
              <div className="aspect-[16/10] overflow-hidden bg-royal-100">
                <img src={event.image} alt="" className="h-full w-full object-cover" />
              </div>
            )}
          </div>
          <div className="md:col-span-5">
            <div className="panel p-7">
              <dl className="space-y-5 text-sm">
                {[
                  ["Starts", new Date(event.startDate).toLocaleString("en-GB")],
                  ["Ends", new Date(event.endDate).toLocaleString("en-GB")],
                  ["Location", event.location],
                  ["Category", event.category],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt className="label text-ink/45">{k}</dt>
                    <dd className="mt-1.5 text-royal-900">{v}</dd>
                  </div>
                ))}
              </dl>
              {event.registrationUrl && (
                <a href={event.registrationUrl} target="_blank" rel="noopener noreferrer" className="btn btn-primary mt-7 w-full">
                  Register
                </a>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

/* ================================================================ DOCUMENTS */
export function Documents() {
  const { query } = useRoute();
  const category = query.get("category") ?? "all";
  const [docs, setDocs] = useState<DocItem[] | null>(null);
  const [q, setQ] = useState("");
  const toast = useToast();

  useEffect(() => {
    let alive = true;
    db.documents().then((d) => alive && setDocs(d));
    return () => {
      alive = false;
    };
  }, []);

  const filtered = (docs ?? []).filter(
    (d) =>
      (category === "all" || d.category === category) &&
      (!q.trim() || `${d.title} ${d.description}`.toLowerCase().includes(q.trim().toLowerCase()))
  );

  useSeo({
    title: "Document Centre | Benson Idahosa University",
    description: "Admissions, academic, policy, form and calendar documents from Benson Idahosa University.",
    path: "/documents",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "Documents", path: "/documents" },
    ]),
  });

  return (
    <>
      <PageHero
        label="Document centre"
        title="Documents & downloads."
        intro="Admissions, academic, policy, form, handbook, calendar and prospectus documents published by the university."
        crumb={[{ name: "Home", path: "/" }, { name: "Documents" }]}
      />
      <section className="border-b border-ink/10 bg-white py-8">
        <div className="shell flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div className="flex flex-wrap gap-2" role="group" aria-label="Filter documents">
            {["all", ...DOC_CATEGORIES].map((c) => (
              <Link
                key={c}
                to={c === "all" ? "/documents" : `/documents?category=${encodeURIComponent(c)}`}
                aria-current={category === c ? "true" : undefined}
                className={`border px-3.5 py-2 text-xs font-semibold tracking-[0.1em] transition-colors ${
                  category === c ? "border-royal-800 bg-royal-800 text-white" : "border-ink/15 text-ink/60 hover:border-royal-700"
                }`}
              >
                {(c === "all" ? "All" : c).toUpperCase()}
              </Link>
            ))}
          </div>
          <div className="w-full md:w-72">
            <label htmlFor="doc-search" className="label text-ink/50">Search documents</label>
            <input id="doc-search" type="search" className="input mt-2" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search documents" />
          </div>
        </div>
      </section>
      <section className="py-16">
        <div className="shell">
          {!docs ? (
            <SkeletonRows rows={5} />
          ) : filtered.length === 0 ? (
            <EmptyState
              title="No documents published yet."
              body="Documents uploaded through the CMS appear here with their version and date."
              action={
                <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="btn btn-outline">
                  biu.edu.ng ↗
                </a>
              }
            />
          ) : (
            <ul className="divide-y divide-ink/10 border-y border-ink/10">
              {filtered.map((d) => (
                <li key={d.id} className="flex flex-wrap items-center justify-between gap-4 py-5">
                  <div>
                    <h2 className="font-display text-xl text-royal-900">{d.title}</h2>
                    <p className="mt-1 text-sm text-ink/55">{d.description}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="label text-ink/45">v{d.version}</span>
                    <span className="text-xs text-ink/45">{new Date(d.date).toLocaleDateString("en-GB")}</span>
                    <Button
                      variant="outline"
                      className="!py-2 !text-[0.7rem]"
                      onClick={() => toast({ tone: "info", title: d.title, body: "Files are attached in the CMS and served from the documents storage bucket." })}
                    >
                      Download
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </>
  );
}
