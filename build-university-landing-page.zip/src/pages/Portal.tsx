import { useEffect, useState } from "react";
import { Link } from "../lib/router";
import { useSeo } from "../lib/seo";
import { admin, db, subscribe, type Application, type Notification } from "../lib/cms";
import { useAuth } from "../lib/auth";
import { Button, EmptyState, PageHero, StatusBadge, useToast } from "../components/ui";

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

export default function Portal() {
  const { session } = useAuth();
  const toast = useToast();
  const [apps, setApps] = useState<Application[] | null>(null);
  const [notes, setNotes] = useState<Notification[] | null>(null);
  const [tab, setTab] = useState<"applications" | "notifications">("applications");
  const [, force] = useState(0);

  useEffect(() => {
    const unsub = subscribe(() => force((n) => n + 1));
    return () => {
      unsub();
    };
  }, []);

  useEffect(() => {
    if (!session) return;
    let alive = true;
    Promise.all([db.applications(session.id), db.notifications(session.id)]).then(([a, n]) => {
      if (!alive) return;
      setApps(a);
      setNotes(n);
    });
    return () => {
      alive = false;
    };
  }, [session]);

  useSeo({
    title: "Applicant Portal | Benson Idahosa University",
    description: "Track your BIU application status, documents and notifications.",
    path: "/portal",
  });

  if (!session) {
    return (
      <div className="shell py-24">
        <EmptyState
          title="Sign in to view your portal."
          body="Your applications, documents and notifications are private to your account."
          action={
            <Link to="/apply" className="btn btn-primary">
              Sign in or create an account
            </Link>
          }
        />
      </div>
    );
  }

  const unread = notes?.filter((n) => !n.read).length ?? 0;

  return (
    <>
      <PageHero
        label="Applicant portal"
        title={`Welcome back, ${session.name.split(" ")[0]}.`}
        intro="Track your applications, documents and notifications. This portal shows only your own records."
        crumb={[{ name: "Home", path: "/" }, { name: "Portal" }]}
        aside={
          <div className="flex flex-col gap-3">
            <Link to="/apply" className="btn btn-gold w-full">New application</Link>
            <a href="https://biuportal.net/" target="_blank" rel="noopener noreferrer" className="btn btn-ghost-light w-full">
              BIU student portal ↗
            </a>
          </div>
        }
      />

      <section className="shell py-16 md:py-20">
        <div className="flex flex-wrap items-center gap-6 border-b border-ink/10" role="tablist" aria-label="Portal sections">
          {(
            [
              ["applications", "Applications"],
              ["notifications", `Notifications${unread ? ` (${unread})` : ""}`],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              role="tab"
              aria-selected={tab === id}
              onClick={() => setTab(id)}
              className={`-mb-px border-b-2 pb-4 text-sm font-semibold tracking-wide transition-colors ${
                tab === id ? "border-royal-800 text-royal-900" : "border-transparent text-ink/45 hover:text-royal-700"
              }`}
            >
              {label.toUpperCase()}
            </button>
          ))}
        </div>

        {tab === "applications" && (
          <div className="mt-10">
            {!apps ? (
              <p className="text-sm text-ink/50">Loading applications…</p>
            ) : apps.length === 0 ? (
              <EmptyState
                title="No applications yet."
                body="Start an application and it will appear here with its status, documents and history."
                action={
                  <Link to="/apply" className="btn btn-primary">
                    Start an application
                  </Link>
                }
              />
            ) : (
              <ul className="space-y-5">
                {apps.map((a) => (
                  <li key={a.id} className="panel p-6">
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div>
                        <p className="label text-ink/45">Reference</p>
                        <p className="mt-1 font-display text-2xl text-royal-900">{a.ref}</p>
                        <p className="mt-2 text-sm text-ink/60">
                          {a.data.programmeSlug?.replace(/-/g, " ") ?? "Programme"} · {a.level}
                        </p>
                      </div>
                      <StatusBadge status={a.status} />
                    </div>

                    <dl className="mt-6 grid gap-5 border-t border-ink/10 pt-5 sm:grid-cols-3">
                      <div>
                        <dt className="label text-ink/45">Submitted</dt>
                        <dd className="mt-1 text-sm text-royal-900">
                          {a.status === "draft" ? "Not yet submitted" : new Date(a.updatedAt).toLocaleDateString("en-GB")}
                        </dd>
                      </div>
                      <div>
                        <dt className="label text-ink/45">Documents</dt>
                        <dd className="mt-1 text-sm text-royal-900">{a.documents.length} attached</dd>
                      </div>
                      <div>
                        <dt className="label text-ink/45">Last updated</dt>
                        <dd className="mt-1 text-sm text-royal-900">{timeAgo(a.updatedAt)}</dd>
                      </div>
                    </dl>

                    {a.documents.length > 0 && (
                      <ul className="mt-5 flex flex-wrap gap-2">
                        {a.documents.map((d) => (
                          <li key={d.id} className="border border-ink/15 px-3 py-1.5 text-xs text-ink/65">
                            {d.name}
                          </li>
                        ))}
                      </ul>
                    )}

                    <div className="mt-6 flex flex-wrap items-center gap-3 border-t border-ink/10 pt-5">
                      {a.status === "draft" && (
                        <Link to="/apply" className="btn btn-primary !py-2.5">
                          Continue application
                        </Link>
                      )}
                      {(a.status === "draft" || a.status === "submitted") && (
                        <Button
                          variant="outline"
                          className="!py-2.5"
                          onClick={() => {
                            admin.withdrawApplication(a.id);
                            toast({ tone: "info", title: "Application withdrawn", body: `${a.ref} has been withdrawn.` });
                          }}
                        >
                          Withdraw
                        </Button>
                      )}
                    </div>

                    {a.history.length > 1 && (
                      <details className="mt-5">
                        <summary className="cursor-pointer text-sm font-semibold text-royal-800">Status history</summary>
                        <ol className="mt-3 space-y-2 border-l border-ink/15 pl-4">
                          {a.history.map((h, i) => (
                            <li key={i} className="text-sm text-ink/65">
                              <span className="font-medium text-royal-900">{h.status.replace(/_/g, " ")}</span> ·{" "}
                              {new Date(h.at).toLocaleString("en-GB")}
                              {h.note && <span className="block text-xs text-ink/50">{h.note}</span>}
                            </li>
                          ))}
                        </ol>
                      </details>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        {tab === "notifications" && (
          <div className="mt-10">
            {!notes ? (
              <p className="text-sm text-ink/50">Loading notifications…</p>
            ) : notes.length === 0 ? (
              <EmptyState title="No notifications." body="Admissions and system messages will appear here." />
            ) : (
              <ul className="divide-y divide-ink/10 border-y border-ink/10">
                {notes.map((n) => (
                  <li key={n.id} className="flex items-start gap-4 py-5">
                    <span
                      aria-hidden="true"
                      className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${n.read ? "bg-ink/20" : "bg-gold-500"}`}
                    />
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center gap-3">
                        <p className="font-semibold text-royal-900">{n.title}</p>
                        <span className="label text-ink/40">{n.category}</span>
                        <span className="text-xs text-ink/40">{timeAgo(n.createdAt)}</span>
                      </div>
                      <p className="mt-1.5 text-sm text-ink/65">{n.body}</p>
                      <Link to={n.href} className="link-editorial mt-2 inline-flex text-sm font-semibold text-royal-800">
                        Open →
                      </Link>
                    </div>
                    {!n.read && (
                      <Button
                        variant="outline"
                        className="!py-2 !text-[0.7rem]"
                        onClick={() => {
                          const store = JSON.parse(localStorage.getItem("biu.cms.v2") ?? "{}");
                          const next = (store.notifications ?? []).map((x: Notification) =>
                            x.id === n.id ? { ...x, read: true } : x
                          );
                          localStorage.setItem("biu.cms.v2", JSON.stringify({ ...store, notifications: next }));
                          setNotes((prev) => prev?.map((x) => (x.id === n.id ? { ...x, read: true } : x)) ?? null);
                        }}
                      >
                        Mark read
                      </Button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </section>
    </>
  );
}
