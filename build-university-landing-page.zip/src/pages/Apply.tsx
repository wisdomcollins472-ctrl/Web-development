import { useEffect, useMemo, useState } from "react";
import { Link } from "../lib/router";
import { useSeo } from "../lib/seo";
import { admin, db, LEVEL_LABEL, LEVELS, ref, type Application, type Level, type Programme } from "../lib/cms";
import { DEMO_ACCOUNTS, useAuth } from "../lib/auth";
import { Button, Field, PageHero, Spinner, StatusBadge, useToast } from "../components/ui";

type Step = 0 | 1 | 2 | 3;

const EMPTY_FORM = {
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  dob: "",
  gender: "",
  nationality: "Nigerian",
  state: "",
  address: "",
  qualification: "",
  institution: "",
  year: "",
  referee: "",
};

/* ------------------------------------------------------------------ Auth */
function AuthPanel() {
  const { login, register } = useAuth();
  const toast = useToast();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      if (mode === "login") await login(form.email, form.password);
      else await register(form.name, form.email, form.password);
      toast({ tone: "success", title: mode === "login" ? "Signed in" : "Account created", body: "You can now start your application." });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="shell grid gap-12 py-20 md:grid-cols-12 md:py-24">
      <div className="md:col-span-5">
        <h1 className="display-2 text-royal-900">Create or continue your application.</h1>
        <p className="mt-6 leading-relaxed text-ink/70">
          Sign in to continue a saved draft, or create an applicant account. Your application, documents and status stay
          private to your account.
        </p>
        <div className="mt-8 border-l-2 border-gold-500 bg-gold-500/8 px-5 py-4">
          <p className="text-sm text-ink/75">
            <strong className="font-semibold text-royal-900">Demonstration accounts.</strong> This build ships with sample
            accounts so the applicant and admissions flows can be reviewed. Replace them with real authentication in
            production.
          </p>
          <ul className="mt-3 space-y-1 text-xs text-ink/60">
            {DEMO_ACCOUNTS.map((a) => (
              <li key={a.email}>
                <span className="font-semibold text-royal-800">{a.role}</span> · {a.email} · {a.password}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="md:col-span-7 md:pl-10">
        <div className="panel p-7 md:p-9">
          <div className="flex gap-6 border-b border-ink/10" role="tablist" aria-label="Account">
            {(["login", "register"] as const).map((m) => (
              <button
                key={m}
                role="tab"
                aria-selected={mode === m}
                onClick={() => {
                  setMode(m);
                  setError("");
                }}
                className={`-mb-px border-b-2 pb-3 text-sm font-semibold tracking-wide transition-colors ${
                  mode === m ? "border-royal-800 text-royal-900" : "border-transparent text-ink/45 hover:text-royal-700"
                }`}
              >
                {m === "login" ? "Sign in" : "Create account"}
              </button>
            ))}
          </div>

          <form className="mt-7 space-y-5" onSubmit={submit} noValidate>
            {mode === "register" && (
              <Field label="Full name" required>
                {(id) => (
                  <input
                    id={id}
                    className="input"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    autoComplete="name"
                    required
                  />
                )}
              </Field>
            )}
            <Field label="Email address" required>
              {(id) => (
                <input
                  id={id}
                  type="email"
                  className="input"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  autoComplete="email"
                  required
                />
              )}
            </Field>
            <Field label="Password" required hint="Use at least 8 characters.">
              {(id) => (
                <input
                  id={id}
                  type="password"
                  className="input"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                  required
                  minLength={8}
                />
              )}
            </Field>

            {error && (
              <p role="alert" className="border-l-2 border-red-600 bg-red-50 px-4 py-3 text-sm text-red-800">
                {error}
              </p>
            )}

            <Button type="submit" variant="primary" className="w-full" disabled={busy}>
              {busy ? (
                <>
                  <Spinner /> Please wait
                </>
              ) : mode === "login" ? (
                "Sign in"
              ) : (
                "Create account"
              )}
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------- Application */
function ApplicationForm() {
  const { session } = useAuth();
  const toast = useToast();
  const [step, setStep] = useState<Step>(0);
  const [programmes, setProgrammes] = useState<Programme[]>([]);
  const [q, setQ] = useState("");
  const [level, setLevel] = useState<Level>("undergraduate");
  const [selected, setSelected] = useState("");
  const [form, setForm] = useState(EMPTY_FORM);
  const [files, setFiles] = useState<File[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [draft, setDraft] = useState<Application | null>(null);
  const [submitted, setSubmitted] = useState<Application | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    db.programmes().then(setProgrammes);
  }, []);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    return programmes.filter(
      (p) => p.level === level && (!term || `${p.title} ${p.department}`.toLowerCase().includes(term))
    );
  }, [programmes, q, level]);

  const validate = (): boolean => {
    const next: Record<string, string> = {};
    if (step === 0 && !selected) next.selected = "Choose the programme you are applying for.";
    if (step === 1) {
      if (!form.firstName.trim()) next.firstName = "Enter your first name.";
      if (!form.lastName.trim()) next.lastName = "Enter your surname.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email)) next.email = "Enter a valid email address.";
      if (!/^[+0-9\s]{7,}$/.test(form.phone)) next.phone = "Enter a valid phone number.";
      if (!form.dob) next.dob = "Enter your date of birth.";
    }
    if (step === 2) {
      if (!form.qualification.trim()) next.qualification = "Enter your highest qualification.";
      if (!form.institution.trim()) next.institution = "Enter the awarding institution.";
      if (!/^\d{4}$/.test(form.year)) next.year = "Enter a four-digit year.";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const saveDraft = async (silent = false) => {
    if (!session) return;
    setBusy(true);
    const data = { ...form, programmeSlug: selected, level };
    if (draft) {
      const updated = { ...draft, data, documents: draft.documents, updatedAt: new Date().toISOString() };
      admin.upsertApplication(updated);
      setDraft(updated);
    } else {
      const created = admin.createApplication(session.id, selected, level, data);
      setDraft(created);
    }
    setBusy(false);
    if (!silent) toast({ tone: "success", title: "Draft saved", body: "You can return and finish at any time." });
  };

  const submit = async () => {
    if (!validate()) return;
    setBusy(true);
    let app = draft;
    if (!app && session) app = admin.createApplication(session.id, selected, level, { ...form, programmeSlug: selected, level });
    if (app) {
      const withDocs: Application = {
        ...app,
        documents: files.map((f) => ({
          id: Math.random().toString(36).slice(2),
          name: f.name,
          size: f.size,
          type: f.type,
          uploadedAt: new Date().toISOString(),
        })),
      };
      admin.upsertApplication(withDocs);
      admin.submitApplication(withDocs.id);
      setSubmitted({ ...withDocs, status: "submitted" });
    }
    setBusy(false);
  };

  if (submitted) {
    return (
      <section className="shell py-24">
        <div className="mx-auto max-w-2xl text-center">
          <span className="label text-gold-600">Application received</span>
          <h1 className="display-2 mt-5 text-royal-900">Reference {submitted.ref}</h1>
          <p className="mt-6 leading-relaxed text-ink/70">
            Your application has been submitted. Track its status, upload further documents and receive notifications
            from the applicant portal.
          </p>
          <div className="mt-9 flex flex-wrap justify-center gap-3">
            <Link to="/portal" className="btn btn-primary">Go to my portal</Link>
            <Link to="/academics/programmes" className="btn btn-outline">Explore more programmes</Link>
          </div>
        </div>
      </section>
    );
  }

  const chosen = programmes.find((p) => p.slug === selected);

  return (
    <section className="shell py-16 md:py-20">
      <div className="grid gap-12 md:grid-cols-12">
        <div className="md:col-span-8">
          {/* Stepper */}
          <ol className="flex flex-wrap items-center gap-x-6 gap-y-2 border-b border-ink/10 pb-5" aria-label="Progress">
            {["Programme", "Personal details", "Education", "Documents"].map((label, i) => (
              <li key={label} className="flex items-center gap-2.5">
                <span
                  className={`flex h-6 w-6 items-center justify-center rounded-full text-[0.7rem] font-semibold ${
                    i <= step ? "bg-royal-800 text-white" : "border border-ink/20 text-ink/40"
                  }`}
                  aria-hidden="true"
                >
                  {i + 1}
                </span>
                <span className={`text-xs font-semibold tracking-wide ${i <= step ? "text-royal-900" : "text-ink/40"}`}>
                  {label.toUpperCase()}
                </span>
              </li>
            ))}
          </ol>

          <div className="mt-9">
            {step === 0 && (
              <div>
                <h1 className="display-3 text-royal-900">Which programme are you applying for?</h1>
                <p className="mt-3 text-ink/65">Search published BIU programmes by level.</p>
                <div className="mt-7 flex flex-wrap gap-2" role="group" aria-label="Level">
                  {LEVELS.map((l) => (
                    <button
                      key={l.value}
                      onClick={() => setLevel(l.value)}
                      aria-pressed={level === l.value}
                      className={`border px-3.5 py-2 text-xs font-semibold tracking-wide transition-colors ${
                        level === l.value ? "border-royal-800 bg-royal-800 text-white" : "border-ink/15 text-ink/60 hover:border-royal-700"
                      }`}
                    >
                      {l.label.toUpperCase()}
                    </button>
                  ))}
                </div>
                <div className="mt-5">
                  <Field label="Search programmes" error={errors.selected}>
                    {(id) => (
                      <input
                        id={id}
                        className="input"
                        type="search"
                        value={q}
                        onChange={(e) => setQ(e.target.value)}
                        placeholder="e.g. law, nursing, accounting"
                      />
                    )}
                  </Field>
                </div>
                <ul className="mt-5 max-h-80 divide-y divide-ink/10 overflow-y-auto border border-ink/10">
                  {filtered.map((p) => (
                    <li key={p.id}>
                      <label className="flex cursor-pointer items-center gap-3 px-4 py-3.5 transition-colors hover:bg-royal-50">
                        <input
                          type="radio"
                          name="programme"
                          value={p.slug}
                          checked={selected === p.slug}
                          onChange={() => setSelected(p.slug)}
                          className="accent-royal-800"
                        />
                        <span>
                          <span className="block text-royal-900">{p.title}</span>
                          <span className="text-xs text-ink/50">
                            {p.award} · {p.department}
                          </span>
                        </span>
                      </label>
                    </li>
                  ))}
                  {filtered.length === 0 && <li className="px-4 py-8 text-center text-sm text-ink/50">No programmes match that search.</li>}
                </ul>
              </div>
            )}

            {step === 1 && (
              <div>
                <h1 className="display-3 text-royal-900">Personal details</h1>
                <div className="mt-7 grid gap-5 sm:grid-cols-2">
                  <Field label="First name" required error={errors.firstName}>
                    {(id) => <input id={id} className="input" value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} autoComplete="given-name" />}
                  </Field>
                  <Field label="Surname" required error={errors.lastName}>
                    {(id) => <input id={id} className="input" value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} autoComplete="family-name" />}
                  </Field>
                  <Field label="Email address" required error={errors.email}>
                    {(id) => <input id={id} type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} autoComplete="email" />}
                  </Field>
                  <Field label="Phone number" required error={errors.phone} hint="Used for admissions contact only.">
                    {(id) => <input id={id} type="tel" className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} autoComplete="tel" />}
                  </Field>
                  <Field label="Date of birth" required error={errors.dob}>
                    {(id) => <input id={id} type="date" className="input" value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} />}
                  </Field>
                  <Field label="Gender">
                    {(id) => (
                      <select id={id} className="input" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                        <option value="">Prefer not to say</option>
                        <option>Female</option>
                        <option>Male</option>
                      </select>
                    )}
                  </Field>
                  <Field label="Nationality">
                    {(id) => <input id={id} className="input" value={form.nationality} onChange={(e) => setForm({ ...form, nationality: e.target.value })} />}
                  </Field>
                  <Field label="State of origin">
                    {(id) => <input id={id} className="input" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} />}
                  </Field>
                  <div className="sm:col-span-2">
                    <Field label="Contact address">
                      {(id) => <textarea id={id} className="input" rows={3} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />}
                    </Field>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div>
                <h1 className="display-3 text-royal-900">Academic background</h1>
                <p className="mt-3 text-ink/65">Enter your highest qualification so far.</p>
                <div className="mt-7 grid gap-5 sm:grid-cols-2">
                  <Field label="Highest qualification" required error={errors.qualification}>
                    {(id) => <input id={id} className="input" value={form.qualification} onChange={(e) => setForm({ ...form, qualification: e.target.value })} placeholder="e.g. WAEC/SSCE, ND, B.Sc." />}
                  </Field>
                  <Field label="Awarding institution" required error={errors.institution}>
                    {(id) => <input id={id} className="input" value={form.institution} onChange={(e) => setForm({ ...form, institution: e.target.value })} />}
                  </Field>
                  <Field label="Year completed" required error={errors.year}>
                    {(id) => <input id={id} className="input" inputMode="numeric" maxLength={4} value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} placeholder="2024" />}
                  </Field>
                  <Field label="Referee (optional)">
                    {(id) => <input id={id} className="input" value={form.referee} onChange={(e) => setForm({ ...form, referee: e.target.value })} />}
                  </Field>
                </div>
              </div>
            )}

            {step === 3 && (
              <div>
                <h1 className="display-3 text-royal-900">Documents & review</h1>
                <p className="mt-3 text-ink/65">
                  Attach any documents you have ready. Files are restricted to your application and are never shared with
                  other applicants.
                </p>
                <div className="mt-6">
                  <label htmlFor="docs" className="label text-ink/60">Upload documents</label>
                  <input
                    id="docs"
                    type="file"
                    multiple
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
                    className="input mt-2 !py-2.5"
                  />
                  <p className="mt-2 text-xs text-ink/50">PDF, JPG or PNG · maximum 5 MB per file.</p>
                  {files.length > 0 && (
                    <ul className="mt-3 divide-y divide-ink/10 border border-ink/10">
                      {files.map((f) => (
                        <li key={f.name} className="flex items-center justify-between px-4 py-2.5 text-sm">
                          <span className="text-royal-900">{f.name}</span>
                          <span className="text-xs text-ink/45">{(f.size / 1024).toFixed(0)} KB</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <div className="mt-9 border-t border-ink/10 pt-7">
                  <h2 className="label text-ink/45">Review</h2>
                  <dl className="mt-4 grid gap-4 sm:grid-cols-2">
                    {[
                      ["Programme", chosen ? `${chosen.title} (${chosen.award})` : "—"],
                      ["Level", LEVEL_LABEL[level]],
                      ["Name", `${form.firstName} ${form.lastName}`.trim() || "—"],
                      ["Email", form.email || "—"],
                      ["Phone", form.phone || "—"],
                      ["Qualification", form.qualification || "—"],
                      ["Institution", form.institution || "—"],
                      ["Documents", `${files.length} attached`],
                    ].map(([k, v]) => (
                      <div key={k}>
                        <dt className="label text-ink/45">{k}</dt>
                        <dd className="mt-1 text-sm text-royal-900">{v}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              </div>
            )}
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-3 border-t border-ink/10 pt-7">
            {step > 0 && (
              <Button variant="outline" onClick={() => setStep((s) => (s - 1) as Step)}>
                Back
              </Button>
            )}
            {step < 3 ? (
              <Button
                variant="primary"
                onClick={() => {
                  if (!validate()) return;
                  setStep((s) => (s + 1) as Step);
                }}
              >
                Continue
              </Button>
            ) : (
              <Button variant="gold" onClick={submit} disabled={busy}>
                {busy ? (
                  <>
                    <Spinner /> Submitting
                  </>
                ) : (
                  "Submit application"
                )}
              </Button>
            )}
            <Button variant="quiet" onClick={() => saveDraft()} disabled={busy || !selected}>
              Save draft
            </Button>
            {draft && (
              <span className="ml-auto flex items-center gap-3 text-xs text-ink/50">
                <StatusBadge status={draft.status} /> {draft.ref}
              </span>
            )}
          </div>
        </div>

        <aside className="md:col-span-4">
          <div className="panel sticky top-28 p-6">
            <h2 className="label text-ink/45">Need help?</h2>
            <p className="mt-4 text-sm leading-relaxed text-ink/65">
              Admissions enquiries are handled by the university's admissions office. You can also ask the Ask BIU
              assistant questions it can verify from published information.
            </p>
            <Link to="/contact" className="link-editorial mt-5 inline-flex text-sm font-semibold text-royal-800">
              Contact BIU →
            </Link>
            <div className="mt-7 border-t border-ink/10 pt-6">
              <h3 className="label text-ink/45">Your drafts</h3>
              <p className="mt-3 text-sm text-ink/60">
                {draft ? "This application is saved as a draft on this device." : "No draft started yet."}
              </p>
            </div>
          </div>
        </aside>
      </div>
    </section>
  );
}

export default function Apply() {
  const { session } = useAuth();
  useSeo({
    title: "Start Your Application | Benson Idahosa University",
    description: "Create your Benson Idahosa University application, save progress, upload documents and track your status.",
    path: "/apply",
  });

  return (
    <>
      <PageHero
        label="Application"
        title={session ? "Continue your application." : "Start your application."}
        intro={
          session
            ? `Signed in as ${session.email}. Choose a programme to begin, or continue where you left off.`
            : "Create an applicant account or sign in to start your BIU application."
        }
        crumb={[{ name: "Home", path: "/" }, { name: "Admissions", path: "/admissions" }, { name: "Apply" }]}
        aside={
          <div className="flex flex-col gap-3">
            <Link to="/portal" className="btn btn-ghost-light w-full">My portal</Link>
            <Link to="/admissions" className="btn btn-ghost-light w-full">How to apply</Link>
          </div>
        }
      />
      {session ? <ApplicationForm /> : <AuthPanel />}
    </>
  );
}

export { ref };
