import { useEffect, useState } from "react";
import { Link } from "../lib/router";
import { useSeo } from "../lib/seo";
import { db, CAMPUS_LIFE, CONTACT, REVIEWS, type Faculty, type NewsItem, type EventItem } from "../lib/cms";
import Hero from "../components/Hero";
import ProgrammeFinder from "../components/ProgrammeFinder";
import FacultyList from "../components/FacultyList";
import { Badge, ButtonLink, EmptyState, Reveal, SectionHeading, SkeletonCard, SkeletonRows } from "../components/ui";
import { usePrefersReducedMotion } from "../lib/hooks";

/* ------------------------------------------------------------ 2. Intro */
function Introduction() {
  const reduced = usePrefersReducedMotion();
  return (
    <section data-parallax-root className="relative overflow-hidden py-24 md:py-36">
      {/* Depth 1 — deep: oversized editorial numeral drifting behind the copy */}
      <div
        data-speed="0.22"
        aria-hidden="true"
        className="parallax pointer-events-none absolute -left-16 top-10 hidden font-display text-[22rem] leading-none text-royal-900/[0.04] lg:block"
      >
        BIU
      </div>

      <div className="shell relative grid items-center gap-14 md:grid-cols-12 md:gap-20">
        <div className="md:col-span-5">
          <Reveal>
            <span className="label text-royal-600">The University</span>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="display-2 mt-5 text-royal-900">
              An education with <em className="italic text-gold-600">purpose.</em>
            </h2>
          </Reveal>
          <Reveal delay={140}>
            <div className="mt-8 space-y-5 leading-relaxed text-ink/70">
              <p className="lede">
                Benson Idahosa University is a university in Ogogugbo, Benin City, named in honour of Archbishop Benson
                Idahosa — a Charismatic Pentecostal minister from Benin City.
              </p>
              <p>
                Visitors describe a campus that is serene enough for learning: neat grounds, waste bins in strategic
                locations and mature trees that give relief from the sun. Former students speak of lecturers who are
                always there to help in a time of need.
              </p>
              <p>
                The university sits on Agboma Street in Ogogugbo, with a further campus in the Legacy Campus area of
                Benin City.
              </p>
            </div>
          </Reveal>
          <Reveal delay={220}>
            <Link to="/about" className="link-editorial mt-9 inline-flex text-sm font-semibold tracking-[0.14em] text-royal-800">
              LEARN MORE <span aria-hidden="true">→</span>
            </Link>
          </Reveal>
        </div>

        <div className="relative md:col-span-7">
          {/* Depth 2 — mid: the photograph */}
          <div data-speed="0.09" className="parallax relative aspect-[4/5] overflow-hidden bg-royal-900 sm:aspect-[5/4] md:aspect-[4/5]">
            <img
              src="/images/students.jpg"
              alt="Students crossing the BIU campus lawn in late afternoon light"
              loading="lazy"
              decoding="async"
              className={`h-full w-full object-cover ${reduced ? "" : "drift"}`}
            />
            <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-royal-950/45 to-transparent" />
          </div>
          <Reveal delay={180}>
            <figure
              data-speed="-0.13"
              className="parallax absolute -bottom-8 left-4 w-[min(20rem,72%)] border border-ink/10 bg-white p-6 shadow-[0_18px_50px_rgba(10,26,51,0.12)] sm:left-8 md:-left-12"
            >
              <blockquote className="font-display text-lg leading-snug text-royal-900">
                “{REVIEWS[0].quote}”
              </blockquote>
              <figcaption className="mt-4 text-xs text-ink/50">
                {REVIEWS[0].name} · Google review
              </figcaption>
            </figure>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------- 3–4. Academic discovery */
function AcademicDiscovery() {
  return (
    <section id="academic-discovery" className="border-y border-ink/10 bg-white py-24 md:py-32">
      <div className="shell">
        <SectionHeading
          label="Academic discovery"
          title={
            <>
              Explore your <em className="italic text-gold-600">future.</em>
            </>
          }
          intro="Search every published BIU programme by level, faculty and department. Programme pages show what the university currently publishes for each award."
        />
        <div className="mt-14">
          <ProgrammeFinder />
        </div>
      </div>
    </section>
  );
}

/* --------------------------------------------------------- 5. Faculties */
function Faculties({ faculties }: { faculties: Faculty[] | null }) {
  return (
    <section className="py-24 md:py-32">
      <div className="shell">
        <SectionHeading
          label="Faculties"
          title="Eight faculties, one academic community."
          intro="BIU teaches across agriculture, arts and education, sciences, medical and health sciences, engineering, law, management and the social sciences, and postgraduate study."
          action={
            <ButtonLink to="/academics/faculties" variant="outline">
              All faculties
            </ButtonLink>
          }
        />
        <div className="mt-12">
          {faculties ? (
            <FacultyList faculties={faculties} />
          ) : (
            <SkeletonRows rows={8} />
          )}
        </div>
      </div>
    </section>
  );
}

/* ----------------------------------------------------------- 6. Why BIU */
function WhyBIU() {
  const items = [
    {
      n: "01",
      title: "A serene place to learn",
      body: "Visitors describe an atmosphere that is serene enough for learning, with shade that protects you from the scorching sun.",
      source: REVIEWS[0].name,
    },
    {
      n: "02",
      title: "Lecturers who show up",
      body: "Former students describe lecturers as simply awesome — always there to help you out in your time of need.",
      source: REVIEWS[1].name,
    },
    {
      n: "03",
      title: "A named legacy",
      body: "The university carries the name of Archbishop Benson Idahosa, reflecting the beliefs he was known for in Benin City.",
      source: REVIEWS[2].name,
    },
  ];
  return (
    <section className="relative overflow-hidden bg-royal-900 py-24 text-white md:py-32">
      <div
        aria-hidden="true"
        className="absolute inset-0 opacity-[0.16]"
        style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, rgb(255 255 255 / 0.6) 1px, transparent 0)",
          backgroundSize: "28px 28px",
        }}
      />
      <div className="shell relative grid gap-14 md:grid-cols-12">
        <div className="md:col-span-4">
          <Reveal>
            <span className="label text-gold-400">Why BIU</span>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="display-2 mt-5 text-white">What the community says.</h2>
          </Reveal>
          <Reveal delay={140}>
            <p className="mt-6 leading-relaxed text-white/65">
              BIU holds a {CONTACT.rating.value} rating from {CONTACT.rating.count} reviews on its public listing. These
              are the themes visitors and former students return to.
            </p>
          </Reveal>
          <Reveal delay={200}>
            <Link to="/campus-life" className="link-editorial mt-8 inline-flex text-sm font-semibold tracking-[0.14em] text-gold-400">
              CAMPUS LIFE <span aria-hidden="true">→</span>
            </Link>
          </Reveal>
        </div>
        <div className="md:col-span-8">
          <ul className="grid gap-px bg-white/10 sm:grid-cols-3">
            {items.map((i, idx) => (
              <li key={i.n} className="bg-royal-900 p-7">
                <Reveal delay={idx * 110}>
                  <span className="font-display text-3xl text-gold-500">{i.n}</span>
                  <h3 className="mt-5 font-display text-2xl leading-snug text-white">{i.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-white/65">{i.body}</p>
                  <p className="mt-5 text-xs text-white/40">Attributed to {i.source}, Google review</p>
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------- 7. Campus life */
function CampusLife() {
  return (
    <section className="py-24 md:py-32">
      <div className="shell">
        <SectionHeading
          label="Campus life"
          title="Life beyond the lecture hall."
          intro="Accommodation, student affairs, sport, societies, chapel, health, dining and events. Imagery is illustrative; each area is managed from the CMS."
          action={
            <ButtonLink to="/campus-life" variant="outline">
              Explore campus life
            </ButtonLink>
          }
        />
      </div>
      {/* Horizontal rail */}
      <div className="mt-14 overflow-x-auto no-bar" tabIndex={0} aria-label="Campus life gallery">
        <ul className="flex gap-5 px-5 pb-2 md:px-8" style={{ width: "max-content" }}>
          {CAMPUS_LIFE.map((c, i) => (
            <li key={c.name} className="w-[76vw] max-w-[22rem] sm:w-[42vw]">
              <Reveal delay={i * 70}>
                <Link to="/campus-life" className="group block">
                  <div className="relative aspect-[3/4] overflow-hidden bg-royal-900">
                    <img
                      src={c.image}
                      alt={`${c.name} at Benson Idahosa University (illustrative)`}
                      loading="lazy"
                      decoding="async"
                      className="h-full w-full object-cover transition-transform duration-[1.4s] group-hover:scale-[1.04]"
                    />
                    <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-royal-950/85 via-royal-950/10 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-6 text-white">
                      <Badge tone="dark">{c.tag}</Badge>
                      <h3 className="mt-3 font-display text-2xl">{c.name}</h3>
                      <p className="mt-1 text-sm text-white/70">{c.note}</p>
                    </div>
                  </div>
                </Link>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

/* ---------------------------------------------------- 8. Research & 9. News */
function Research() {
  return (
      <section id="research" data-parallax-root className="border-y border-ink/10 bg-white py-24 md:py-32">
        <div
          data-speed="0.16"
          aria-hidden="true"
          className="parallax pointer-events-none absolute right-0 top-0 hidden font-display text-[16rem] leading-none text-royal-900/[0.04] lg:block"
        >
          02
        </div>
        <div className="shell relative grid gap-14 md:grid-cols-12 md:gap-20">
        <div className="md:col-span-6">
          <Reveal>
            <span className="label text-royal-600">Research & innovation</span>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="display-2 mt-5 text-royal-900">
              Research that moves knowledge <em className="italic text-gold-600">forward.</em>
            </h2>
          </Reveal>
          <Reveal delay={140}>
            <p className="mt-7 leading-relaxed text-ink/70">
              Research centres, areas, publications and partnerships are published by the university as they are
              confirmed. Until then, this section remains an editable CMS structure rather than placeholder claims.
            </p>
          </Reveal>
          <Reveal delay={200}>
            <div className="mt-9 flex flex-wrap gap-3">
              <ButtonLink to="/research" variant="primary">
                Research at BIU
              </ButtonLink>
              <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="btn btn-outline">
                Official site ↗
              </a>
            </div>
          </Reveal>
        </div>
        <div className="md:col-span-6">
          <Reveal delay={160}>
            <div data-speed="0.07" className="parallax relative aspect-[4/3] overflow-hidden bg-royal-900">
              <img
                src="/images/lab.jpg"
                alt="Students working in a university laboratory (illustrative)"
                loading="lazy"
                decoding="async"
                className="h-full w-full object-cover"
              />
            </div>
          </Reveal>
          <Reveal delay={240}>
            <ul className="mt-6 grid grid-cols-2 gap-px bg-ink/10 text-center">
              {["Research areas", "Centres", "Publications", "Partnerships"].map((x) => (
                <li key={x} className="bg-white px-4 py-6">
                  <span className="label text-ink/40">CMS</span>
                  <p className="mt-2 font-display text-lg text-royal-900">{x}</p>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function News({ news }: { news: NewsItem[] | null }) {
  return (
    <section className="py-24 md:py-32">
      <div className="shell">
        <SectionHeading
          label="Newsroom"
          title="Latest from BIU."
          action={
            <ButtonLink to="/news" variant="outline">
              All news
            </ButtonLink>
          }
        />
        <div className="mt-12">
          {!news ? (
            <div className="grid gap-5 md:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <SkeletonCard key={i} />
              ))}
            </div>
          ) : news.length === 0 ? (
            <EmptyState
              icon="✳"
              title="No published articles yet."
              body="News, announcements and stories are published through the BIU newsroom CMS and appear here automatically."
              action={
                <a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="btn btn-outline">
                  Read news on biu.edu.ng ↗
                </a>
              }
            />
          ) : (
            <ul className="grid gap-5 md:grid-cols-3">
              {news.slice(0, 3).map((n, i) => (
                <li key={n.id}>
                  <Reveal delay={i * 90}>
                    <Link to={`/news/${n.slug}`} className="panel group block overflow-hidden">
                      {n.coverImage && (
                        <div className="aspect-[16/10] overflow-hidden bg-royal-100">
                          <img src={n.coverImage} alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-105" />
                        </div>
                      )}
                      <div className="p-6">
                        <div className="flex items-center gap-3">
                          <span className="label text-royal-600">{n.category}</span>
                          <span className="text-xs text-ink/40">
                            {new Date(n.publishedAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                          </span>
                        </div>
                        <h3 className="mt-3 font-display text-2xl leading-snug text-royal-900 group-hover:text-royal-700">{n.title}</h3>
                        <p className="mt-3 text-sm leading-relaxed text-ink/60">{n.excerpt}</p>
                      </div>
                    </Link>
                  </Reveal>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
  );
}

/* ----------------------------------------------------------- 10. Events */
function Events({ events }: { events: EventItem[] | null }) {
  const upcoming = events?.filter((e) => e.startDate >= new Date().toISOString()) ?? [];
  return (
    <section className="border-y border-ink/10 bg-white py-24 md:py-32">
      <div className="shell">
        <SectionHeading
          label="Events"
          title="What's coming up."
          action={
            <ButtonLink to="/events" variant="outline">
              All events
            </ButtonLink>
          }
        />
        <div className="mt-12">
          {!events ? (
            <SkeletonRows rows={3} />
          ) : upcoming.length === 0 ? (
            <EmptyState
              icon="◷"
              title="No upcoming events."
              body="Events are published through the CMS and listed here automatically once scheduled."
            />
          ) : (
            <ul className="divide-y divide-ink/10">
              {upcoming.slice(0, 4).map((e) => (
                <li key={e.id}>
                  <Link to={`/events/${e.slug}`} className="group grid gap-4 py-6 md:grid-cols-12 md:items-center">
                    <div className="md:col-span-2">
                      <span className="font-display text-3xl text-royal-800">
                        {new Date(e.startDate).toLocaleDateString("en-GB", { day: "2-digit" })}
                      </span>
                      <span className="label mt-1 block text-ink/45">
                        {new Date(e.startDate).toLocaleDateString("en-GB", { month: "short", year: "numeric" })}
                      </span>
                    </div>
                    <div className="md:col-span-7">
                      <h3 className="font-display text-2xl text-royal-900 group-hover:text-royal-700">{e.title}</h3>
                      <p className="mt-1 text-sm text-ink/55">{e.location}</p>
                    </div>
                    <div className="md:col-span-3 md:text-right">
                      <span className="label text-royal-600">{e.category}</span>
                      <p className="mt-1 text-sm text-ink/50">View event →</p>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
  );
}

/* --------------------------------------------- 11–12. Admissions & resources */
function AdmissionsCTA() {
  return (
    <section className="relative overflow-hidden bg-royal-950 py-24 text-white md:py-32">
      <img
        src="/images/hero-poster.jpg"
        alt=""
        aria-hidden="true"
        loading="lazy"
        className="absolute inset-0 h-full w-full object-cover opacity-25"
      />
      <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-r from-royal-950 via-royal-950/85 to-royal-950/40" />
      <div className="shell relative">
        <Reveal>
          <span className="label text-gold-400">Admissions</span>
        </Reveal>
        <Reveal delay={80}>
          <h2 className="display-2 mt-5 max-w-3xl text-white">Your next chapter starts here.</h2>
        </Reveal>
        <Reveal delay={140}>
          <p className="lede mt-6 max-w-xl text-white/70">
            Choose a programme, create your application, upload your documents and track your status from the applicant
            portal.
          </p>
        </Reveal>
        <Reveal delay={200}>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link to="/apply" className="btn btn-gold">
              Start your application
            </Link>
            <Link to="/admissions" className="btn btn-ghost-light">
              How to apply
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Resources() {
  const links = [
    { title: "Student Hub", body: "Portal, e-learning, CBT, library and student support.", to: "/student-hub" },
    { title: "Staff Hub", body: "Staff portal and academic systems.", to: "/staff-hub" },
    { title: "Document Centre", body: "Admissions, academic and policy documents.", to: "/documents" },
    { title: "Contact BIU", body: "Reach the university by phone, address or enquiry form.", to: "/contact" },
  ];
  return (
    <section className="py-24 md:py-32">
      <div className="shell">
        <SectionHeading label="Student resources" title="Everything in one place." />
        <ul className="mt-12 grid gap-px bg-ink/10 md:grid-cols-2 lg:grid-cols-4">
          {links.map((l, i) => (
            <li key={l.title} className="bg-parchment">
              <Reveal delay={i * 80}>
                <Link to={l.to} className="group flex h-full flex-col p-7">
                  <h3 className="font-display text-2xl text-royal-900 group-hover:text-royal-700">{l.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-ink/60">{l.body}</p>
                  <span className="mt-6 text-sm font-semibold text-royal-800">
                    Open <span aria-hidden="true" className="inline-block transition-transform group-hover:translate-x-1">→</span>
                  </span>
                </Link>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ Page */
export default function Home() {
  const [faculties, setFaculties] = useState<Faculty[] | null>(null);
  const [news, setNews] = useState<NewsItem[] | null>(null);
  const [events, setEvents] = useState<EventItem[] | null>(null);

  useEffect(() => {
    let alive = true;
    Promise.all([db.faculties(), db.news(), db.events()])
      .then(([f, n, e]) => {
        if (!alive) return;
        setFaculties(f);
        setNews(n);
        setEvents(e);
      })
      .catch(() => {
        if (alive) {
          setFaculties([]);
          setNews([]);
          setEvents([]);
        }
      });
    return () => {
      alive = false;
    };
  }, []);

  useSeo({
    title: "Benson Idahosa University — Where Purpose Becomes Possibility",
    description:
      "A university experience designed to develop academically excellent, professionally capable and purpose-driven leaders. BIU, Benin City, Edo State.",
    path: "/",
    jsonLd: {
      "@context": "https://schema.org",
      "@type": "WebSite",
      name: "Benson Idahosa University",
      url: CONTACT.website,
      potentialAction: {
        "@type": "SearchAction",
        target: `${window.location.origin}${window.location.pathname}#/academics/programmes?q={search_term_string}`,
        "query-input": "required name=search_term_string",
      },
    },
  });

  return (
    <>
      <Hero />
      <Introduction />
      <AcademicDiscovery />
      <Faculties faculties={faculties} />
      <WhyBIU />
      <CampusLife />
      <Research />
      <News news={news} />
      <Events events={events} />
      <AdmissionsCTA />
      <Resources />
    </>
  );
}
