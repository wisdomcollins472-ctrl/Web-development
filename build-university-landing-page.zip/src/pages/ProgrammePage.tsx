import { useEffect, useState } from "react";
import { Link, useRoute } from "../lib/router";
import { useSeo, breadcrumbLd } from "../lib/seo";
import { db, LEVEL_LABEL, type Programme } from "../lib/cms";
import { Badge, ButtonLink, EmptyState, Reveal, SkeletonText } from "../components/ui";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Reveal>
      <section className="mt-14">
        <h2 className="display-3 text-royal-900">{title}</h2>
        <div className="mt-5">{children}</div>
      </section>
    </Reveal>
  );
}

export default function ProgrammePage({ slug: slugProp }: { slug?: string }) {
  const { query } = useRoute();
  const slug = slugProp ?? query.get("slug") ?? "";
  const [programme, setProgramme] = useState<Programme | null | undefined>(undefined);
  const [related, setRelated] = useState<Programme[]>([]);

  useEffect(() => {
    let alive = true;
    setProgramme(undefined);
    Promise.all([db.programme(slug), db.programmes()]).then(([p, all]) => {
      if (!alive) return;
      setProgramme(p);
      setRelated(all.filter((x) => x.slug !== slug && x.facultySlug === p?.facultySlug).slice(0, 4));
    });
    return () => {
      alive = false;
    };
  }, [slug]);

  useSeo({
    title: programme ? `${programme.title} (${programme.award}) | Benson Idahosa University` : "Programme | Benson Idahosa University",
    description:
      programme?.overview?.slice(0, 155) ??
      `${programme?.title ?? "Programme"} at Benson Idahosa University — faculty, department, level and duration.`,
    path: `/academics/programmes/${slug}`,
    jsonLd: programme
      ? [
          breadcrumbLd([
            { name: "Home", path: "/" },
            { name: "Academics", path: "/academics" },
            { name: "Programmes", path: "/academics/programmes" },
            { name: programme.title, path: `/academics/programmes/${programme.slug}` },
          ]),
          {
            "@context": "https://schema.org",
            "@type": "Course",
            name: programme.title,
            description: programme.overview || `${programme.award} programme at Benson Idahosa University.`,
            provider: { "@type": "CollegeOrUniversity", name: "Benson Idahosa University" },
          },
        ]
      : undefined,
  });

  if (programme === undefined) {
    return (
      <div className="shell py-24">
        <SkeletonText lines={6} />
      </div>
    );
  }
  if (!programme) {
    return (
      <div className="shell py-24">
        <EmptyState
          title="Programme not found."
          body="This programme may have been unpublished. Search the full programme list instead."
          action={
            <ButtonLink to="/academics/programmes" variant="primary">
              Programme finder
            </ButtonLink>
          }
        />
      </div>
    );
  }

  const CmsNote = ({ field }: { field: string }) => (
    <div className="border-l-2 border-gold-500 bg-gold-500/8 px-5 py-4">
      <p className="text-sm text-ink/70">
        <strong className="font-semibold text-royal-900">{field}</strong> has not been published for this programme yet.
        It is an editable CMS field and will appear here as soon as the university provides it.
      </p>
    </div>
  );

  return (
    <>
      <header className="relative overflow-hidden border-b border-ink/10 bg-royal-900 text-white">
        <div className="shell py-14 md:py-20">
          <nav aria-label="Breadcrumb" className="mb-8 text-xs text-white/50">
            <ol className="flex flex-wrap items-center gap-2">
              <li>
                <Link to="/" className="hover:text-gold-400">Home</Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link to="/academics" className="hover:text-gold-400">Academics</Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link to="/academics/programmes" className="hover:text-gold-400">Programmes</Link>
              </li>
              <li aria-hidden="true">/</li>
              <li aria-current="page" className="text-white/80">{programme.title}</li>
            </ol>
          </nav>
          <div className="flex flex-wrap items-center gap-3">
            <Badge tone="dark">{LEVEL_LABEL[programme.level]}</Badge>
            {programme.award && <Badge tone="gold">{programme.award}</Badge>}
            <Link to={`/academics/faculties/${programme.facultySlug}`} className="text-sm text-white/70 underline decoration-white/30 underline-offset-4 hover:text-gold-400">
              {programme.facultySlug.replace(/-/g, " ")}
            </Link>
          </div>
          <h1 className="display-1 mt-6 max-w-4xl text-white">{programme.title}</h1>
          <dl className="mt-10 grid gap-6 border-t border-white/15 pt-8 sm:grid-cols-3">
            {[
              ["Faculty", programme.facultySlug.replace(/-/g, " ")],
              ["Department", programme.department],
              ["Duration", programme.duration || "Published per session"],
            ].map(([k, v]) => (
              <div key={k}>
                <dt className="label text-white/45">{k}</dt>
                <dd className="mt-2 text-white/85">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </header>

      <div className="shell grid gap-16 py-20 md:grid-cols-12 md:py-24">
        <div className="md:col-span-7 lg:col-span-8">
          <Section title="Overview">
            {programme.overview ? <p className="leading-relaxed text-ink/70">{programme.overview}</p> : <CmsNote field="Programme overview" />}
          </Section>

          <Section title="Programme objectives">
            {programme.objectives.length ? (
              <ul className="space-y-3">
                {programme.objectives.map((o) => (
                  <li key={o} className="flex gap-3 leading-relaxed text-ink/70">
                    <span aria-hidden="true" className="mt-2 h-1.5 w-1.5 shrink-0 bg-gold-500" />
                    {o}
                  </li>
                ))}
              </ul>
            ) : (
              <CmsNote field="Programme objectives" />
            )}
          </Section>

          <Section title="Admission requirements">
            {programme.requirements.length ? (
              <ul className="space-y-3">
                {programme.requirements.map((r) => (
                  <li key={r} className="flex gap-3 leading-relaxed text-ink/70">
                    <span aria-hidden="true" className="mt-2 h-1.5 w-1.5 shrink-0 bg-gold-500" />
                    {r}
                  </li>
                ))}
              </ul>
            ) : (
              <CmsNote field="Admission requirements" />
            )}
          </Section>

          <Section title="Career opportunities">
            {programme.careers.length ? (
              <ul className="flex flex-wrap gap-2">
                {programme.careers.map((c) => (
                  <li key={c} className="border border-ink/15 px-3 py-1.5 text-sm text-ink/70">{c}</li>
                ))}
              </ul>
            ) : (
              <CmsNote field="Career opportunities" />
            )}
          </Section>
        </div>

        <aside className="md:col-span-5 lg:col-span-4">
          <div className="panel sticky top-28 p-7">
            <h2 className="label text-ink/45">Programme</h2>
            <dl className="mt-5 space-y-5 text-sm">
              {[
                ["Level", LEVEL_LABEL[programme.level]],
                ["Award", programme.award || "—"],
                ["Duration", programme.duration || "Published per session"],
                ["Department", programme.department],
              ].map(([k, v]) => (
                <div key={k}>
                  <dt className="label text-ink/45">{k}</dt>
                  <dd className="mt-1.5 text-royal-900">{v}</dd>
                </div>
              ))}
            </dl>
            <div className="mt-7 border-t border-ink/10 pt-6">
              <ButtonLink to="/apply" variant="gold" className="w-full">
                Apply now
              </ButtonLink>
              <ButtonLink to="/admissions" variant="outline" className="mt-3 w-full">
                Admissions information
              </ButtonLink>
            </div>
            {programme.sources.length > 0 && (
              <p className="mt-6 text-xs leading-relaxed text-ink/40">
                Programme listing source:{" "}
                {programme.sources.map((s, i) => (
                  <span key={s.url}>
                    {i > 0 && ", "}
                    <a href={s.url} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2 hover:text-royal-700">
                      {s.label}
                    </a>
                  </span>
                ))}
                .
              </p>
            )}
          </div>
        </aside>
      </div>

      {related.length > 0 && (
        <section className="border-t border-ink/10 bg-white py-16">
          <div className="shell">
            <h2 className="display-3 text-royal-900">Related programmes</h2>
            <ul className="mt-8 grid gap-px bg-ink/10 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((r) => (
                <li key={r.id} className="bg-parchment">
                  <Link to={`/academics/programmes/${r.slug}`} className="group block h-full p-6">
                    <span className="label text-royal-600">{LEVEL_LABEL[r.level]}</span>
                    <h3 className="mt-3 font-display text-xl leading-snug text-royal-900 group-hover:text-royal-700">{r.title}</h3>
                    <p className="mt-2 text-sm text-ink/50">{r.award}</p>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}
    </>
  );
}
