import { Link } from "../lib/router";
import { useSeo, breadcrumbLd } from "../lib/seo";
import { CONTACT } from "../lib/cms";
import { Field, PageHero, Reveal, SectionHeading, Button, useToast } from "../components/ui";
import { useState } from "react";
import { createEnquiry } from "../lib/cms";

/* ============================================================== STUDENT HUB */
export function StudentHub() {
  useSeo({
    title: "Student Hub | Benson Idahosa University",
    description: "Student portal, e-learning, CBT, library, academic calendar, accommodation, fees and student support.",
    path: "/student-hub",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "Student Hub", path: "/student-hub" },
    ]),
  });

  const groups = [
    {
      title: "Systems",
      links: [
        { label: "Student Portal", href: CONTACT.portal, note: "Registration, results and fees" },
        { label: "E-learning", href: CONTACT.portal, note: "Course materials online" },
        { label: "CBT", href: CONTACT.portal, note: "Computer-based testing" },
        { label: "Library", href: CONTACT.website, note: "Catalogue and resources" },
      ],
    },
    {
      title: "Academic",
      links: [
        { label: "Programme finder", to: "/academics/programmes", note: "Search published programmes" },
        { label: "Faculties", to: "/academics/faculties", note: "Faculty directory" },
        { label: "Academic calendar", to: "/documents?category=Calendars", note: "Published by the university" },
        { label: "Documents", to: "/documents", note: "Forms and handbooks" },
      ],
    },
    {
      title: "Support",
      links: [
        { label: "Student Affairs", to: "/campus-life?category=Student%20Affairs", note: "Student welfare" },
        { label: "Accommodation", to: "/campus-life?category=Accommodation", note: "Where students live" },
        { label: "Health", to: "/campus-life?category=Health", note: "Campus medical care" },
        { label: "Contact BIU", to: "/contact", note: "Reach the university" },
      ],
    },
  ];

  return (
    <>
      <PageHero
        label="Student hub"
        title="Everything students need."
        intro="Existing BIU systems are linked directly rather than duplicated. Where a service is published by the university, it opens here."
        crumb={[{ name: "Home", path: "/" }, { name: "Student Hub" }]}
        aside={
          <a href={CONTACT.portal} target="_blank" rel="noopener noreferrer" className="btn btn-gold">
            Student portal ↗
          </a>
        }
      />
      <section className="shell py-16 md:py-20">
        <div className="grid gap-px bg-ink/10 lg:grid-cols-3">
          {groups.map((g, i) => (
            <div key={g.title} className="bg-parchment">
              <Reveal delay={i * 90}>
                <div className="h-full p-8">
                  <h2 className="label text-royal-600">{g.title}</h2>
                  <ul className="mt-6 divide-y divide-ink/10">
                    {g.links.map((l) => (
                      <li key={l.label}>
                        {"href" in l && l.href ? (
                          <a href={l.href} target="_blank" rel="noopener noreferrer" className="group block py-4">
                            <span className="flex items-center justify-between gap-3">
                              <span className="font-display text-xl text-royal-900 group-hover:text-royal-700">{l.label}</span>
                              <span aria-hidden="true" className="text-ink/30">↗</span>
                            </span>
                            <span className="mt-1 block text-sm text-ink/55">{l.note}</span>
                          </a>
                        ) : (
                          <Link to={"to" in l && l.to ? l.to : "/"} className="group block py-4">
                            <span className="flex items-center justify-between gap-3">
                              <span className="font-display text-xl text-royal-900 group-hover:text-royal-700">{l.label}</span>
                              <span aria-hidden="true" className="text-ink/30 transition-transform group-hover:translate-x-1">→</span>
                            </span>
                            <span className="mt-1 block text-sm text-ink/55">{l.note}</span>
                          </Link>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>
            </div>
          ))}
        </div>
        <p className="mt-8 text-sm text-ink/50">
          Links open the university's published services. If a system is not listed here, it has not been published
          rather than omitted.
        </p>
      </section>
    </>
  );
}

/* ================================================================ STAFF HUB */
export function StaffHub() {
  useSeo({
    title: "Staff Hub | Benson Idahosa University",
    description: "Staff portal, e-learning, academic systems, documents and support.",
    path: "/staff-hub",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "Staff Hub", path: "/staff-hub" },
    ]),
  });

  const links = [
    { label: "Staff Portal", href: CONTACT.portal, note: "Staff systems" },
    { label: "E-learning", href: CONTACT.portal, note: "Course delivery" },
    { label: "Academic systems", href: CONTACT.website, note: "Published services" },
    { label: "Documents", to: "/documents", note: "Policies and forms" },
    { label: "Support", to: "/contact", note: "Contact the university" },
  ];

  return (
    <>
      <PageHero
        label="Staff hub"
        title="Resources for staff."
        intro="Existing BIU staff systems are linked directly. Nothing here duplicates a service the university already runs."
        crumb={[{ name: "Home", path: "/" }, { name: "Staff Hub" }]}
      />
      <section className="shell py-16 md:py-20">
        <ul className="divide-y divide-ink/10 border-y border-ink/10">
          {links.map((l, i) => (
            <li key={l.label}>
              <Reveal delay={i * 70}>
                {"href" in l && l.href ? (
                  <a href={l.href} target="_blank" rel="noopener noreferrer" className="group flex items-center justify-between gap-4 py-6">
                    <span>
                      <span className="block font-display text-2xl text-royal-900 group-hover:text-royal-700">{l.label}</span>
                      <span className="mt-1 block text-sm text-ink/55">{l.note}</span>
                    </span>
                    <span aria-hidden="true" className="text-ink/30">↗</span>
                  </a>
                ) : (
                  <Link to={"to" in l && l.to ? l.to : "/"} className="group flex items-center justify-between gap-4 py-6">
                    <span>
                      <span className="block font-display text-2xl text-royal-900 group-hover:text-royal-700">{l.label}</span>
                      <span className="mt-1 block text-sm text-ink/55">{l.note}</span>
                    </span>
                    <span aria-hidden="true" className="text-ink/30 transition-transform group-hover:translate-x-1">→</span>
                  </Link>
                )}
              </Reveal>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}

/* ================================================================== CONTACT */
export function Contact() {
  const toast = useToast();
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  useSeo({
    title: "Contact BIU | Benson Idahosa University",
    description: "Contact Benson Idahosa University — address, telephone, directions and enquiry form.",
    path: "/contact",
    jsonLd: breadcrumbLd([
      { name: "Home", path: "/" },
      { name: "Contact", path: "/contact" },
    ]),
  });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!form.name.trim()) next.name = "Enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email)) next.email = "Enter a valid email address.";
    if (form.phone && !/^[+0-9\s]{7,}$/.test(form.phone)) next.phone = "Enter a valid phone number.";
    if (!form.subject.trim()) next.subject = "Enter a subject.";
    if (form.message.trim().length < 10) next.message = "Please give us a little more detail.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    setBusy(true);
    // Submissions are stored securely; email notifications are sent server-side.
    setTimeout(() => {
      createEnquiry({ ...form, message: form.message.trim() });
      setBusy(false);
      setSent(true);
      toast({ tone: "success", title: "Enquiry sent", body: "The appropriate BIU office will respond." });
    }, 500);
  };

  return (
    <>
      <PageHero
        label="Contact"
        title="Contact Benson Idahosa University."
        intro="Reach the university by telephone, find the campus on Google Maps, or send an enquiry to the appropriate office."
        crumb={[{ name: "Home", path: "/" }, { name: "Contact" }]}
      />

      <section className="shell grid gap-12 py-16 md:grid-cols-12 md:py-20">
        <div className="md:col-span-5">
          <SectionHeading label="Visit & call" title="Find us." />
          <div className="mt-8 space-y-8">
            <div>
              <h3 className="label text-ink/45">Telephone</h3>
              <ul className="mt-3 space-y-2">
                {CONTACT.phones.map((p) => (
                  <li key={p.tel}>
                    <a href={`tel:${p.tel}`} className="link-editorial font-display text-2xl text-royal-900">
                      {p.display}
                    </a>
                    <span className="mt-0.5 block text-xs text-ink/45">{p.label}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="label text-ink/45">Campus</h3>
              <a
                href={CONTACT.addresses[0].href}
                target="_blank"
                rel="noopener noreferrer"
                className="link-editorial mt-3 block font-display text-xl leading-snug text-royal-900"
              >
                {CONTACT.addresses[0].lines.map((l) => (
                  <span key={l} className="block">{l}</span>
                ))}
              </a>
              <a
                href={CONTACT.plusCode.href}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-block text-sm text-ink/55 underline decoration-gold-500 underline-offset-4"
              >
                Plus code {CONTACT.plusCode.code}
              </a>
              <div className="mt-5">
                <a href={CONTACT.addresses[0].href} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
                  Get directions
                </a>
              </div>
            </div>
            <div>
              <h3 className="label text-ink/45">Mailing address</h3>
              <p className="mt-3 leading-relaxed text-ink/70">{CONTACT.addresses[1].lines.join(", ")}</p>
            </div>
            <div>
              <h3 className="label text-ink/45">Hours</h3>
              <p className="mt-3 leading-relaxed text-ink/70">
                {CONTACT.hours.summary}. {CONTACT.hours.note}
              </p>
            </div>
          </div>
        </div>

        <div className="md:col-span-7">
          <div className="panel p-7 md:p-9">
            <h2 className="display-3 text-royal-900">Send an enquiry.</h2>
            <p className="mt-3 text-sm text-ink/60">
              Enquiries are stored securely and routed to the appropriate office. Please do not send sensitive personal
              documents by email.
            </p>

            {sent ? (
              <div className="mt-8 border-l-2 border-emerald-600 bg-emerald-50 px-6 py-5" role="status">
                <h3 className="font-display text-2xl text-emerald-900">Thank you — your enquiry has been received.</h3>
                <p className="mt-2 text-sm text-emerald-900/75">
                  The appropriate BIU office will respond. You can also call {CONTACT.phones[0].display}.
                </p>
                <Button variant="outline" className="mt-5" onClick={() => { setSent(false); setForm({ name: "", email: "", phone: "", subject: "", message: "" }); }}>
                  Send another enquiry
                </Button>
              </div>
            ) : (
              <form className="mt-8 space-y-5" onSubmit={submit} noValidate>
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label="Full name" required error={errors.name}>
                    {(id) => (
                      <input id={id} className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} autoComplete="name" />
                    )}
                  </Field>
                  <Field label="Email address" required error={errors.email}>
                    {(id) => (
                      <input id={id} type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} autoComplete="email" />
                    )}
                  </Field>
                  <Field label="Phone number" error={errors.phone}>
                    {(id) => (
                      <input id={id} type="tel" className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} autoComplete="tel" />
                    )}
                  </Field>
                  <Field label="Subject" required error={errors.subject}>
                    {(id) => (
                      <select id={id} className="input" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}>
                        <option value="">Select a subject</option>
                        <option>Admissions</option>
                        <option>Academic programmes</option>
                        <option>Campus visit</option>
                        <option>Student support</option>
                        <option>Other</option>
                      </select>
                    )}
                  </Field>
                </div>
                <Field label="Message" required error={errors.message}>
                  {(id) => (
                    <textarea id={id} className="input" rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
                  )}
                </Field>
                <Button type="submit" variant="primary" disabled={busy}>
                  {busy ? "Sending…" : "Send enquiry"}
                </Button>
              </form>
            )}
          </div>
        </div>
      </section>
    </>
  );
}

/* ==================================================================== 404 */
export function NotFound() {
  useSeo({
    title: "Page not found | Benson Idahosa University",
    description: "The page you were looking for could not be found.",
    path: "/404",
  });
  return (
    <section className="shell py-32 text-center">
      <span className="label text-gold-600">404</span>
      <h1 className="display-1 mt-5 text-royal-900">This page could not be found.</h1>
      <p className="lede mx-auto mt-6 max-w-xl text-ink/65">
        The link may be out of date. Try the programme finder, admissions, or return to the homepage.
      </p>
      <div className="mt-10 flex flex-wrap justify-center gap-3">
        <Link to="/" className="btn btn-primary">Homepage</Link>
        <Link to="/academics/programmes" className="btn btn-outline">Programme finder</Link>
        <Link to="/contact" className="btn btn-outline">Contact BIU</Link>
      </div>
    </section>
  );
}
