import { useEffect, useState } from "react";
import { Link, RouterProvider, useRoute } from "./lib/router";
import { AuthProvider } from "./lib/auth";
import { useParallax, usePrefersReducedMotion } from "./lib/hooks";
import { db, subscribe, type Announcement } from "./lib/cms";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import SearchOverlay from "./components/SearchOverlay";
import AskBIU from "./components/AskBIU";
import { ToastProvider } from "./components/ui";

import Home from "./pages/Home";
import Academics from "./pages/Academics";
import FacultyPage from "./pages/FacultyPage";
import ProgrammePage from "./pages/ProgrammePage";
import Admissions from "./pages/Admissions";
import Apply from "./pages/Apply";
import Portal from "./pages/Portal";
import Admin from "./pages/Admin";
import About, { Leadership } from "./pages/About";
import { CampusLife, Research, News, NewsArticle, Events, EventDetail, Documents } from "./pages/Content";
import { StudentHub, StaffHub, Contact, NotFound } from "./pages/Hubs";

/** Announcement banner — only renders when an active announcement is published. */
function AnnouncementBanner() {
  const [items, setItems] = useState<Announcement[] | null>(null);
  const [dismissed, setDismissed] = useState<string[]>([]);
  useEffect(() => {
    let alive = true;
    db.announcements().then((a) => alive && setItems(a));
    const unsub = subscribe(() => db.announcements().then((a) => alive && setItems(a)));
    return () => {
      alive = false;
      unsub();
    };
  }, []);
  const active = (items ?? []).filter((a) => !dismissed.includes(a.id))[0];
  if (!active) return null;
  return (
    <div className="relative z-[65] bg-royal-800 text-white" role="region" aria-label="Announcement">
      <div className="shell flex items-center justify-center gap-4 py-2.5 text-center text-xs sm:text-sm">
        <span className="hidden font-semibold tracking-[0.18em] text-gold-400 sm:inline">ANNOUNCEMENT</span>
        <p className="text-white/85">{active.title}</p>
        <Link to={active.href} className="link-editorial shrink-0 font-semibold text-gold-400">
          {active.cta} →
        </Link>
        <button
          onClick={() => setDismissed((d) => [...d, active.id])}
          aria-label="Dismiss announcement"
          className="absolute right-4 text-white/50 hover:text-white"
        >
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M6 6l12 12M18 6L6 18" />
          </svg>
        </button>
      </div>
    </div>
  );
}

function Routes() {
  const { path } = useRoute();
  const [, section, sub, slug] = path.split("/");
  if (path === "/") return <Home />;
  if (path === "/about") return <About />;
  if (path === "/about/leadership") return <Leadership />;
  if (path === "/academics") return <Academics />;
  if (section === "academics" && sub === "faculties") return <FacultyPage slug={slug} />;
  if (section === "academics" && sub === "programmes") return <ProgrammePage slug={slug} />;
  if (path === "/admissions") return <Admissions />;
  if (path === "/apply") return <Apply />;
  if (path === "/portal") return <Portal />;
  if (path === "/admin") return <Admin />;
  if (path === "/campus-life") return <CampusLife />;
  if (path === "/research") return <Research />;
  if (path === "/news") return <News />;
  if (path === "/events") return <Events />;
  if (section === "news") return <NewsArticle slug={slug} />;
  if (section === "events") return <EventDetail slug={slug} />;
  if (path === "/documents") return <Documents />;
  if (path === "/student-hub") return <StudentHub />;
  if (path === "/staff-hub") return <StaffHub />;
  if (path === "/contact") return <Contact />;
  return <NotFound />;
}

function Shell() {
  const reduced = usePrefersReducedMotion();
  const [searchOpen, setSearchOpen] = useState(false);
  useParallax(reduced);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-gold-500 focus:px-4 focus:py-2 focus:text-royal-950"
      >
        Skip to content
      </a>
      <AnnouncementBanner />
      <Navbar onOpenSearch={() => setSearchOpen(true)} />
      <main id="main">
        <Routes />
      </main>
      <Footer />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
      <AskBIU />
    </>
  );
}

export default function App() {
  return (
    <RouterProvider>
      <AuthProvider>
        <ToastProvider>
          <Shell />
        </ToastProvider>
      </AuthProvider>
    </RouterProvider>
  );
}
