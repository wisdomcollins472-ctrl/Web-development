import { useEffect, useState } from "react";

const RM = "(prefers-reduced-motion: reduce)";

export function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(() => window.matchMedia(RM).matches);
  useEffect(() => {
    const mq = window.matchMedia(RM);
    const on = () => setReduced(mq.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return reduced;
}

/**
 * Global transform-only parallax.
 * Elements carrying `data-speed` are translated relative to their nearest
 * `[data-parallax-root]`. Positive speed lags behind scroll (deeper layer),
 * negative speed leads (nearer layer). Disabled for reduced-motion users and
 * damped on small screens.
 */
export function useParallax(reduced: boolean) {
  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>("[data-speed]"));
    if (reduced) {
      els.forEach((el) => (el.style.transform = ""));
      return;
    }
    const items = els.map((el) => ({
      el,
      host: (el.closest("[data-parallax-root]") as HTMLElement) ?? el.parentElement!,
      speed: parseFloat(el.dataset.speed || "0"),
    }));
    let raf = 0;
    const update = () => {
      raf = 0;
      const vh = window.innerHeight;
      const damp = window.innerWidth < 768 ? 0.55 : 1;
      for (const { el, host, speed } of items) {
        const r = host.getBoundingClientRect();
        if (r.bottom < -vh * 0.6 || r.top > vh * 1.6) continue;
        const offset = r.top + r.height / 2 - vh / 2;
        el.style.transform = `translate3d(0, ${(-offset * speed * damp).toFixed(1)}px, 0)`;
      }
    };
    const request = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", request, { passive: true });
    window.addEventListener("resize", request);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", request);
      window.removeEventListener("resize", request);
    };
  }, [reduced]);
}

/** Adds `.in` to every `.reveal` element as it enters the viewport. */
export function useReveal() {
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) =>
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        }),
      { threshold: 0.1, rootMargin: "0px 0px -6% 0px" }
    );
    document.querySelectorAll(".reveal").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

/** Tracks which section id is currently in view (used for nav highlighting). */
export function useActiveSection(ids: string[]) {
  const [active, setActive] = useState(ids[0]);
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" }
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) io.observe(el);
    });
    return () => io.disconnect();
  }, [ids.join(",")]);
  return active;
}
