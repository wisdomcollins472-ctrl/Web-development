/**
 * BIU CONTENT LAYER
 * ---------------------------------------------------------------------------
 * Every record carries a `sources` array pointing at where the fact came from.
 * Fields that could not be verified are deliberately left EMPTY and are hidden
 * by the UI, or shown as CMS-editable placeholders. Nothing here is invented.
 *
 * This module is the seam between the UI and the database. In production the
 * same interfaces are implemented by Supabase (see supabase/schema.sql +
 * src/lib/api.supabase.ts for the intended contract). Locally it is backed by
 * localStorage so the CMS is genuinely editable in this build.
 */

export interface Source { label: string; url: string }

export type Level = "undergraduate" | "postgraduate" | "professional";
export type Status = "published" | "draft";

export interface Department {
  slug: string;
  name: string;
  facultySlug: string;
}

export interface Faculty {
  id: string;
  slug: string;
  name: string;
  short: string;
  ordinal: string;
  summary: string;
  intro: string;
  dean: string;
  departments: string[];
  researchAreas: string[];
  contact: { email: string; phone: string };
  image: string;
  status: Status;
  sources: Source[];
}

export interface Programme {
  id: string;
  slug: string;
  title: string;
  facultySlug: string;
  department: string;
  level: Level;
  award: string;
  duration: string;
  overview: string;
  objectives: string[];
  requirements: string[];
  careers: string[];
  status: Status;
  sources: Source[];
}

export interface Leader {
  id: string;
  name: string;
  role: string;
  office: string;
  bio: string;
  email: string;
  sources: Source[];
}

export interface NewsItem {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  author: string;
  coverImage: string;
  publishedAt: string;
  status: Status;
  seoTitle: string;
  seoDescription: string;
  ogImage: string;
}

export interface EventItem {
  id: string;
  title: string;
  slug: string;
  description: string;
  image: string;
  startDate: string;
  endDate: string;
  location: string;
  category: string;
  registrationUrl: string;
  status: Status;
}

export interface Announcement {
  id: string;
  title: string;
  body: string;
  href: string;
  cta: string;
  startsAt: string;
  expiresAt: string;
  status: Status;
}

export interface DocItem {
  id: string;
  title: string;
  description: string;
  category: string;
  version: string;
  date: string;
  status: Status;
}

export interface Enquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  status: "new" | "in_progress" | "responded" | "resolved";
  createdAt: string;
}

export interface Application {
  id: string;
  ref: string;
  applicantId: string;
  programmeSlug: string;
  level: Level;
  status: "draft" | "submitted" | "under_review" | "additional_information_required" | "accepted" | "rejected" | "withdrawn";
  data: Record<string, string>;
  documents: { id: string; name: string; size: number; type: string; uploadedAt: string }[];
  createdAt: string;
  updatedAt: string;
  history: { at: string; status: string; note: string }[];
}

export interface Notification {
  id: string;
  userId: string;
  category: "application" | "admissions" | "academic" | "events" | "announcements" | "system";
  title: string;
  body: string;
  href: string;
  read: boolean;
  createdAt: string;
}

export interface AuditEntry {
  id: string;
  actor: string;
  action: string;
  resource: string;
  at: string;
}

/* ============================ VERIFIED CONTENT ============================ */

const BIU = "https://biu.edu.ng";
const GMAPS = "https://www.google.com/maps/search/?api=1&query=Benson+Idahosa+University%2C+15+Agboma+St%2C+Ogogugbo%2C+Benin+City+300102%2C+Edo";
const DIRECTIONS = "https://www.google.com/maps/dir/?api=1&destination=Benson+Idahosa+University%2C+15+Agboma+St%2C+Ogogugbo%2C+Benin+City+300102%2C+Edo";
const PLUS = "https://www.google.com/maps/search/?api=1&query=8JP3%2B2Q+Benin+City";

export const CONTACT = {
  name: "Benson Idahosa University",
  short: "BIU",
  website: BIU,
  portal: "https://biuportal.net/",
  phones: [
    { label: "Main line", display: "+234 811 111 7310", tel: "+2348111117310", source: "Office of the Vice Chancellor, biu.edu.ng" },
    { label: "Admissions line", display: "+234 814 990 6200", tel: "+2348149906200", source: "Published BIU contact listing" },
  ],
  addresses: [
    {
      label: "Campus (Google Maps)",
      lines: ["15 Agboma St, Ogogugbo", "Benin City 300102, Edo"],
      href: DIRECTIONS,
    },
    {
      label: "Mailing address",
      lines: ["Private Mail Bag 1100, University Way", "Off Upper Adesuwa Road, GRA, Benin City, Nigeria"],
      href: GMAPS,
    },
  ],
  plusCode: { code: "8JP3+2Q Benin City", href: PLUS },
  hours: { summary: "Open · Closes 4 PM", closes: "4:00 PM", note: "Daily hours beyond the listed closing time are not published on the listing." },
  rating: { value: 4.2, count: 180 },
};

export const REVIEWS = [
  {
    quote:
      "The atmosphere is serene enough for learning, neat (with waste-bins in strategic locations) and shades (tress) that can protect you from the scorching sun.",
    name: "Ejiroghene Onovughe",
    meta: "10 reviews · 4 years ago",
    rating: 5,
  },
  {
    quote:
      "Biu is a great uni to attend.. It made me who I am today and the lecturers are simply awesome. They are always there to help you out in your time of need",
    name: "Michael Egbagbe",
    meta: "Local Guide · 10 years ago",
    rating: 5,
  },
  {
    quote:
      "BIU (previously named Christian Faith University) was renamed in honor of Archbishop Benson Idahosa, a Charismatic Pentecostal minister from Benin City, Nigeria, and reflects his evangelical beliefs.",
    name: "Ayibabebra Alamene",
    meta: "Local Guide · 4 years ago",
    rating: 5,
  },
];

export const FACULTIES: Faculty[] = [
  {
    id: "f-agri",
    slug: "agriculture",
    name: "Faculty of Agriculture",
    short: "Agriculture",
    ordinal: "01",
    summary: "Agricultural science, education and practice.",
    intro: "",
    dean: "",
    departments: ["Agriculture"],
    researchAreas: [],
    contact: { email: "", phone: "" },
    image: "/images/faculty-agriculture.jpg",
    status: "published",
    sources: [{ label: "Educatly — BIU academic programmes", url: "https://www.educatly.com/university/56583/benson-idahosa-university" }],
  },
  {
    id: "f-arts",
    slug: "arts-and-education",
    name: "Faculty of Arts and Education",
    short: "Arts & Education",
    ordinal: "02",
    summary: "Arts, humanities and teacher education.",
    intro: "",
    dean: "",
    departments: ["Arts Education", "Education"],
    researchAreas: [],
    contact: { email: "", phone: "" },
    image: "/images/faculty-arts.jpg",
    status: "published",
    sources: [{ label: "Educatly — BIU academic programmes", url: "https://www.educatly.com/university/56583/benson-idahosa-university" }],
  },
  {
    id: "f-sci",
    slug: "basic-and-applied-sciences",
    name: "Faculty of Basic and Applied Sciences",
    short: "Sciences",
    ordinal: "03",
    summary: "Biological, physical and computing sciences.",
    intro: "",
    dean: "",
    departments: ["Biological Sciences", "Physical Sciences", "Computer Science"],
    researchAreas: [],
    contact: { email: "", phone: "" },
    image: "/images/faculty-sciences.jpg",
    status: "published",
    sources: [{ label: "Grokipedia — BIU faculties and departments", url: "https://grokipedia.com/page/Benson_Idahosa_University" }],
  },
  {
    id: "f-health",
    slug: "basic-medical-and-health-sciences",
    name: "Faculty of Basic Medical and Health Sciences",
    short: "Medical & Health Sciences",
    ordinal: "04",
    summary: "Medicine, nursing and health sciences.",
    intro: "",
    dean: "",
    departments: ["Basic Medical Sciences", "Health Sciences"],
    researchAreas: [],
    contact: { email: "", phone: "" },
    image: "/images/faculty-health.jpg",
    status: "published",
    sources: [{ label: "Grokipedia — BIU faculties and departments", url: "https://grokipedia.com/page/Benson_Idahosa_University" }],
  },
  {
    id: "f-eng",
    slug: "engineering",
    name: "Faculty of Engineering",
    short: "Engineering",
    ordinal: "05",
    summary: "Civil, mechanical and electrical engineering.",
    intro: "",
    dean: "",
    departments: ["Civil Engineering", "Mechanical Engineering", "Electrical & Electronics Engineering"],
    researchAreas: [],
    contact: { email: "", phone: "" },
    image: "/images/faculty-engineering.jpg",
    status: "published",
    sources: [{ label: "Grokipedia — BIU faculties and departments", url: "https://grokipedia.com/page/Benson_Idahosa_University" }],
  },
  {
    id: "f-law",
    slug: "law",
    name: "Faculty of Law",
    short: "Law",
    ordinal: "06",
    summary: "Legal education across public and private law.",
    intro: "",
    dean: "",
    departments: ["Public Law", "Private Law"],
    researchAreas: [],
    contact: { email: "", phone: "" },
    image: "/images/faculty-law.jpg",
    status: "published",
    sources: [{ label: "Grokipedia — BIU faculties and departments", url: "https://grokipedia.com/page/Benson_Idahosa_University" }],
  },
  {
    id: "f-sms",
    slug: "social-and-management-sciences",
    name: "Faculty of Social and Management Sciences",
    short: "Social & Management Sciences",
    ordinal: "07",
    summary: "Management, economics, media and the social sciences.",
    intro: "",
    dean: "",
    departments: [
      "Accounting",
      "Business Administration",
      "Economics, Banking & Finance",
      "Mass Communication",
      "Political Science & Public Administration",
      "Sociology & Anthropology",
    ],
    researchAreas: [],
    contact: { email: "", phone: "" },
    image: "/images/faculty-management.jpg",
    status: "published",
    sources: [{ label: "Grokipedia — BIU faculties and departments", url: "https://grokipedia.com/page/Benson_Idahosa_University" }],
  },
  {
    id: "f-pg",
    slug: "school-of-postgraduate-studies",
    name: "School of Postgraduate Studies",
    short: "Postgraduate",
    ordinal: "08",
    summary: "Postgraduate diplomas, masters and doctoral study.",
    intro: "",
    dean: "",
    departments: [],
    researchAreas: [],
    contact: { email: "", phone: "" },
    image: "/images/faculty-postgraduate.jpg",
    status: "published",
    sources: [{ label: "Educatly — BIU academic programmes", url: "https://www.educatly.com/university/56583/benson-idahosa-university" }],
  },
];

/**
 * Faculty imagery. These are institutional, illustrative campus photographs —
 * each faculty's own imagery is managed from the CMS (faculties.image).
 */
const FACULTY_IMAGES: Record<string, string> = {
  agriculture: "/images/campus.jpg",
  "arts-and-education": "/images/library.jpg",
  "basic-and-applied-sciences": "/images/lab.jpg",
  "basic-medical-and-health-sciences": "/images/lab.jpg",
  engineering: "/images/campus.jpg",
  law: "/images/library.jpg",
  "social-and-management-sciences": "/images/students.jpg",
  "school-of-postgraduate-studies": "/images/library.jpg",
};
FACULTIES.forEach((f) => {
  if (FACULTY_IMAGES[f.slug]) f.image = FACULTY_IMAGES[f.slug];
});

const S_GROK = { label: "BIU programme listings", url: "https://grokipedia.com/page/Benson_Idahosa_University" };
const S_EDU = { label: "Educatly — BIU programmes", url: "https://www.educatly.com/university/56583/benson-idahosa-university" };

function p(
  title: string,
  facultySlug: string,
  department: string,
  level: Level,
  award: string,
  slug: string,
  sources: Source[]
): Programme {
  return {
    id: slug,
    slug,
    title,
    facultySlug,
    department,
    level,
    award,
    duration: "",
    overview: "",
    objectives: [],
    requirements: [],
    careers: [],
    status: "published",
    sources,
  };
}

export const PROGRAMMES: Programme[] = [
  p("Accounting", "social-and-management-sciences", "Accounting", "undergraduate", "B.Sc.", "accounting", [S_EDU]),
  p("Banking and Finance", "social-and-management-sciences", "Economics, Banking & Finance", "undergraduate", "B.Sc.", "banking-and-finance", [S_EDU]),
  p("Business Administration", "social-and-management-sciences", "Business Administration", "undergraduate", "B.Sc.", "business-administration", [S_EDU]),
  p("Economics", "social-and-management-sciences", "Economics, Banking & Finance", "undergraduate", "B.Sc.", "economics", [S_EDU]),
  p("Mass Communication", "social-and-management-sciences", "Mass Communication", "undergraduate", "B.Sc.", "mass-communication", [S_EDU]),
  p("Political Science and Public Administration", "social-and-management-sciences", "Political Science & Public Administration", "undergraduate", "B.Sc.", "political-science-public-administration", [S_EDU]),
  p("Sociology and Anthropology", "social-and-management-sciences", "Sociology & Anthropology", "undergraduate", "B.Sc.", "sociology-anthropology", [S_EDU]),
  p("International Relations and Diplomacy", "social-and-management-sciences", "Political Science & Public Administration", "undergraduate", "B.Sc.", "international-relations-diplomacy", [S_GROK]),
  p("Peace Studies and Conflict Resolution", "social-and-management-sciences", "Sociology & Anthropology", "undergraduate", "B.Sc.", "peace-studies-conflict-resolution", [S_GROK]),
  p("Computer Science", "basic-and-applied-sciences", "Computer Science", "undergraduate", "B.Sc.", "computer-science", [S_EDU]),
  p("Biochemistry", "basic-and-applied-sciences", "Biological Sciences", "undergraduate", "B.Sc.", "biochemistry", [S_EDU]),
  p("Microbiology", "basic-and-applied-sciences", "Biological Sciences", "undergraduate", "B.Sc.", "microbiology", [S_EDU]),
  p("Chemistry", "basic-and-applied-sciences", "Physical Sciences", "undergraduate", "B.Sc.", "chemistry", [S_EDU]),
  p("Physics", "basic-and-applied-sciences", "Physical Sciences", "undergraduate", "B.Sc.", "physics", [S_EDU]),
  p("Geophysics", "basic-and-applied-sciences", "Physical Sciences", "undergraduate", "B.Sc.", "geophysics", [S_EDU]),
  p("Mathematics", "basic-and-applied-sciences", "Physical Sciences", "undergraduate", "B.Sc.", "mathematics", [S_EDU]),
  p("Industrial Mathematics", "basic-and-applied-sciences", "Physical Sciences", "undergraduate", "B.Sc.", "industrial-mathematics", [S_EDU]),
  p("Civil Engineering", "engineering", "Civil Engineering", "undergraduate", "B.Eng.", "civil-engineering", [S_EDU]),
  p("Mechanical Engineering", "engineering", "Mechanical Engineering", "undergraduate", "B.Eng.", "mechanical-engineering", [S_EDU]),
  p("Electrical and Electronics Engineering", "engineering", "Electrical & Electronics Engineering", "undergraduate", "B.Eng.", "electrical-electronics-engineering", [S_EDU]),
  p("Law", "law", "Public Law", "undergraduate", "LL.B.", "law", [S_EDU]),
  p("Medicine and Surgery", "basic-medical-and-health-sciences", "Basic Medical Sciences", "undergraduate", "MBBS", "medicine-and-surgery", [S_GROK]),
  p("Nursing Science", "basic-medical-and-health-sciences", "Health Sciences", "undergraduate", "B.N.Sc.", "nursing-science", [S_EDU]),
  p("Medical Laboratory Science", "basic-medical-and-health-sciences", "Health Sciences", "undergraduate", "B.MLS.", "medical-laboratory-science", [S_EDU]),
  p("Agriculture", "agriculture", "Agriculture", "undergraduate", "B.Agric.", "agriculture", [S_EDU]),
  p("Agricultural Science and Education", "arts-and-education", "Arts Education", "undergraduate", "B.Ed.", "agricultural-science-education", [S_EDU]),
  p("English Language", "arts-and-education", "Arts Education", "undergraduate", "B.A.", "english-language", [S_EDU]),
  p("Christian Religious Studies", "arts-and-education", "Arts Education", "undergraduate", "B.A.", "christian-religious-studies", [S_EDU]),
  p("Education and Mathematics", "arts-and-education", "Education", "undergraduate", "B.Ed.", "education-mathematics", [S_EDU]),
  p("Education and English Language", "arts-and-education", "Education", "undergraduate", "B.Ed.", "education-english-language", [S_EDU]),
  p("Education and Economics", "arts-and-education", "Education", "undergraduate", "B.Ed.", "education-economics", [S_EDU]),
  p("Library and Information Studies", "arts-and-education", "Arts Education", "undergraduate", "B.Sc.", "library-information-studies", [S_EDU]),
  p("M.Sc. Accounting", "school-of-postgraduate-studies", "Accounting", "postgraduate", "M.Sc.", "msc-accounting", [S_GROK]),
  p("M.Sc. Business Administration", "school-of-postgraduate-studies", "Business Administration", "postgraduate", "M.Sc.", "msc-business-administration", [S_GROK]),
  p("Ph.D. Economics", "school-of-postgraduate-studies", "Economics, Banking & Finance", "postgraduate", "Ph.D.", "phd-economics", [S_GROK]),
  p("Ph.D. Public Administration", "school-of-postgraduate-studies", "Political Science & Public Administration", "postgraduate", "Ph.D.", "phd-public-administration", [S_GROK]),
];

export const LEADERS: Leader[] = [
  {
    id: "l-president",
    name: "Bishop F. E. B. Idahosa",
    role: "President",
    office: "Office of the President",
    bio: "",
    email: "",
    sources: [{ label: "BIU leadership listing", url: "https://grokipedia.com/page/Benson_Idahosa_University" }],
  },
  {
    id: "l-chancellor",
    name: "Archbishop Margaret E. Benson-Idahosa",
    role: "Chancellor",
    office: "Office of the Chancellor",
    bio: "",
    email: "",
    sources: [{ label: "BIU leadership listing", url: "https://grokipedia.com/page/Benson_Idahosa_University" }],
  },
  {
    id: "l-vc",
    name: "Prof. Sam Guobadia",
    role: "Vice Chancellor",
    office: "Office of the Vice Chancellor",
    bio: "",
    email: "",
    sources: [{ label: "BIU management listing", url: "https://rocketreach.co/benson-idahosa-university-management_b6a0bb01c872def9" }],
  },
];

export const CAMPUS_LIFE = [
  { name: "Accommodation", note: "Where students live", image: "/images/campus.jpg", tag: "Illustrative" },
  { name: "Student Affairs", note: "Support and representation", image: "/images/students.jpg", tag: "Illustrative" },
  { name: "Sports", note: "Athletics and recreation", image: "/images/students.jpg", tag: "Illustrative" },
  { name: "Clubs & Societies", note: "Societies and interests", image: "/images/students.jpg", tag: "Illustrative" },
  { name: "Chapel", note: "Worship and fellowship", image: "/images/chapel.jpg", tag: "Illustrative" },
  { name: "Health", note: "Campus medical care", image: "/images/lab.jpg", tag: "Illustrative" },
  { name: "Dining", note: "Meals and cafés", image: "/images/campus.jpg", tag: "Illustrative" },
  { name: "Events", note: "What's happening on campus", image: "/images/students.jpg", tag: "Illustrative" },
];

export const DOC_CATEGORIES = ["Admissions", "Academic", "Policies", "Forms", "Handbooks", "Calendars", "Prospectus", "Fees", "Other"];
export const NEWS_CATEGORIES = ["Academic", "Admissions", "Campus", "Research", "Events", "Community", "Announcements"];

/* ============================ DATA ACCESS ================================ */

const KEY = "biu.cms.v2";
const LATENCY = 260; // ms — makes loading states real

interface Store {
  news: NewsItem[];
  events: EventItem[];
  announcements: Announcement[];
  documents: DocItem[];
  enquiries: Enquiry[];
  applications: Application[];
  notifications: Notification[];
  audit: AuditEntry[];
  programmes: Programme[];
  faculties: Faculty[];
}

const EMPTY: Store = {
  news: [],
  events: [],
  announcements: [],
  documents: [],
  enquiries: [],
  applications: [],
  notifications: [],
  audit: [],
  programmes: PROGRAMMES,
  faculties: FACULTIES,
};

function load(): Store {
  if (typeof localStorage === "undefined") return { ...EMPTY };
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...EMPTY };
    const parsed = JSON.parse(raw);
    return { ...EMPTY, ...parsed };
  } catch {
    return { ...EMPTY };
  }
}

function save(s: Store) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* storage unavailable — session-only */
  }
}

let store: Store = load();
const listeners = new Set<() => void>();

function commit() {
  save(store);
  listeners.forEach((l) => l());
}

export function subscribe(l: () => void) {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

export function getStore() {
  return store;
}

function delay<T>(value: T): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), LATENCY));
}

export const db = {
  async faculties(): Promise<Faculty[]> {
    return delay(store.faculties.filter((f) => f.status === "published"));
  },
  async allFaculties(): Promise<Faculty[]> {
    return delay(store.faculties);
  },
  async faculty(slug: string): Promise<Faculty | null> {
    return delay(store.faculties.find((f) => f.slug === slug) ?? null);
  },
  async programmes(filter?: { q?: string; level?: Level | "all"; faculty?: string; department?: string }): Promise<Programme[]> {
    let out = store.programmes.filter((p) => p.status === "published");
    const q = filter?.q?.trim().toLowerCase();
    if (q) out = out.filter((p) => `${p.title} ${p.department} ${p.award}`.toLowerCase().includes(q));
    if (filter?.level && filter.level !== "all") out = out.filter((p) => p.level === filter.level);
    if (filter?.faculty && filter.faculty !== "all") out = out.filter((p) => p.facultySlug === filter.faculty);
    if (filter?.department && filter.department !== "all") out = out.filter((p) => p.department === filter.department);
    return delay(out);
  },
  async programme(slug: string): Promise<Programme | null> {
    return delay(store.programmes.find((p) => p.slug === slug) ?? null);
  },
  async news(): Promise<NewsItem[]> {
    return delay(store.news.filter((n) => n.status === "published"));
  },
  async newsItem(slug: string): Promise<NewsItem | null> {
    return delay(store.news.find((n) => n.slug === slug) ?? null);
  },
  async events(): Promise<EventItem[]> {
    return delay(
      store.events
        .filter((e) => e.status === "published")
        .sort((a, b) => a.startDate.localeCompare(b.startDate))
    );
  },
  async event(slug: string): Promise<EventItem | null> {
    return delay(store.events.find((e) => e.slug === slug) ?? null);
  },
  async announcements(): Promise<Announcement[]> {
    const now = new Date().toISOString();
    return delay(
      store.announcements.filter((a) => a.status === "published" && a.startsAt <= now && a.expiresAt > now)
    );
  },
  async documents(): Promise<DocItem[]> {
    return delay(store.documents.filter((d) => d.status === "published"));
  },
  async enquiries(): Promise<Enquiry[]> {
    return delay([...store.enquiries].reverse());
  },
  async applications(applicantId: string): Promise<Application[]> {
    return delay(store.applications.filter((a) => a.applicantId === applicantId));
  },
  async allApplications(): Promise<Application[]> {
    return delay([...store.applications].reverse());
  },
  async notifications(userId: string): Promise<Notification[]> {
    return delay(
      store.notifications.filter((n) => n.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    );
  },
  async audit(): Promise<AuditEntry[]> {
    return delay([...store.audit].reverse());
  },
};

export const admin = {
  log(action: string, resource: string) {
    store = {
      ...store,
      audit: [
        { id: crypto.randomUUID(), actor: currentActor(), action, resource, at: new Date().toISOString() },
        ...store.audit,
      ].slice(0, 200),
    };
    commit();
  },
  upsertProgramme(p: Programme) {
    const exists = store.programmes.some((x) => x.id === p.id);
    store = { ...store, programmes: exists ? store.programmes.map((x) => (x.id === p.id ? p : x)) : [p, ...store.programmes] };
    admin.log(exists ? "CONTENT_UPDATED" : "CONTENT_CREATED", `programme:${p.slug}`);
    commit();
  },
  deleteProgramme(id: string) {
    const p = store.programmes.find((x) => x.id === id);
    store = { ...store, programmes: store.programmes.filter((x) => x.id !== id) };
    admin.log("CONTENT_DELETED", `programme:${p?.slug ?? id}`);
    commit();
  },
  upsertFaculty(f: Faculty) {
    const exists = store.faculties.some((x) => x.id === f.id);
    store = { ...store, faculties: exists ? store.faculties.map((x) => (x.id === f.id ? f : x)) : [f, ...store.faculties] };
    admin.log(exists ? "CONTENT_UPDATED" : "CONTENT_CREATED", `faculty:${f.slug}`);
    commit();
  },
  deleteFaculty(id: string) {
    const f = store.faculties.find((x) => x.id === id);
    store = { ...store, faculties: store.faculties.filter((x) => x.id !== id) };
    admin.log("CONTENT_DELETED", `faculty:${f?.slug ?? id}`);
    commit();
  },
  upsertNews(n: NewsItem) {
    const exists = store.news.some((x) => x.id === n.id);
    store = { ...store, news: exists ? store.news.map((x) => (x.id === n.id ? n : x)) : [n, ...store.news] };
    admin.log(exists ? "CONTENT_UPDATED" : "CONTENT_CREATED", `news:${n.slug}`);
    commit();
  },
  deleteNews(id: string) {
    const n = store.news.find((x) => x.id === id);
    store = { ...store, news: store.news.filter((x) => x.id !== id) };
    admin.log("CONTENT_DELETED", `news:${n?.slug ?? id}`);
    commit();
  },
  upsertEvent(e: EventItem) {
    const exists = store.events.some((x) => x.id === e.id);
    store = { ...store, events: exists ? store.events.map((x) => (x.id === e.id ? e : x)) : [e, ...store.events] };
    admin.log(exists ? "CONTENT_UPDATED" : "CONTENT_CREATED", `event:${e.slug}`);
    commit();
  },
  deleteEvent(id: string) {
    const e = store.events.find((x) => x.id === id);
    store = { ...store, events: store.events.filter((x) => x.id !== id) };
    admin.log("CONTENT_DELETED", `event:${e?.slug ?? id}`);
    commit();
  },
  upsertAnnouncement(a: Announcement) {
    const exists = store.announcements.some((x) => x.id === a.id);
    store = { ...store, announcements: exists ? store.announcements.map((x) => (x.id === a.id ? a : x)) : [a, ...store.announcements] };
    admin.log(exists ? "CONTENT_UPDATED" : "CONTENT_CREATED", `announcement:${a.id}`);
    commit();
  },
  deleteAnnouncement(id: string) {
    store = { ...store, announcements: store.announcements.filter((x) => x.id !== id) };
    admin.log("CONTENT_DELETED", `announcement:${id}`);
    commit();
  },
  upsertDocument(d: DocItem) {
    const exists = store.documents.some((x) => x.id === d.id);
    store = { ...store, documents: exists ? store.documents.map((x) => (x.id === d.id ? d : x)) : [d, ...store.documents] };
    admin.log("DOCUMENT_UPLOADED", `document:${d.title}`);
    commit();
  },
  deleteDocument(id: string) {
    const d = store.documents.find((x) => x.id === id);
    store = { ...store, documents: store.documents.filter((x) => x.id !== id) };
    admin.log("CONTENT_DELETED", `document:${d?.title ?? id}`);
    commit();
  },
  setEnquiryStatus(id: string, status: Enquiry["status"]) {
    const e = store.enquiries.find((x) => x.id === id);
    store = { ...store, enquiries: store.enquiries.map((x) => (x.id === id ? { ...x, status } : x)) };
    if (e) admin.log("ENQUIRY_STATUS_CHANGED", `enquiry:${id} → ${status}`);
    commit();
  },
  upsertApplication(a: Application) {
    const exists = store.applications.some((x) => x.id === a.id);
    store = {
      ...store,
      applications: exists ? store.applications.map((x) => (x.id === a.id ? a : x)) : [a, ...store.applications],
    };
    commit();
  },
  createApplication(applicantId: string, programmeSlug: string, level: Level, data: Record<string, string>) {
    const now = new Date().toISOString();
    const app: Application = {
      id: uid(),
      ref: ref(),
      applicantId,
      programmeSlug,
      level,
      status: "draft",
      data,
      documents: [],
      createdAt: now,
      updatedAt: now,
      history: [{ at: now, status: "draft", note: "Application created." }],
    };
    store = { ...store, applications: [app, ...store.applications] };
    pushNotification(applicantId, {
      category: "application",
      title: "Application started",
      body: `Draft ${app.ref} created. Complete and submit when ready.`,
      href: "/portal",
    });
    admin.log("APPLICATION_CREATED", `application:${app.ref}`);
    return app;
  },
  submitApplication(id: string) {
    const a = store.applications.find((x) => x.id === id);
    if (!a) return;
    const now = new Date().toISOString();
    const updated: Application = {
      ...a,
      status: "submitted",
      updatedAt: now,
      history: [...a.history, { at: now, status: "submitted", note: "Submitted by applicant." }],
    };
    store = { ...store, applications: store.applications.map((x) => (x.id === id ? updated : x)) };
    pushNotification(a.applicantId, {
      category: "application",
      title: "Application submitted",
      body: `We have received ${a.ref}. You will be notified of any status change.`,
      href: "/portal",
    });
    admin.log("APPLICATION_SUBMITTED", `application:${a.ref}`);
    commit();
  },
  withdrawApplication(id: string) {
    const a = store.applications.find((x) => x.id === id);
    if (!a) return;
    const now = new Date().toISOString();
    const updated: Application = {
      ...a,
      status: "withdrawn",
      updatedAt: now,
      history: [...a.history, { at: now, status: "withdrawn", note: "Withdrawn by applicant." }],
    };
    store = { ...store, applications: store.applications.map((x) => (x.id === id ? updated : x)) };
    admin.log("APPLICATION_STATUS_CHANGED", `application:${a.ref} → withdrawn`);
    commit();
  },
  setApplicationStatus(id: string, status: Application["status"], note = "") {
    const a = store.applications.find((x) => x.id === id);
    if (!a) return;
    const updated: Application = {
      ...a,
      status,
      updatedAt: new Date().toISOString(),
      history: [...a.history, { at: new Date().toISOString(), status, note }],
    };
    store = { ...store, applications: store.applications.map((x) => (x.id === id ? updated : x)) };
    pushNotification(a.applicantId, {
      category: "application",
      title: `Application ${status.replace(/_/g, " ")}`,
      body: `Your application ${a.ref} is now ${status.replace(/_/g, " ")}.${note ? ` ${note}` : ""}`,
      href: "/portal",
    });
    admin.log("APPLICATION_STATUS_CHANGED", `application:${a.ref} → ${status}`);
    commit();
  },
};

function currentActor() {
  try {
    const raw = localStorage.getItem("biu.session.v1");
    if (raw) return JSON.parse(raw).email ?? "system";
  } catch {
    /* ignore */
  }
  return "system";
}

export function pushNotification(userId: string, n: Omit<Notification, "id" | "userId" | "read" | "createdAt">) {
  store = {
    ...store,
    notifications: [
      { ...n, id: crypto.randomUUID(), userId, read: false, createdAt: new Date().toISOString() },
      ...store.notifications,
    ],
  };
  commit();
}

export function createEnquiry(e: Omit<Enquiry, "id" | "status" | "createdAt">) {
  const item: Enquiry = { ...e, id: crypto.randomUUID(), status: "new", createdAt: new Date().toISOString() };
  store = { ...store, enquiries: [item, ...store.enquiries] };
  commit();
  return item;
}

export function slugify(s: string) {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export function uid() {
  // crypto.randomUUID is unavailable in some non-secure contexts.
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return "id-" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function ref() {
  return "BIU-" + new Date().getFullYear() + "-" + Math.floor(100000 + Math.random() * 899999);
}

export const LEVELS: { value: Level; label: string }[] = [
  { value: "undergraduate", label: "Undergraduate" },
  { value: "postgraduate", label: "Postgraduate" },
  { value: "professional", label: "Professional" },
];

export const LEVEL_LABEL: Record<Level, string> = {
  undergraduate: "Undergraduate",
  postgraduate: "Postgraduate",
  professional: "Professional",
};
