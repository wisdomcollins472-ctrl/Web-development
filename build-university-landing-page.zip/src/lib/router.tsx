import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

/** Route table — also used to generate the sitemap at deploy time. */
export const ROUTES = [
  { path: "/", label: "Home", seo: { title: "Benson Idahosa University — Where Purpose Becomes Possibility", description: "A university experience designed to develop academically excellent, professionally capable and purpose-driven leaders." } },
  { path: "/about", label: "About", seo: { title: "About BIU — Vision, Mission & Leadership", description: "Benson Idahosa University: institutional overview, vision and mission, and leadership directory." } },
  { path: "/academics", label: "Academics", seo: { title: "Academics — Faculties & Programmes", description: "Explore BIU faculties, departments and programmes." } },
  { path: "/academics/faculties", label: "Faculties", seo: { title: "Faculties", description: "Browse BIU faculties." } },
  { path: "/academics/programmes", label: "Programmes", seo: { title: "Programmes", description: "Search BIU programmes by level, faculty and department." } },
  { path: "/admissions", label: "Admissions", seo: { title: "Admissions — Your Next Chapter Starts Here", description: "Undergraduate, postgraduate and professional admissions at Benson Idahosa University." } },
  { path: "/apply", label: "Apply", seo: { title: "Start Your Application", description: "Create your BIU application." } },
  { path: "/portal", label: "Student & Applicant Portal", seo: { title: "Applicant Portal", description: "Track your application, documents and notifications." } },
  { path: "/campus-life", label: "Campus Life", seo: { title: "Campus Life", description: "Accommodation, student affairs, sports, clubs, chapel, health, dining and events." } },
  { path: "/research", label: "Research", seo: { title: "Research & Innovation", description: "Research areas, centres and partnerships at BIU." } },
  { path: "/news", label: "News", seo: { title: "News & Announcements", description: "The latest news from Benson Idahosa University." } },
  { path: "/events", label: "Events", seo: { title: "Events", description: "Upcoming events at Benson Idahosa University." } },
  { path: "/documents", label: "Documents", seo: { title: "Document Centre", description: "Admissions, academic, policy and form downloads." } },
  { path: "/contact", label: "Contact", seo: { title: "Contact BIU", description: "Contact Benson Idahosa University, Benin City." } },
  { path: "/student-hub", label: "Student Hub", seo: { title: "Student Hub", description: "Portal, e-learning, CBT, library and student support links." } },
  { path: "/staff-hub", label: "Staff Hub", seo: { title: "Staff Hub", description: "Staff portal and academic systems." } },
  { path: "/admin", label: "Admin", seo: { title: "CMS Administration", description: "BIU content management." } },
] as const;

interface Ctx {
  path: string;
  navigate: (to: string) => void;
}
const RouterCtx = createContext<Ctx>({ path: "/", navigate: () => {} });

function currentPath() {
  const h = window.location.hash.replace(/^#/, "");
  return h.startsWith("/") ? h : "/";
}

export function RouterProvider({ children }: { children: ReactNode }) {
  const [path, setPath] = useState(currentPath);

  useEffect(() => {
    const on = () => setPath(currentPath());
    window.addEventListener("hashchange", on);
    if (!window.location.hash) window.location.hash = "#/";
    return () => window.removeEventListener("hashchange", on);
  }, []);

  // Scroll restoration + title sync
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    const route = ROUTES.find((r) => r.path === path.split("?")[0]);
    if (route) document.title = route.seo.title;
  }, [path]);

  const navigate = useCallback((to: string) => {
    window.location.hash = to.startsWith("#") ? to : `#${to}`;
  }, []);

  const value = useMemo(() => ({ path, navigate }), [path, navigate]);
  return <RouterCtx.Provider value={value}>{children}</RouterCtx.Provider>;
}

export function useRouter() {
  return useContext(RouterCtx);
}

/** Current path plus parsed query string. */
export function useRoute() {
  const { path } = useRouter();
  return useMemo(() => {
    const [pure, qs = ""] = path.split("?");
    return { path: pure, query: new URLSearchParams(qs) };
  }, [path]);
}

/** Scroll to an in-page section once it exists (used for ?section= links). */
export function useSectionScroll(deps: unknown[] = []) {
  const { query } = useRoute();
  const section = query.get("section");
  useEffect(() => {
    if (!section) return;
    const id = setTimeout(() => {
      const el = document.getElementById(section);
      if (el) {
        const y = el.getBoundingClientRect().top + window.scrollY - 96;
        window.scrollTo({ top: y, behavior: "smooth" });
      }
    }, 260);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [section, ...deps]);
}

export function Link({
  to,
  children,
  className,
  ...rest
}: { to: string; children: ReactNode } & React.AnchorHTMLAttributes<HTMLAnchorElement>) {
  const { navigate } = useRouter();
  const href = to.startsWith("#") ? to : `#${to}`;
  return (
    <a
      href={href}
      className={className}
      onClick={(e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey) return;
        e.preventDefault();
        navigate(to);
      }}
      {...rest}
    >
      {children}
    </a>
  );
}

export function useQuery() {
  const { path } = useRouter();
  const [query, setQuery] = useState("");
  useEffect(() => setQuery(window.location.hash.split("?")[1] ?? ""), [path]);
  return new URLSearchParams(query);
}
