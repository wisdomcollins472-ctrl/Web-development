import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { uid } from "./cms";

/**
 * AUTHENTICATION, ROLES & PERMISSIONS
 * ---------------------------------------------------------------------------
 * The session is client-held here so this build runs standalone. In production
 * the same interface is backed by Supabase Auth; `can()` is mirrored by
 * PostgreSQL RLS policies (see supabase/schema.sql) so permissions are also
 * enforced server-side — never by hiding UI alone.
 */

export const ROLES = [
  "SUPER_ADMIN",
  "ADMIN",
  "ADMISSIONS",
  "EDITOR",
  "FACULTY_ADMIN",
  "STAFF",
  "STUDENT",
  "APPLICANT",
] as const;
export type Role = (typeof ROLES)[number];

export const PERMISSIONS: Record<Role, string[]> = {
  SUPER_ADMIN: ["*"],
  ADMIN: [
    "content.read", "content.write", "content.delete", "content.publish",
    "applications.read", "applications.update",
    "enquiries.read", "enquiries.update",
    "users.read", "audit.read", "analytics.read", "documents.write",
  ],
  ADMISSIONS: ["content.read", "applications.read", "applications.update", "enquiries.read", "enquiries.update", "documents.write"],
  EDITOR: ["content.read", "content.write", "content.publish", "documents.write"],
  FACULTY_ADMIN: ["content.read", "programmes.read", "programmes.write"],
  STAFF: ["content.read"],
  STUDENT: [],
  APPLICANT: [],
};

export function can(role: Role | null, perm: string) {
  if (!role) return false;
  const list = PERMISSIONS[role];
  return list.includes("*") || list.includes(perm);
}

export interface Session {
  id: string;
  email: string;
  name: string;
  role: Role;
}

const SESSION_KEY = "biu.session.v1";
const USERS_KEY = "biu.users.v1";

interface StoredUser extends Session {
  password: string;
}

const DEMO_USERS: StoredUser[] = [
  { id: "u-admin", email: "admin@biu.edu.ng", name: "Site Administrator", role: "SUPER_ADMIN", password: "biu-admin" },
  { id: "u-adm", email: "admissions@biu.edu.ng", name: "Admissions Officer", role: "ADMISSIONS", password: "biu-admissions" },
  { id: "u-app", email: "applicant@biu.edu.ng", name: "Demo Applicant", role: "APPLICANT", password: "biu-applicant" },
];

function loadUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    return raw ? (JSON.parse(raw) as StoredUser[]) : DEMO_USERS;
  } catch {
    return DEMO_USERS;
  }
}

function saveUsers(u: StoredUser[]) {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(u));
  } catch {
    /* ignore */
  }
}

interface AuthCtx {
  session: Session | null;
  login: (email: string, password: string) => Promise<Session>;
  logout: () => void;
  register: (name: string, email: string, password: string) => Promise<Session>;
  can: (perm: string) => boolean;
}

const Ctx = createContext<AuthCtx>({
  session: null,
  login: async () => {
    throw new Error("no provider");
  },
  logout: () => {},
  register: async () => {
    throw new Error("no provider");
  },
  can: () => false,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (raw) setSession(JSON.parse(raw) as Session);
    } catch {
      /* ignore */
    }
  }, []);

  const persist = (s: Session | null) => {
    setSession(s);
    try {
      if (s) localStorage.setItem(SESSION_KEY, JSON.stringify(s));
      else localStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
  };

  const login = useCallback(async (email: string, password: string) => {
    await new Promise((r) => setTimeout(r, 320));
    const user = loadUsers().find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!user || user.password !== password) throw new Error("Incorrect email or password.");
    const { password: _p, ...rest } = user;
    persist(rest);
    return rest;
  }, []);

  const register = useCallback(async (name: string, email: string, password: string) => {
    await new Promise((r) => setTimeout(r, 380));
    const users = loadUsers();
    if (users.some((u) => u.email.toLowerCase() === email.trim().toLowerCase()))
      throw new Error("An account with this email already exists.");
    const user: StoredUser = {
      id: uid(),
      email: email.trim(),
      name: name.trim(),
      role: "APPLICANT",
      password,
    };
    saveUsers([...users, user]);
    const { password: _p, ...rest } = user;
    persist(rest);
    return rest;
  }, []);

  const logout = useCallback(() => persist(null), []);

  const value = useMemo<AuthCtx>(
    () => ({ session, login, logout, register, can: (perm: string) => can(session?.role ?? null, perm) }),
    [session, login, logout, register]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  return useContext(Ctx);
}

/** Demo accounts surfaced in the UI — clearly labelled as demonstration data. */
export const DEMO_ACCOUNTS = [
  { role: "SUPER_ADMIN", email: "admin@biu.edu.ng", password: "biu-admin" },
  { role: "ADMISSIONS", email: "admissions@biu.edu.ng", password: "biu-admissions" },
  { role: "APPLICANT", email: "applicant@biu.edu.ng", password: "biu-applicant" },
];
